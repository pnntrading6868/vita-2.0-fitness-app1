import {
  type User,
  type InsertUser,
  type Coach,
  type InsertCoach,
  type Client,
  type InsertClient,
  type Package,
  type InsertPackage,
  type Session,
  type InsertSession,
  type Message,
  type InsertMessage,
  type Wallet,
  type InsertWallet,
  type Transaction,
  type InsertTransaction,
  type Achievement,
  type InsertAchievement,
  type Review,
  type InsertReview,
} from "@shared/schema";
import { randomUUID } from "crypto";

// Storage interface for all VITA entities
export interface IStorage {
  // ===== USER METHODS =====
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // ===== COACH METHODS =====
  getAllCoaches(): Promise<Coach[]>;
  getCoach(id: string): Promise<Coach | undefined>;
  getCoachesBySport(sport: string): Promise<Coach[]>;
  createCoach(coach: InsertCoach): Promise<Coach>;
  updateCoach(id: string, updates: Partial<Coach>): Promise<Coach | undefined>;
  deleteCoach(id: string): Promise<boolean>;

  // ===== CLIENT METHODS (for Coach CRM) =====
  getClientsByCoach(coachId: string): Promise<Client[]>;
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, updates: Partial<Client>): Promise<Client | undefined>;
  deleteClient(id: string): Promise<boolean>;

  // ===== PACKAGE METHODS =====
  getAllPackages(): Promise<Package[]>;
  getPackage(id: string): Promise<Package | undefined>;
  createPackage(pkg: InsertPackage): Promise<Package>;
  updatePackage(id: string, updates: Partial<Package>): Promise<Package | undefined>;
  deletePackage(id: string): Promise<boolean>;

  // ===== SESSION METHODS =====
  getSessionsByAthlete(athleteId: string): Promise<Session[]>;
  getSessionsByCoach(coachId: string): Promise<Session[]>;
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined>;
  deleteSession(id: string): Promise<boolean>;

  // ===== MESSAGE METHODS =====
  getMessagesByUser(userId: string): Promise<Message[]>;
  getConversation(user1Id: string, user2Id: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: string): Promise<boolean>;

  // ===== WALLET METHODS =====
  getWallet(userId: string): Promise<Wallet | undefined>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(userId: string, amount: number): Promise<Wallet | undefined>;

  // ===== TRANSACTION METHODS =====
  getTransactionsByWallet(walletId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(
    id: string,
    status: string
  ): Promise<Transaction | undefined>;

  // ===== ACHIEVEMENT METHODS =====
  getAchievementsByUser(userId: string): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  updateAchievement(
    id: string,
    updates: Partial<Achievement>
  ): Promise<Achievement | undefined>;
  unlockAchievement(id: string): Promise<Achievement | undefined>;

  // ===== REVIEW METHODS =====
  getReviewsByCoach(coachId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private coaches: Map<string, Coach>;
  private clients: Map<string, Client>;
  private packages: Map<string, Package>;
  private sessions: Map<string, Session>;
  private messages: Map<string, Message>;
  private wallets: Map<string, Wallet>;
  private transactions: Map<string, Transaction>;
  private achievements: Map<string, Achievement>;
  private reviews: Map<string, Review>;

  constructor() {
    this.users = new Map();
    this.coaches = new Map();
    this.clients = new Map();
    this.packages = new Map();
    this.sessions = new Map();
    this.messages = new Map();
    this.wallets = new Map();
    this.transactions = new Map();
    this.achievements = new Map();
    this.reviews = new Map();
  }

  // ===== USER METHODS =====
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(
    id: string,
    updates: Partial<User>
  ): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  // ===== COACH METHODS =====
  async getAllCoaches(): Promise<Coach[]> {
    return Array.from(this.coaches.values());
  }

  async getCoach(id: string): Promise<Coach | undefined> {
    return this.coaches.get(id);
  }

  async getCoachesBySport(sport: string): Promise<Coach[]> {
    return Array.from(this.coaches.values()).filter(
      (coach) => coach.sport === sport
    );
  }

  async createCoach(insertCoach: InsertCoach): Promise<Coach> {
    const id = randomUUID();
    const coach: Coach = {
      ...insertCoach,
      id,
      createdAt: new Date(),
    };
    this.coaches.set(id, coach);
    return coach;
  }

  async updateCoach(
    id: string,
    updates: Partial<Coach>
  ): Promise<Coach | undefined> {
    const coach = this.coaches.get(id);
    if (!coach) return undefined;
    const updated = { ...coach, ...updates };
    this.coaches.set(id, updated);
    return updated;
  }

  async deleteCoach(id: string): Promise<boolean> {
    return this.coaches.delete(id);
  }

  // ===== CLIENT METHODS =====
  async getClientsByCoach(coachId: string): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(
      (client) => client.coachId === coachId
    );
  }

  async getClient(id: string): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const id = randomUUID();
    const client: Client = {
      ...insertClient,
      id,
      createdAt: new Date(),
    };
    this.clients.set(id, client);
    return client;
  }

  async updateClient(
    id: string,
    updates: Partial<Client>
  ): Promise<Client | undefined> {
    const client = this.clients.get(id);
    if (!client) return undefined;
    const updated = { ...client, ...updates };
    this.clients.set(id, updated);
    return updated;
  }

  async deleteClient(id: string): Promise<boolean> {
    return this.clients.delete(id);
  }

  // ===== PACKAGE METHODS =====
  async getAllPackages(): Promise<Package[]> {
    return Array.from(this.packages.values());
  }

  async getPackage(id: string): Promise<Package | undefined> {
    return this.packages.get(id);
  }

  async createPackage(insertPackage: InsertPackage): Promise<Package> {
    const id = randomUUID();
    const pkg: Package = {
      ...insertPackage,
      id,
      createdAt: new Date(),
    };
    this.packages.set(id, pkg);
    return pkg;
  }

  async updatePackage(
    id: string,
    updates: Partial<Package>
  ): Promise<Package | undefined> {
    const pkg = this.packages.get(id);
    if (!pkg) return undefined;
    const updated = { ...pkg, ...updates };
    this.packages.set(id, updated);
    return updated;
  }

  async deletePackage(id: string): Promise<boolean> {
    return this.packages.delete(id);
  }

  // ===== SESSION METHODS =====
  async getSessionsByAthlete(athleteId: string): Promise<Session[]> {
    return Array.from(this.sessions.values()).filter(
      (session) => session.athleteId === athleteId
    );
  }

  async getSessionsByCoach(coachId: string): Promise<Session[]> {
    return Array.from(this.sessions.values()).filter(
      (session) => session.coachId === coachId
    );
  }

  async getSession(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      ...insertSession,
      id,
      createdAt: new Date(),
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSession(
    id: string,
    updates: Partial<Session>
  ): Promise<Session | undefined> {
    const session = this.sessions.get(id);
    if (!session) return undefined;
    const updated = { ...session, ...updates };
    this.sessions.set(id, updated);
    return updated;
  }

  async deleteSession(id: string): Promise<boolean> {
    return this.sessions.delete(id);
  }

  // ===== MESSAGE METHODS =====
  async getMessagesByUser(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (msg) => msg.senderId === userId || msg.recipientId === userId
    );
  }

  async getConversation(user1Id: string, user2Id: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(
        (msg) =>
          (msg.senderId === user1Id && msg.recipientId === user2Id) ||
          (msg.senderId === user2Id && msg.recipientId === user1Id)
      )
      .sort(
        (a, b) =>
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      read: false,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async markMessageAsRead(id: string): Promise<boolean> {
    const message = this.messages.get(id);
    if (!message) return false;
    message.read = true;
    this.messages.set(id, message);
    return true;
  }

  // ===== WALLET METHODS =====
  async getWallet(userId: string): Promise<Wallet | undefined> {
    return Array.from(this.wallets.values()).find(
      (wallet) => wallet.userId === userId
    );
  }

  async createWallet(insertWallet: InsertWallet): Promise<Wallet> {
    const id = randomUUID();
    const wallet: Wallet = {
      ...insertWallet,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.wallets.set(id, wallet);
    return wallet;
  }

  async updateWalletBalance(
    userId: string,
    amount: number
  ): Promise<Wallet | undefined> {
    const wallet = await this.getWallet(userId);
    if (!wallet) return undefined;
    wallet.balance += amount;
    wallet.updatedAt = new Date();
    this.wallets.set(wallet.id, wallet);
    return wallet;
  }

  // ===== TRANSACTION METHODS =====
  async getTransactionsByWallet(walletId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((tx) => tx.walletId === walletId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createTransaction(
    insertTransaction: InsertTransaction
  ): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionStatus(
    id: string,
    status: string
  ): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;
    transaction.status = status;
    this.transactions.set(id, transaction);
    return transaction;
  }

  // ===== ACHIEVEMENT METHODS =====
  async getAchievementsByUser(userId: string): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(
      (achievement) => achievement.userId === userId
    );
  }

  async createAchievement(
    insertAchievement: InsertAchievement
  ): Promise<Achievement> {
    const id = randomUUID();
    const achievement: Achievement = {
      ...insertAchievement,
      id,
      createdAt: new Date(),
    };
    this.achievements.set(id, achievement);
    return achievement;
  }

  async updateAchievement(
    id: string,
    updates: Partial<Achievement>
  ): Promise<Achievement | undefined> {
    const achievement = this.achievements.get(id);
    if (!achievement) return undefined;
    const updated = { ...achievement, ...updates };
    this.achievements.set(id, updated);
    return updated;
  }

  async unlockAchievement(id: string): Promise<Achievement | undefined> {
    const achievement = this.achievements.get(id);
    if (!achievement) return undefined;
    achievement.unlocked = true;
    achievement.unlockedAt = new Date();
    this.achievements.set(id, achievement);
    return achievement;
  }

  // ===== REVIEW METHODS =====
  async getReviewsByCoach(coachId: string): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter((review) => review.coachId === coachId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = randomUUID();
    const review: Review = {
      ...insertReview,
      id,
      createdAt: new Date(),
    };
    this.reviews.set(id, review);
    return review;
  }
}

export const storage = new MemStorage();
