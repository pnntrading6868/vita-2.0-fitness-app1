import { storage } from "./storage";

// Seed database with initial data for demo purposes
export async function seedData() {
  // Check if already seeded
  const existingCoaches = await storage.getAllCoaches();
  if (existingCoaches.length > 0) {
    console.log("Database already seeded");
    return;
  }

  console.log("Seeding database...");

  // Create coaches
  const coachData = [
    {
      userId: "coach-1",
      name: "Sarah Martinez",
      sport: "Tennis",
      bio: "Former ATP coach with 15 years of experience. Specialized in developing junior players and advanced techniques.",
      rating: 4.9,
      hourlyRate: 150,
      location: "Dubai Marina",
      availability: ["Mon", "Wed", "Fri"],
      image: "/api/placeholder/400/400",
      certifications: ["PTR Certified", "USPTA Professional"],
      specialties: ["Singles Strategy", "Serve Technique", "Mental Game"],
    },
    {
      userId: "coach-2",
      name: "Ahmed Al-Rashid",
      sport: "Football",
      bio: "UEFA B licensed coach focusing on youth development and tactical training.",
      rating: 4.8,
      hourlyRate: 120,
      location: "Business Bay",
      availability: ["Tue", "Thu", "Sat"],
      image: "/api/placeholder/400/400",
      certifications: ["UEFA B License", "FA Youth Development"],
      specialties: ["Position Play", "Passing Drills", "Game Intelligence"],
    },
    {
      userId: "coach-3",
      name: "Maria Santos",
      sport: "Swimming",
      bio: "Olympic swimming coach specializing in freestyle and butterfly techniques.",
      rating: 5.0,
      hourlyRate: 180,
      location: "JBR",
      availability: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      image: "/api/placeholder/400/400",
      certifications: ["ASCA Level 5", "Olympic Training Center"],
      specialties: ["Freestyle", "Butterfly", "Race Strategy"],
    },
  ];

  for (const coach of coachData) {
    await storage.createCoach(coach);
  }

  // Create packages
  const packageData = [
    {
      name: "Tennis Mastery",
      description: "Complete tennis program with focus on advanced techniques",
      price: 800,
      sessions: 8,
      duration: "60 min",
      coachIds: ["coach-1"],
      features: ["Video Analysis", "Equipment Guidance", "Tournament Prep"],
    },
    {
      name: "Football Development",
      description: "Youth football training program for skill development",
      price: 600,
      sessions: 10,
      duration: "90 min",
      coachIds: ["coach-2"],
      features: ["Technical Skills", "Tactical Understanding", "Fitness Plan"],
    },
    {
      name: "Swimming Excellence",
      description: "Professional swimming coaching for all levels",
      price: 1000,
      sessions: 12,
      duration: "45 min",
      coachIds: ["coach-3"],
      features: ["Stroke Analysis", "Endurance Training", "Competition Prep"],
    },
  ];

  for (const pkg of packageData) {
    await storage.createPackage(pkg);
  }

  console.log("Database seeded successfully");
  console.log(`- ${coachData.length} coaches created`);
  console.log(`- ${packageData.length} packages created`);
}
