import type { Express, Request, Response } from "express";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertCoachSchema,
  insertClientSchema,
  insertPackageSchema,
  insertSessionSchema,
  insertMessageSchema,
  insertWalletSchema,
  insertTransactionSchema,
  insertAchievementSchema,
  insertReviewSchema,
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { z } from "zod";

// Additional validation schemas for specialized operations
const updateBalanceSchema = z.object({
  amount: z.number().int()
});

const updateStatusSchema = z.object({
  status: z.string().min(1)
});

export function registerRoutes(app: Express) {
  // ===== USER ROUTES =====
  
  // Get user by ID
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Get user by username
  app.get("/api/users/username/:username", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Create user
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const user = await storage.createUser(validation.data);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  // Update user
  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertUserSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const user = await storage.updateUser(req.params.id, validation.data);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Delete user
  app.delete("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteUser(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "User not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // ===== COACH ROUTES =====
  
  // Get all coaches
  app.get("/api/coaches", async (req: Request, res: Response) => {
    try {
      const sport = req.query.sport as string | undefined;
      const coaches = sport 
        ? await storage.getCoachesBySport(sport)
        : await storage.getAllCoaches();
      res.json(coaches);
    } catch (error) {
      res.status(500).json({ error: "Failed to get coaches" });
    }
  });

  // Get coach by ID
  app.get("/api/coaches/:id", async (req: Request, res: Response) => {
    try {
      const coach = await storage.getCoach(req.params.id);
      if (!coach) {
        return res.status(404).json({ error: "Coach not found" });
      }
      res.json(coach);
    } catch (error) {
      res.status(500).json({ error: "Failed to get coach" });
    }
  });

  // Create coach
  app.post("/api/coaches", async (req: Request, res: Response) => {
    try {
      const validation = insertCoachSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const coach = await storage.createCoach(validation.data);
      res.status(201).json(coach);
    } catch (error) {
      res.status(500).json({ error: "Failed to create coach" });
    }
  });

  // Update coach
  app.patch("/api/coaches/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertCoachSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const coach = await storage.updateCoach(req.params.id, validation.data);
      if (!coach) {
        return res.status(404).json({ error: "Coach not found" });
      }
      res.json(coach);
    } catch (error) {
      res.status(500).json({ error: "Failed to update coach" });
    }
  });

  // Delete coach
  app.delete("/api/coaches/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteCoach(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Coach not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete coach" });
    }
  });

  // ===== CLIENT ROUTES (for Coach CRM) =====
  
  // Get clients by coach
  app.get("/api/coaches/:coachId/clients", async (req: Request, res: Response) => {
    try {
      const clients = await storage.getClientsByCoach(req.params.coachId);
      res.json(clients);
    } catch (error) {
      res.status(500).json({ error: "Failed to get clients" });
    }
  });

  // Get client by ID
  app.get("/api/clients/:id", async (req: Request, res: Response) => {
    try {
      const client = await storage.getClient(req.params.id);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      res.status(500).json({ error: "Failed to get client" });
    }
  });

  // Create client
  app.post("/api/clients", async (req: Request, res: Response) => {
    try {
      const validation = insertClientSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const client = await storage.createClient(validation.data);
      res.status(201).json(client);
    } catch (error) {
      res.status(500).json({ error: "Failed to create client" });
    }
  });

  // Update client
  app.patch("/api/clients/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertClientSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const client = await storage.updateClient(req.params.id, validation.data);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      res.status(500).json({ error: "Failed to update client" });
    }
  });

  // Delete client
  app.delete("/api/clients/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteClient(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Client not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete client" });
    }
  });

  // ===== PACKAGE ROUTES =====
  
  // Get all packages
  app.get("/api/packages", async (req: Request, res: Response) => {
    try {
      const packages = await storage.getAllPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get packages" });
    }
  });

  // Get package by ID
  app.get("/api/packages/:id", async (req: Request, res: Response) => {
    try {
      const pkg = await storage.getPackage(req.params.id);
      if (!pkg) {
        return res.status(404).json({ error: "Package not found" });
      }
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ error: "Failed to get package" });
    }
  });

  // Create package
  app.post("/api/packages", async (req: Request, res: Response) => {
    try {
      const validation = insertPackageSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const pkg = await storage.createPackage(validation.data);
      res.status(201).json(pkg);
    } catch (error) {
      res.status(500).json({ error: "Failed to create package" });
    }
  });

  // Update package
  app.patch("/api/packages/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertPackageSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const pkg = await storage.updatePackage(req.params.id, validation.data);
      if (!pkg) {
        return res.status(404).json({ error: "Package not found" });
      }
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ error: "Failed to update package" });
    }
  });

  // Delete package
  app.delete("/api/packages/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deletePackage(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Package not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete package" });
    }
  });

  // ===== SESSION ROUTES =====
  
  // Get sessions by athlete
  app.get("/api/athletes/:athleteId/sessions", async (req: Request, res: Response) => {
    try {
      const sessions = await storage.getSessionsByAthlete(req.params.athleteId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to get sessions" });
    }
  });

  // Get sessions by coach
  app.get("/api/coaches/:coachId/sessions", async (req: Request, res: Response) => {
    try {
      const sessions = await storage.getSessionsByCoach(req.params.coachId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to get sessions" });
    }
  });

  // Get session by ID
  app.get("/api/sessions/:id", async (req: Request, res: Response) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to get session" });
    }
  });

  // Create session
  app.post("/api/sessions", async (req: Request, res: Response) => {
    try {
      const validation = insertSessionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const session = await storage.createSession(validation.data);
      res.status(201).json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to create session" });
    }
  });

  // Update session
  app.patch("/api/sessions/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertSessionSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const session = await storage.updateSession(req.params.id, validation.data);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  // Delete session
  app.delete("/api/sessions/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteSession(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete session" });
    }
  });

  // ===== MESSAGE ROUTES =====
  
  // Get messages for a user
  app.get("/api/users/:userId/messages", async (req: Request, res: Response) => {
    try {
      const messages = await storage.getMessagesByUser(req.params.userId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  // Get conversation between two users
  app.get("/api/conversations/:user1Id/:user2Id", async (req: Request, res: Response) => {
    try {
      const messages = await storage.getConversation(
        req.params.user1Id,
        req.params.user2Id
      );
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get conversation" });
    }
  });

  // Create message
  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const validation = insertMessageSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const message = await storage.createMessage(validation.data);
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  // Mark message as read
  app.patch("/api/messages/:id/read", async (req: Request, res: Response) => {
    try {
      const success = await storage.markMessageAsRead(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Message not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to mark message as read" });
    }
  });

  // ===== WALLET ROUTES =====
  
  // Get wallet by user ID
  app.get("/api/users/:userId/wallet", async (req: Request, res: Response) => {
    try {
      const wallet = await storage.getWallet(req.params.userId);
      if (!wallet) {
        return res.status(404).json({ error: "Wallet not found" });
      }
      res.json(wallet);
    } catch (error) {
      res.status(500).json({ error: "Failed to get wallet" });
    }
  });

  // Create wallet
  app.post("/api/wallets", async (req: Request, res: Response) => {
    try {
      const validation = insertWalletSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const wallet = await storage.createWallet(validation.data);
      res.status(201).json(wallet);
    } catch (error) {
      res.status(500).json({ error: "Failed to create wallet" });
    }
  });

  // Update wallet balance
  app.post("/api/wallets/:userId/update-balance", async (req: Request, res: Response) => {
    try {
      const validation = updateBalanceSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const wallet = await storage.updateWalletBalance(
        req.params.userId,
        validation.data.amount
      );
      if (!wallet) {
        return res.status(404).json({ error: "Wallet not found" });
      }
      res.json(wallet);
    } catch (error) {
      res.status(500).json({ error: "Failed to update wallet balance" });
    }
  });

  // ===== TRANSACTION ROUTES =====
  
  // Get transactions by wallet
  app.get("/api/wallets/:walletId/transactions", async (req: Request, res: Response) => {
    try {
      const transactions = await storage.getTransactionsByWallet(req.params.walletId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to get transactions" });
    }
  });

  // Create transaction
  app.post("/api/transactions", async (req: Request, res: Response) => {
    try {
      const validation = insertTransactionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const transaction = await storage.createTransaction(validation.data);
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  // Update transaction status
  app.patch("/api/transactions/:id/status", async (req: Request, res: Response) => {
    try {
      const validation = updateStatusSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const transaction = await storage.updateTransactionStatus(
        req.params.id,
        validation.data.status
      );
      if (!transaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ error: "Failed to update transaction status" });
    }
  });

  // ===== ACHIEVEMENT ROUTES =====
  
  // Get achievements by user
  app.get("/api/users/:userId/achievements", async (req: Request, res: Response) => {
    try {
      const achievements = await storage.getAchievementsByUser(req.params.userId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to get achievements" });
    }
  });

  // Create achievement
  app.post("/api/achievements", async (req: Request, res: Response) => {
    try {
      const validation = insertAchievementSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const achievement = await storage.createAchievement(validation.data);
      res.status(201).json(achievement);
    } catch (error) {
      res.status(500).json({ error: "Failed to create achievement" });
    }
  });

  // Unlock achievement
  app.patch("/api/achievements/:id/unlock", async (req: Request, res: Response) => {
    try {
      const achievement = await storage.unlockAchievement(req.params.id);
      if (!achievement) {
        return res.status(404).json({ error: "Achievement not found" });
      }
      res.json(achievement);
    } catch (error) {
      res.status(500).json({ error: "Failed to unlock achievement" });
    }
  });

  // Update achievement
  app.patch("/api/achievements/:id", async (req: Request, res: Response) => {
    try {
      const validation = insertAchievementSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const achievement = await storage.updateAchievement(req.params.id, validation.data);
      if (!achievement) {
        return res.status(404).json({ error: "Achievement not found" });
      }
      res.json(achievement);
    } catch (error) {
      res.status(500).json({ error: "Failed to update achievement" });
    }
  });

  // ===== REVIEW ROUTES =====
  
  // Get reviews by coach
  app.get("/api/coaches/:coachId/reviews", async (req: Request, res: Response) => {
    try {
      const reviews = await storage.getReviewsByCoach(req.params.coachId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: "Failed to get reviews" });
    }
  });

  // Create review
  app.post("/api/reviews", async (req: Request, res: Response) => {
    try {
      const validation = insertReviewSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: fromZodError(validation.error).toString() 
        });
      }
      const review = await storage.createReview(validation.data);
      res.status(201).json(review);
    } catch (error) {
      res.status(500).json({ error: "Failed to create review" });
    }
  });
}
