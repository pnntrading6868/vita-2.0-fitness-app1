# Coach Client Detail Screen Guide

## Overview
The Client Detail screen is a comprehensive performance lab and communication hub that coaches access by clicking any client card from their dashboard. It visualizes progress, session history, and AI analysis in a clean, futuristic athletic interface.

## Design Philosophy
**Precision > Clutter**

Data should feel alive, not spreadsheet-like. Every element tells a story of improvement and connection.

---

## Screen Sections

### 1️⃣ Header Section – Client Snapshot
**Location**: Top of screen

**Components**:
- **Profile Avatar**: 24x24 rounded image with Flow Index badge overlay
- **Client Info**:
  - Name (large, prominent)
  - Location with flag emoji (🇻🇳 Ho Chi Minh City)
  - Training focus tag ("Boxing & Core Stability")
  - Flow Index badge (neon-lime, numeric: "72")
  - Status chip: "Active" / "Rest Week" / "Rehab Phase"

- **Summary Stats Grid** (3 cards):
  - 📅 **124 Sessions**
  - ⏰ **186 Hours**
  - 🔥 **21-Day Streak**

**Visual Treatment**: Gradient background card with white/10 border, stats in individual sub-cards

---

### 2️⃣ Performance Overview Section
**Components**:

#### Charts (Side-by-side on desktop)
1. **Line Chart**: "Flow Index Over Time"
   - Shows 6-week progression
   - Neon-lime line (#c6ff00)
   - Smooth transitions

2. **Bar Chart**: "Session Attendance (Last 4 Weeks)"
   - Weekly session count
   - Blue bars (#00d9ff)

#### Metrics Grid (4 circular mini-widgets)
Each widget shows:
- Metric name (Speed / Power / Endurance / Technique)
- Percentage value (0-100%)
- Change indicator (e.g., "+7%")
- Color-coded progress bar
- Subtle glowing background accent

**Colors**:
- Speed: #c6ff00 (lime)
- Power: #00d9ff (blue)
- Endurance: #ff00d9 (magenta)
- Technique: #ffa500 (orange)

#### AI Insight Card
- Gradient background (lime tint)
- TrendingUp icon
- Example: "Speed improved +7%, technique +5%. Suggest 2 more sparring drills this week."

---

### 3️⃣ Session History Section
**Features**:
- Filter tabs: All / Completed / Missed / Upcoming
- Scrollable list (last 5-10 sessions)
- Accordion-style expandable entries

**Each Session Card Shows**:
- Sport emoji (🥊, 🧘, 💪, 🏃)
- Date (e.g., "29 Oct")
- Session title
- Status badge:
  - ✅ Completed (lime green)
  - ❌ Skipped (orange)
- Rating (e.g., "9/10")

**Expanded View Shows**:
- Duration
- Coach notes/feedback
- Optional: Attached clips (future feature)

**Visual Treatment**: Cards with hover states, smooth expand/collapse animations

---

### 4️⃣ Coach Notes & Feedback Section
**Components**:

#### Add New Note
- Multi-line text area
- "Share with client" toggle switch
- "Add Note" button (lime CTA)

#### Past Feedback Cards
Each card displays:
- Date tag
- Note content
- Visibility badge:
  - "Shared" (lime badge with share icon)
  - "Private" (gray badge)

**Use Cases**:
- Private coaching observations
- Feedback shared with clients
- Session-specific notes
- Progress tracking

---

### 5️⃣ Client Goals Section
**Right sidebar component**

Shows current objectives as horizontal cards:
- Goal title with target icon
- Progress percentage
- Visual progress bar
- Status label

**Example Goals**:
- "Master defensive movement (70% progress)"
- "Improve 3-round stamina (45%)"
- "Maintain consistency streak (Active 🔥)"

**Visual Treatment**: Individual cards with lime progress bars

---

### 6️⃣ Communication Section (Mini Chat Panel)
**Right sidebar component**

**Features**:
- Last 2-3 messages preview
- Color-coded bubbles:
  - Coach messages: Lime background (#c6ff00)
  - Client messages: Dark background with border
- Timestamp on each message
- "Open Full Chat" button → Links to full messaging

**Example**:
```
Coach: Great session today. Footwork much sharper!
Client: Thanks! Will drill it again tomorrow 👊
```

---

### 7️⃣ Action Bar (Sticky Footer)
**Location**: Fixed to bottom of screen

**Three Primary Buttons** (evenly spaced):
1. **Schedule Next Session** (Calendar icon, lime background)
2. **Add Progress Note** (Edit icon, transparent with border)
3. **Send Message** (Send icon, transparent with border)

**Effects**:
- Neon-lime glow on hover
- Smooth transitions
- Safe area padding for mobile

---

## Design System

### Color Palette
| Element | Color | Usage |
|---------|-------|-------|
| Background | #0A0A0A | Main screen |
| Card Background | #0f0f0f → #1a1a1a | Gradient cards |
| Primary Accent | #c6ff00 | CTAs, highlights |
| Speed Metric | #c6ff00 | Progress bar |
| Power Metric | #00d9ff | Progress bar |
| Endurance Metric | #ff00d9 | Progress bar |
| Technique Metric | #ffa500 | Progress bar |
| Text Primary | #ffffff | Headers |
| Text Secondary | #ffffff/60 | Body text |
| Borders | #ffffff/10 | Card borders |

### Typography
- **Font**: Poppins / Inter SemiBold
- **Logo**: VITΛ with light weight (200)
- **Headings**: Text-xl to text-3xl
- **Body**: Text-sm to text-base
- **Metrics**: Text-2xl for emphasis

### Spacing & Layout
- **Card Radius**: 20-24px
- **Padding**: 4-6 units (16-24px)
- **Gap**: 3-6 units between elements
- **Grid**: 1 column mobile, 3-column desktop (2 main + 1 sidebar)

### Effects
- **Shadows**: Soft drop shadows on cards
- **Glow**: Neon-lime glow on hover states
- **Blur**: Backdrop blur on sticky header/footer
- **Animations**:
  - Chart transitions
  - Accordion expand/collapse
  - Progress bar fills
  - Status badge pulse

---

## Navigation Flow

```
Coach Dashboard
    ↓ (Click client card)
Client Detail Screen
    ↓ (Click "Back to Dashboard")
Coach Dashboard
```

### Entry Points
1. Click any client card from "Your Clients" section on dashboard
2. Each card is clickable with hover state (lime border glow)

### Exit Points
1. "Back to Dashboard" button (top-left)
2. Action bar buttons may navigate to other screens (future)

---

## Mock Data Structure

### Client Profile
```typescript
{
  name: "Huy Nguyen",
  location: "🇻🇳 Ho Chi Minh City",
  trainingFocus: "Boxing & Core Stability",
  flowIndex: 72,
  totalSessions: 124,
  totalHours: 186,
  currentStreak: 21,
  status: "Active" | "Rest Week" | "Rehab Phase",
  image: "url"
}
```

### Performance Metrics
```typescript
{
  name: "Speed",
  value: 78,
  change: "+7%",
  color: "#c6ff00"
}
```

### Session Entry
```typescript
{
  date: "29 Oct",
  sport: "Boxing",
  emoji: "🥊",
  title: "Boxing Drills",
  status: "completed" | "skipped" | "upcoming",
  rating: 9,
  notes: "Excellent footwork today...",
  duration: "60 min"
}
```

---

## Responsive Design

### Desktop (1024px+)
- 3-column layout (2 main + 1 sidebar)
- Side-by-side charts
- 4-column metrics grid
- Full-width action bar

### Tablet (768px - 1023px)
- 2-column layout
- Stacked charts
- 2-column metrics grid
- Full-width action bar

### Mobile (<768px)
- Single column
- Stacked everything
- Icon-only action buttons
- Collapsible sections

---

## Technical Implementation

### Files
- `/components/ClientDetail.tsx` - Main component
- `/components/CoachDashboard.tsx` - Updated with navigation
- `/App.tsx` - Routing logic

### Dependencies
- **Recharts**: Line and bar charts
- **Lucide React**: Icons
- **Tailwind CSS**: Styling
- **ShadCN UI**: Progress bars, Switch, Textarea

### State Management
```typescript
const [expandedSession, setExpandedSession] = useState<number | null>(null);
const [sessionFilter, setSessionFilter] = useState<"all" | "completed" | "missed" | "upcoming">("all");
const [newNote, setNewNote] = useState("");
const [shareNewNote, setShareNewNote] = useState(false);
```

---

## Future Enhancements

### Planned Features
- [ ] Video playback for session clips
- [ ] Real-time chat integration
- [ ] Goal creation/editing
- [ ] Export client report (PDF)
- [ ] Calendar integration for scheduling
- [ ] Payment history
- [ ] Exercise library with assignments
- [ ] Nutrition tracking
- [ ] Wearable data integration
- [ ] Progress photo gallery
- [ ] Injury tracking
- [ ] Custom metric creation

### API Integration Points
- Client profile data
- Performance metrics
- Session history
- Chat messages
- Goals and progress
- Notes and feedback

---

## User Experience Goals

### For Coaches
1. **Instant Insight**: See client status at a glance
2. **Data-Driven**: Make informed coaching decisions
3. **Efficient Communication**: Quick message access
4. **Progress Tracking**: Visual representation of improvement
5. **Actionable**: Clear next steps via AI insights

### For Clients (Indirect)
1. Coaches can provide better guidance
2. Transparent progress sharing
3. Consistent communication
4. Goal-oriented training
5. Motivational feedback

---

## Design Inspiration
- Performance lab aesthetics
- Athletic dashboard UI
- Futuristic data visualization
- Human connection emphasis
- Premium fitness app standards

**Goal**: Create a hybrid performance lab + human connection point where coaches instantly understand client status and know what to do next — all without friction.

---

## Accessibility

- High contrast text (white on dark)
- Clear status indicators
- Keyboard navigation support
- Screen reader friendly labels
- Touch-friendly tap targets (44x44px minimum)
- Color is not the only indicator (icons + text)

---

## Performance Considerations

- Lazy load session history
- Optimized chart rendering
- Image optimization
- Smooth animations (60fps)
- Debounced search/filters
- Cached client data

---

**Last Updated**: November 2, 2025
**Version**: 1.0
**Status**: ✅ Implemented
