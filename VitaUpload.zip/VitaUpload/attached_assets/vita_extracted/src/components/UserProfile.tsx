import { ArrowLeft, MapPin, Calendar, Trophy, Star, Users, Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, UserPlus, Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export interface UserProfileData {
  id: string;
  name: string;
  username: string;
  avatar: string;
  coverImage: string;
  bio: string;
  location: string;
  memberSince: string;
  isCoach: boolean;
  verified: boolean;
  stats: {
    followers: number;
    following: number;
    posts: number;
    sessions: number;
  };
  sports: string[];
  coaches: {
    id: string;
    name: string;
    avatar: string;
    sport: string;
    sessionCount: number;
  }[];
  posts: {
    id: string;
    text: string;
    image?: string;
    sport?: string;
    workout?: {
      duration: string;
      distance?: string;
      calories?: number;
    };
    stats: {
      likes: number;
      comments: number;
      shares: number;
    };
    timestamp: string;
    liked: boolean;
    bookmarked: boolean;
  }[];
  achievements: {
    title: string;
    icon: string;
    unlocked: boolean;
  }[];
}

interface UserProfileProps {
  userData: UserProfileData;
  onClose: () => void;
  onLikePost: (postId: string) => void;
  onBookmarkPost: (postId: string) => void;
}

export function UserProfile({ userData, onClose, onLikePost, onBookmarkPost }: UserProfileProps) {
  return (
    <div className="fixed inset-0 z-50 bg-[#0f0f0f] animate-fade-in overflow-y-auto">
      <div className="max-w-md mx-auto pb-20">
        {/* Header with Back Button */}
        <div className="sticky top-0 z-10 bg-[#0f0f0f]/80 backdrop-blur-xl border-b border-white/10">
          <div className="px-5 py-4 flex items-center gap-4">
            <button
              onClick={onClose}
              className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all duration-200"
            >
              <ArrowLeft className="w-5 h-5 text-white" strokeWidth={2} />
            </button>
            <div className="flex-1">
              <h2 className="text-white tracking-tight">{userData.name}</h2>
              <p className="text-white/40 text-sm">{userData.posts.length} posts</p>
            </div>
          </div>
        </div>

        {/* Cover Image */}
        <div className="relative h-48">
          <ImageWithFallback
            src={userData.coverImage}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0f0f0f]" />
        </div>

        {/* Profile Info */}
        <div className="px-5 -mt-16 relative">
          {/* Avatar */}
          <div className="relative inline-block mb-4">
            <div className="w-28 h-28 rounded-full border-4 border-[#0f0f0f] overflow-hidden bg-[#1a1a1a]">
              <ImageWithFallback
                src={userData.avatar}
                alt={userData.name}
                className="w-full h-full object-cover"
              />
            </div>
            {userData.isCoach && (
              <div className="absolute bottom-0 right-0 w-9 h-9 bg-[#c6ff00] rounded-full flex items-center justify-center border-4 border-[#0f0f0f]">
                <Trophy className="w-5 h-5 text-black" strokeWidth={2.5} />
              </div>
            )}
          </div>

          {/* Name & Actions */}
          <div className="mb-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-white">{userData.name}</h1>
                  {userData.verified && (
                    <div className="w-5 h-5 bg-[#c6ff00] rounded-full flex items-center justify-center">
                      <Check className="w-3 h-3 text-black" strokeWidth={3} />
                    </div>
                  )}
                </div>
                <p className="text-white/60 text-sm">{userData.username}</p>
              </div>
              <button className="px-6 py-2.5 bg-[#c6ff00] hover:bg-[#b5e600] rounded-xl text-black transition-all duration-200 flex items-center gap-2">
                <UserPlus className="w-4 h-4" strokeWidth={2.5} />
                Follow
              </button>
            </div>

            {/* Bio */}
            <p className="text-white/70 text-sm mb-3 leading-relaxed">{userData.bio}</p>

            {/* Location & Member Since */}
            <div className="flex items-center gap-4 text-sm text-white/60 mb-4">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4" strokeWidth={2} />
                <span>{userData.location}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" strokeWidth={2} />
                <span>Joined {userData.memberSince}</span>
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 text-sm">
              <div>
                <span className="text-white">{userData.stats.followers}</span>
                <span className="text-white/40 ml-1">Followers</span>
              </div>
              <div>
                <span className="text-white">{userData.stats.following}</span>
                <span className="text-white/40 ml-1">Following</span>
              </div>
              <div>
                <span className="text-white">{userData.stats.sessions}</span>
                <span className="text-white/40 ml-1">Sessions</span>
              </div>
            </div>
          </div>

          {/* Sports Tags */}
          {userData.sports.length > 0 && (
            <div className="mb-5 pb-5 border-b border-white/10">
              <h3 className="text-white text-sm mb-3">Training Focus</h3>
              <div className="flex flex-wrap gap-2">
                {userData.sports.map((sport, index) => (
                  <div
                    key={index}
                    className="px-3 py-1.5 bg-[#c6ff00]/10 border border-[#c6ff00]/30 rounded-full text-[#c6ff00] text-xs"
                  >
                    {sport}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Coaches */}
          {userData.coaches.length > 0 && (
            <div className="mb-5 pb-5 border-b border-white/10">
              <h3 className="text-white mb-3">Training With</h3>
              <div className="space-y-3">
                {userData.coaches.map((coach) => (
                  <div
                    key={coach.id}
                    className="bg-[#1a1a1a] border border-white/10 rounded-[20px] p-4 flex items-center gap-3"
                  >
                    <div className="relative">
                      <ImageWithFallback
                        src={coach.avatar}
                        alt={coach.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#c6ff00] rounded-full flex items-center justify-center border-2 border-[#1a1a1a]">
                        <Trophy className="w-3 h-3 text-black" strokeWidth={3} />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white tracking-tight">{coach.name}</h4>
                      <p className="text-sm text-white/40">{coach.sport}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-[#c6ff00] text-sm">{coach.sessionCount}</div>
                      <div className="text-white/40 text-xs">sessions</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Achievements */}
          {userData.achievements.length > 0 && (
            <div className="mb-5 pb-5 border-b border-white/10">
              <h3 className="text-white mb-3">Achievements</h3>
              <div className="grid grid-cols-3 gap-3">
                {userData.achievements.map((achievement, index) => (
                  <div
                    key={index}
                    className={`bg-[#1a1a1a] border ${
                      achievement.unlocked ? "border-[#c6ff00]/30" : "border-white/10"
                    } rounded-[20px] p-4 text-center`}
                  >
                    <div className={`w-12 h-12 mx-auto mb-2 rounded-full flex items-center justify-center ${
                      achievement.unlocked ? "bg-[#c6ff00]/20" : "bg-white/5"
                    }`}>
                      {achievement.icon === "trophy" && (
                        <Trophy className={`w-6 h-6 ${achievement.unlocked ? "text-[#c6ff00]" : "text-white/30"}`} strokeWidth={2} />
                      )}
                      {achievement.icon === "star" && (
                        <Star className={`w-6 h-6 ${achievement.unlocked ? "text-[#c6ff00]" : "text-white/30"}`} strokeWidth={2} />
                      )}
                      {achievement.icon === "users" && (
                        <Users className={`w-6 h-6 ${achievement.unlocked ? "text-[#c6ff00]" : "text-white/30"}`} strokeWidth={2} />
                      )}
                    </div>
                    <p className={`text-xs ${achievement.unlocked ? "text-white" : "text-white/40"}`}>
                      {achievement.title}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Posts */}
          <div>
            <h3 className="text-white mb-4">Posts</h3>
            <div className="space-y-4">
              {userData.posts.map((post) => (
                <div
                  key={post.id}
                  className="bg-[#1a1a1a] border border-white/10 rounded-[20px] overflow-hidden"
                >
                  {/* Post Text */}
                  <div className="p-4">
                    <p className="text-white/90 text-sm leading-relaxed mb-2">{post.text}</p>
                    {post.sport && (
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#c6ff00]/10 border border-[#c6ff00]/30 rounded-full">
                        <div className="w-1.5 h-1.5 bg-[#c6ff00] rounded-full"></div>
                        <span className="text-xs text-[#c6ff00]">{post.sport}</span>
                      </div>
                    )}
                  </div>

                  {/* Post Image */}
                  {post.image && (
                    <div className="relative h-64">
                      <ImageWithFallback
                        src={post.image}
                        alt="Post"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  {/* Workout Stats */}
                  {post.workout && (
                    <div className="px-4 py-3 bg-[#0f0f0f]/50 flex items-center gap-4 text-xs text-white/60">
                      <div className="flex items-center gap-1.5">
                        <div className="w-1 h-1 bg-[#c6ff00] rounded-full"></div>
                        <span>{post.workout.duration}</span>
                      </div>
                      {post.workout.distance && (
                        <div className="flex items-center gap-1.5">
                          <div className="w-1 h-1 bg-[#c6ff00] rounded-full"></div>
                          <span>{post.workout.distance}</span>
                        </div>
                      )}
                      {post.workout.calories && (
                        <div className="flex items-center gap-1.5">
                          <div className="w-1 h-1 bg-[#c6ff00] rounded-full"></div>
                          <span>{post.workout.calories} cal</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Post Actions */}
                  <div className="px-4 py-3 border-t border-white/10">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-6">
                        <button
                          onClick={() => onLikePost(post.id)}
                          className="flex items-center gap-2 group"
                        >
                          <Heart
                            className={`w-5 h-5 transition-all duration-200 ${
                              post.liked
                                ? "text-red-500 fill-red-500"
                                : "text-white/60 group-hover:text-white"
                            }`}
                            strokeWidth={2}
                          />
                          <span className={`text-sm ${post.liked ? "text-red-500" : "text-white/60"}`}>
                            {post.stats.likes}
                          </span>
                        </button>

                        <button className="flex items-center gap-2 group">
                          <MessageCircle className="w-5 h-5 text-white/60 group-hover:text-white transition-colors duration-200" strokeWidth={2} />
                          <span className="text-sm text-white/60">{post.stats.comments}</span>
                        </button>

                        <button className="flex items-center gap-2 group">
                          <Share2 className="w-5 h-5 text-white/60 group-hover:text-white transition-colors duration-200" strokeWidth={2} />
                          <span className="text-sm text-white/60">{post.stats.shares}</span>
                        </button>
                      </div>

                      <button
                        onClick={() => onBookmarkPost(post.id)}
                        className="group"
                      >
                        <Bookmark
                          className={`w-5 h-5 transition-all duration-200 ${
                            post.bookmarked
                              ? "text-[#c6ff00] fill-[#c6ff00]"
                              : "text-white/60 group-hover:text-white"
                          }`}
                          strokeWidth={2}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Timestamp */}
                  <div className="px-4 pb-3">
                    <p className="text-xs text-white/40">{post.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
