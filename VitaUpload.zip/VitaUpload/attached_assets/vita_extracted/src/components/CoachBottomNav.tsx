import {
  LayoutDashboard,
  Users,
  Calendar,
  Package,
  Sparkles,
  Library,
  User,
} from "lucide-react";

interface CoachBottomNavProps {
  activeTab: "dashboard" | "clients" | "sessions" | "packages" | "ai" | "library" | "profile";
  onTabChange: (tab: "dashboard" | "clients" | "sessions" | "packages" | "ai" | "library" | "profile") => void;
}

export function CoachBottomNav({ activeTab, onTabChange }: CoachBottomNavProps) {
  const tabs = [
    { id: "dashboard" as const, icon: LayoutDashboard, label: "Dashboard" },
    { id: "clients" as const, icon: Users, label: "Clients" },
    { id: "sessions" as const, icon: Calendar, label: "Sessions" },
    { id: "packages" as const, icon: Package, label: "Packages" },
    { id: "ai" as const, icon: Sparkles, label: "AI Assistant" },
    { id: "library" as const, icon: Library, label: "Library" },
    { id: "profile" as const, icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#0f0f0f]/95 backdrop-blur-xl border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-around px-2 py-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-xl transition-all duration-300 ${
                  isActive
                    ? "bg-[#c6ff00]/20 text-[#c6ff00]"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? "scale-110" : ""} transition-transform`} />
                <span className="text-[10px]">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      {/* Safe area for mobile devices */}
      <div className="h-[env(safe-area-inset-bottom,0px)] bg-[#0f0f0f]/95" />
    </div>
  );
}
