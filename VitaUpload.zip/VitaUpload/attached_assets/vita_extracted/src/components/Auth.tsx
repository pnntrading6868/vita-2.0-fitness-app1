import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import authBgImage from "figma:asset/10d8c91efff2015948983cdbe885bb2e0535e10c.png";

interface AuthProps {
  onSignUpUser: () => void;
  onSignUpCoach: () => void;
  onLogin: () => void;
}

export function Auth({ onSignUpUser, onSignUpCoach, onLogin }: AuthProps) {
  const [showForm, setShowForm] = useState(false);
  const [userType, setUserType] = useState<"athlete" | "coach">("athlete");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleUserTypeSelect = (type: "athlete" | "coach") => {
    setUserType(type);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userType === "athlete") {
      onSignUpUser();
    } else {
      onSignUpCoach();
    }
  };

  const handleBack = () => {
    setShowForm(false);
    setFormData({
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
    });
  };

  return (
    <div className="min-h-screen w-screen bg-[#0f0f0f] relative overflow-auto">
      {/* Hero Background Image */}
      <div className="fixed inset-0 z-0">
        <img 
          src={authBgImage}
          alt="Professional volleyball athlete"
          className="w-full h-full object-cover object-center opacity-70"
        />
        {/* Subtle gradient for text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {!showForm ? (
          // Initial View - Logo + CTA Buttons
          <>
            {/* Logo Section */}
            <div className="flex-1 flex flex-col items-center justify-center px-5 pt-20 pb-10">
              <div className="text-center">
                <h1 
                  className="text-white text-7xl md:text-8xl tracking-[0.15em] drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] mb-6" 
                  style={{ fontWeight: 200 }}
                >
                  VIT<span className="inline-block scale-x-[-1] -ml-[0.08em]">Λ</span>
                </h1>
                <h2 className="text-white text-2xl md:text-3xl mb-4 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  Join the Tribe. Start Your Journey.
                </h2>
                <p className="text-white/70 max-w-md mx-auto leading-relaxed drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  Sign up to access expert coaches, personalized programs, and your fitness community.
                </p>
              </div>
            </div>

            {/* CTA Section */}
            <div className="max-w-md mx-auto w-full px-5 pb-20 space-y-4">
              {/* Sign Up as Athlete */}
              <button
                onClick={() => handleUserTypeSelect("athlete")}
                className="w-full bg-[#c6ff00] hover:bg-[#b8f000] text-black py-5 rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
              >
                <span className="tracking-wide">Sign Up as Athlete</span>
                <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
              </button>

              {/* Sign Up as Coach */}
              <button
                onClick={() => handleUserTypeSelect("coach")}
                className="w-full bg-white/10 hover:bg-white/[0.15] backdrop-blur-md text-white py-5 rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 border-2 border-white/20 shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
              >
                <span className="tracking-wide">Sign Up as Coach</span>
                <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
              </button>

              {/* Login Link */}
              <div className="text-center pt-4">
                <button
                  onClick={onLogin}
                  className="text-white/60 hover:text-[#c6ff00] transition-colors duration-300"
                >
                  Already have an account?{" "}
                  <span className="underline underline-offset-4">Log in</span>
                </button>
              </div>
            </div>
          </>
        ) : (
          // Form View
          <div className="flex-1 flex items-center justify-center px-5 py-12">
            <div className="max-w-md w-full">
              {/* Logo - Smaller */}
              <div className="text-center mb-8">
                <h1 
                  className="text-white text-4xl tracking-[0.15em] drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]" 
                  style={{ fontWeight: 200 }}
                >
                  VIT<span className="inline-block scale-x-[-1] -ml-[0.08em]">Λ</span>
                </h1>
              </div>

              {/* Form Card */}
              <div className="bg-[#1a1a1a]/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10">
                {/* Back Button */}
                <button
                  onClick={handleBack}
                  className="text-white/60 hover:text-white transition-colors mb-6 flex items-center gap-2"
                >
                  <ArrowRight className="w-4 h-4 rotate-180" />
                  Back
                </button>

                {/* Headlines */}
                <div className="mb-6 text-center">
                  <h2 className="text-white text-2xl mb-2">
                    Sign Up as {userType === "athlete" ? "Athlete" : "Coach"}
                  </h2>
                  <p className="text-white/60">
                    Create your account to get started
                  </p>
                </div>

                {/* Sign Up Form */}
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Full Name */}
                  <div className="space-y-2">
                    <Label htmlFor="fullName" className="text-white/80">
                      Full Name
                    </Label>
                    <Input
                      id="fullName"
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="Enter your full name"
                      className="bg-[#0f0f0f]/50 border-white/10 text-white placeholder:text-white/30 rounded-xl h-12 focus:border-[#c6ff00] focus:ring-[#c6ff00]/20"
                      required
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white/80">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Enter your email"
                      className="bg-[#0f0f0f]/50 border-white/10 text-white placeholder:text-white/30 rounded-xl h-12 focus:border-[#c6ff00] focus:ring-[#c6ff00]/20"
                      required
                    />
                  </div>

                  {/* Password */}
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-white/80">
                      Password
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="Create a password"
                      className="bg-[#0f0f0f]/50 border-white/10 text-white placeholder:text-white/30 rounded-xl h-12 focus:border-[#c6ff00] focus:ring-[#c6ff00]/20"
                      required
                    />
                  </div>

                  {/* Confirm Password */}
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-white/80">
                      Confirm Password
                    </Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      placeholder="Confirm your password"
                      className="bg-[#0f0f0f]/50 border-white/10 text-white placeholder:text-white/30 rounded-xl h-12 focus:border-[#c6ff00] focus:ring-[#c6ff00]/20"
                      required
                    />
                  </div>

                  {/* Create Account Button */}
                  <button
                    type="submit"
                    className="w-full bg-[#c6ff00] hover:bg-[#b8f000] text-black py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] mt-6"
                  >
                    <span className="tracking-wide">Create Account</span>
                    <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
                  </button>

                  {/* Terms */}
                  <p className="text-white/40 text-center text-sm leading-relaxed pt-2">
                    By signing up, you agree to our{" "}
                    <span className="text-white/60 hover:text-[#c6ff00] cursor-pointer transition-colors">
                      Terms of Service
                    </span>{" "}
                    and{" "}
                    <span className="text-white/60 hover:text-[#c6ff00] cursor-pointer transition-colors">
                      Privacy Policy
                    </span>
                    .
                  </p>
                </form>

                {/* Divider */}
                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/10"></div>
                  </div>
                  <div className="relative flex justify-center">
                    <span className="bg-[#1a1a1a] px-4 text-white/40">or continue with</span>
                  </div>
                </div>

                {/* Social Sign-up */}
                <div className="space-y-3">
                  <button
                    type="button"
                    className="w-full bg-white/10 hover:bg-white/[0.15] backdrop-blur-md text-white py-3.5 rounded-xl transition-all duration-300 border border-white/20 shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
                  >
                    Continue with Google
                  </button>
                  <button
                    type="button"
                    className="w-full bg-white/10 hover:bg-white/[0.15] backdrop-blur-md text-white py-3.5 rounded-xl transition-all duration-300 border border-white/20 shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
                  >
                    Continue with Apple
                  </button>
                </div>

                {/* Login Link */}
                <div className="text-center pt-6">
                  <button
                    type="button"
                    onClick={onLogin}
                    className="text-white/60 hover:text-[#c6ff00] transition-colors duration-300"
                  >
                    Already have an account?{" "}
                    <span className="underline underline-offset-4">Log in</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Safe Area Bottom Spacer */}
        <div className="h-[env(safe-area-inset-bottom,20px)]" />
      </div>
    </div>
  );
}