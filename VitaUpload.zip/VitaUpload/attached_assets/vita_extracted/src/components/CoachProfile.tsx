import {
  User,
  Mail,
  Phone,
  MapPin,
  Award,
  DollarSign,
  Calendar,
  LogOut,
  Edit,
  Camera,
  Settings as SettingsIcon,
  Bell,
  Globe,
} from "lucide-react";

interface CoachProfileProps {
  onLogout: () => void;
}

export function CoachProfile({ onLogout }: CoachProfileProps) {
  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <h1 className="text-white text-2xl">Profile & Settings</h1>
          <p className="text-white/60 text-sm mt-1">Manage your account and preferences</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-5 py-6 space-y-6">
        {/* Profile Header */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <div className="flex items-start gap-5">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop"
                alt="Coach Profile"
                className="w-24 h-24 rounded-2xl object-cover"
              />
              <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-[#c6ff00] hover:bg-[#b8f000] rounded-xl flex items-center justify-center transition-colors">
                <Camera className="w-5 h-5 text-black" />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-white text-2xl mb-1">Coach Marcus</h2>
              <p className="text-white/60 mb-3">Professional Boxing & Fitness Coach</p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded-full text-sm">
                  Premium Coach
                </span>
                <span className="px-3 py-1 bg-white/5 text-white/60 rounded-full text-sm">
                  Verified
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Personal Information */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-white text-xl">Personal Information</h3>
            <button className="p-2 hover:bg-white/5 rounded-lg transition-colors">
              <Edit className="w-4 h-4 text-white/60" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <User className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Full Name</p>
                <p className="text-white">Marcus Johnson</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Email</p>
                <p className="text-white">marcus.j@vita.app</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Phone</p>
                <p className="text-white">+84 90 123 4567</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Location</p>
                <p className="text-white">Ho Chi Minh City, Vietnam</p>
              </div>
            </div>
          </div>
        </div>

        {/* Certifications */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-white text-xl">Certifications</h3>
            <button className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors">
              Add Certificate
            </button>
          </div>

          <div className="space-y-3">
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 flex items-center gap-3">
              <Award className="w-5 h-5 text-[#c6ff00]" />
              <div className="flex-1">
                <p className="text-white">Certified Boxing Trainer</p>
                <p className="text-white/60 text-sm">WBC Professional Certification</p>
              </div>
              <span className="px-2 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
                Verified
              </span>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 flex items-center gap-3">
              <Award className="w-5 h-5 text-[#c6ff00]" />
              <div className="flex-1">
                <p className="text-white">Personal Training Certificate</p>
                <p className="text-white/60 text-sm">ACE Certified</p>
              </div>
              <span className="px-2 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
                Verified
              </span>
            </div>
          </div>
        </div>

        {/* Business Settings */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <h3 className="text-white text-xl mb-5">Business Settings</h3>

          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white/60" />
              </div>
              <div className="flex-1">
                <p className="text-white">Payout Method</p>
                <p className="text-white/60 text-sm">Bank Account •••• 4532</p>
              </div>
              <button className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors">
                Edit
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white/60" />
              </div>
              <div className="flex-1">
                <p className="text-white">Availability</p>
                <p className="text-white/60 text-sm">Mon-Fri: 6AM-8PM</p>
              </div>
              <button className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors">
                Edit
              </button>
            </div>
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <h3 className="text-white text-xl mb-5">App Settings</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-white/60" />
                <div>
                  <p className="text-white">Push Notifications</p>
                  <p className="text-white/60 text-sm">Session reminders and updates</p>
                </div>
              </div>
              <div className="w-12 h-6 bg-[#c6ff00] rounded-full p-1 cursor-pointer">
                <div className="w-4 h-4 bg-black rounded-full ml-auto" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-white/60" />
                <div>
                  <p className="text-white">Language</p>
                  <p className="text-white/60 text-sm">English (US)</p>
                </div>
              </div>
              <button className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors">
                Change
              </button>
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full px-6 py-4 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl border border-red-500/20 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
