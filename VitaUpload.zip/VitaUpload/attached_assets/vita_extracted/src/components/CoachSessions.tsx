import { useState } from "react";
import {
  Calendar as CalendarIcon,
  List,
  Plus,
  Clock,
  MapPin,
  User,
  CheckCircle,
  XCircle,
  AlertCircle,
  Filter,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Calendar } from "./ui/calendar";

interface CoachSessionsProps {
  onClientSelect?: (clientId: string) => void;
}

const sessions = [
  {
    id: 1,
    clientName: "Huy Nguyen",
    clientImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    sport: "Boxing",
    emoji: "🥊",
    date: "2025-11-02",
    time: "09:00 AM",
    duration: "60 min",
    location: "VITA Studio - District 1",
    status: "upcoming",
    notes: "Focus on defensive techniques",
  },
  {
    id: 2,
    clientName: "Linh Tran",
    clientImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    sport: "Yoga",
    emoji: "🧘",
    date: "2025-11-02",
    time: "11:00 AM",
    duration: "45 min",
    location: "Client's Home",
    status: "upcoming",
    notes: "Flexibility and relaxation",
  },
  {
    id: 3,
    clientName: "Mai Pham",
    clientImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop",
    sport: "Boxing",
    emoji: "🥊",
    date: "2025-11-02",
    time: "02:00 PM",
    duration: "90 min",
    location: "VITA Studio - District 1",
    status: "upcoming",
    notes: "Sparring practice",
  },
  {
    id: 4,
    clientName: "Huy Nguyen",
    clientImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    sport: "Boxing",
    emoji: "🥊",
    date: "2025-11-01",
    time: "09:00 AM",
    duration: "60 min",
    location: "VITA Studio - District 1",
    status: "completed",
    notes: "Great session - improved footwork",
  },
  {
    id: 5,
    clientName: "Khoa Le",
    clientImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    sport: "Strength",
    emoji: "💪",
    date: "2025-10-28",
    time: "10:00 AM",
    duration: "60 min",
    location: "VITA Gym - District 3",
    status: "missed",
    notes: "Client did not show up",
  },
];

const aiSuggestions = [
  {
    day: "Friday",
    date: "2025-11-05",
    slots: ["10:00 AM", "02:00 PM", "04:00 PM"],
    suggestedClients: ["Khoa Le", "Duc Phan"],
  },
];

export function CoachSessions({ onClientSelect }: CoachSessionsProps) {
  const [view, setView] = useState<"calendar" | "list">("list");
  const [filter, setFilter] = useState<"all" | "upcoming" | "completed" | "missed">("all");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [showAddModal, setShowAddModal] = useState(false);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-[#c6ff00]" />;
      case "missed":
        return <XCircle className="w-4 h-4 text-orange-400" />;
      case "upcoming":
        return <Clock className="w-4 h-4 text-blue-400" />;
      default:
        return <AlertCircle className="w-4 h-4 text-white/40" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-[#c6ff00]/20 text-[#c6ff00]";
      case "missed":
        return "bg-orange-500/20 text-orange-400";
      case "upcoming":
        return "bg-blue-500/20 text-blue-400";
      default:
        return "bg-white/10 text-white/60";
    }
  };

  const filteredSessions = sessions.filter((session) => {
    if (filter === "all") return true;
    return session.status === filter;
  });

  const todaySessions = sessions.filter(
    (s) => s.date === new Date().toISOString().split("T")[0] && s.status === "upcoming"
  );

  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-white text-2xl">Sessions</h1>
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Session</span>
            </button>
          </div>

          {/* View Toggle & Filters */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setView("list")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  view === "list"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                <List className="w-4 h-4" />
                <span className="hidden sm:inline">List</span>
              </button>
              <button
                onClick={() => setView("calendar")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  view === "calendar"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                <CalendarIcon className="w-4 h-4" />
                <span className="hidden sm:inline">Calendar</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilter("all")}
                className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                  filter === "all"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter("upcoming")}
                className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                  filter === "upcoming"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                Upcoming
              </button>
              <button
                onClick={() => setFilter("completed")}
                className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                  filter === "completed"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                Completed
              </button>
              <button
                onClick={() => setFilter("missed")}
                className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                  filter === "missed"
                    ? "bg-[#c6ff00] text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                Missed
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* AI Auto-Suggest */}
        {view === "list" && aiSuggestions.length > 0 && (
          <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-5 border border-[#c6ff00]/20">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-white mb-1">AI Schedule Optimization</h3>
                <p className="text-white/60 text-sm">Suggested actions to maximize your calendar</p>
              </div>
            </div>

            {aiSuggestions.map((suggestion, idx) => (
              <div
                key={idx}
                className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5"
              >
                <p className="text-white mb-2">
                  You have <span className="text-[#c6ff00]">{suggestion.slots.length} open time slots</span> on{" "}
                  <span className="font-medium">{suggestion.day}</span>
                </p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {suggestion.slots.map((slot) => (
                    <span
                      key={slot}
                      className="px-2 py-1 bg-white/5 text-white/80 rounded-lg text-sm"
                    >
                      {slot}
                    </span>
                  ))}
                </div>
                <p className="text-white/60 text-sm mb-3">
                  Suggested clients: {suggestion.suggestedClients.join(", ")}
                </p>
                <button className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors">
                  Auto-Fill Slots
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Today's Sessions */}
        {view === "list" && todaySessions.length > 0 && (
          <div>
            <h2 className="text-white text-xl mb-3">Today's Sessions</h2>
            <div className="space-y-3">
              {todaySessions.map((session) => (
                <div
                  key={session.id}
                  className="bg-gradient-to-br from-[#c6ff00]/10 to-[#0f0f0f] rounded-[20px] p-5 border border-[#c6ff00]/20"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={session.clientImage}
                      alt={session.clientName}
                      className="w-14 h-14 rounded-2xl object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-white">{session.clientName}</h3>
                          <span className="text-xl">{session.emoji}</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusBadge(session.status)}`}>
                            {session.status}
                          </span>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                        <div className="flex items-center gap-2 text-white/60">
                          <Clock className="w-4 h-4" />
                          {session.time} ({session.duration})
                        </div>
                        <div className="flex items-center gap-2 text-white/60">
                          <MapPin className="w-4 h-4" />
                          {session.location}
                        </div>
                        <div className="text-white/60">{session.sport}</div>
                      </div>
                      {session.notes && (
                        <p className="text-white/60 text-sm mt-2">{session.notes}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Calendar View */}
        {view === "calendar" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md"
              />
            </div>
            <div className="lg:col-span-2">
              <h3 className="text-white text-xl mb-4">
                Sessions for {selectedDate?.toLocaleDateString()}
              </h3>
              <div className="space-y-3">
                {sessions
                  .filter((s) => s.date === selectedDate?.toISOString().split("T")[0])
                  .map((session) => (
                    <div
                      key={session.id}
                      className="bg-[#0f0f0f] rounded-[20px] p-5 border border-white/10"
                    >
                      <div className="flex items-start gap-4">
                        <img
                          src={session.clientImage}
                          alt={session.clientName}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-white">{session.clientName}</h3>
                            <span className="text-lg">{session.emoji}</span>
                          </div>
                          <div className="flex items-center gap-3 text-sm text-white/60 mb-2">
                            <span>{session.time}</span>
                            <span>•</span>
                            <span>{session.duration}</span>
                            <span>•</span>
                            <span>{session.sport}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-white/60">
                            <MapPin className="w-3 h-3" />
                            {session.location}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(session.status)}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* List View */}
        {view === "list" && (
          <div>
            <h2 className="text-white text-xl mb-3">All Sessions</h2>
            <div className="space-y-3">
              {filteredSessions.map((session) => (
                <div
                  key={session.id}
                  className="bg-[#0f0f0f] rounded-[20px] p-5 border border-white/10 hover:border-white/20 transition-all"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={session.clientImage}
                      alt={session.clientName}
                      className="w-14 h-14 rounded-2xl object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-white">{session.clientName}</h3>
                          <span className="text-xl">{session.emoji}</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusBadge(session.status)}`}>
                            {session.status}
                          </span>
                        </div>
                        <span className="text-white/60 text-sm">{session.date}</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm mb-2">
                        <div className="flex items-center gap-2 text-white/60">
                          <Clock className="w-4 h-4" />
                          {session.time} ({session.duration})
                        </div>
                        <div className="flex items-center gap-2 text-white/60">
                          <MapPin className="w-4 h-4" />
                          {session.location}
                        </div>
                        <div className="text-white/60">{session.sport}</div>
                      </div>
                      {session.notes && (
                        <p className="text-white/60 text-sm">{session.notes}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Add Session Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10 max-w-md w-full">
            <h3 className="text-white text-xl mb-4">Add New Session</h3>
            <p className="text-white/60 text-sm mb-4">
              Quick session creation - full scheduling coming soon
            </p>
            <button
              onClick={() => setShowAddModal(false)}
              className="w-full px-4 py-3 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
