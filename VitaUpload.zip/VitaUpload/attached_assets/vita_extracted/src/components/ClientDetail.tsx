import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  TrendingUp,
  Calendar,
  Clock,
  Flame,
  Target,
  Zap,
  Activity,
  Award,
  MessageCircle,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  X,
  Send,
  Plus,
  Edit,
  Share2,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Progress } from "./ui/progress";
import { Textarea } from "./ui/textarea";
import { Switch } from "./ui/switch";

interface ClientDetailProps {
  clientId: string;
  onBack: () => void;
}

// Client profiles database
const clientProfiles: Record<string, any> = {
  "1": {
    name: "Huy Nguyen",
    location: "🇻🇳 Ho Chi Minh City",
    trainingFocus: "Boxing & Core Stability",
    flowIndex: 72,
    totalSessions: 124,
    totalHours: 186,
    currentStreak: 21,
    status: "Active",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 58 },
      { date: "Week 2", flow: 62 },
      { date: "Week 3", flow: 65 },
      { date: "Week 4", flow: 68 },
      { date: "Week 5", flow: 70 },
      { date: "Week 6", flow: 72 },
    ],
    attendanceData: [
      { week: "W1", sessions: 4 },
      { week: "W2", sessions: 5 },
      { week: "W3", sessions: 3 },
      { week: "W4", sessions: 6 },
    ],
    metrics: [
      { name: "Speed", value: 78, change: "+7%", color: "#c6ff00" },
      { name: "Power", value: 82, change: "+3%", color: "#00d9ff" },
      { name: "Endurance", value: 71, change: "+2%", color: "#ff00d9" },
      { name: "Technique", value: 85, change: "+5%", color: "#ffa500" },
    ],
    aiInsight: "Speed improved +7%, technique +5%. Suggest 2 more sparring drills this week to maintain momentum.",
    sessions: [
      {
        id: 1,
        date: "29 Oct",
        sport: "Boxing",
        emoji: "🥊",
        title: "Boxing Drills",
        status: "completed",
        rating: 9,
        notes: "Excellent footwork today. Guard transitions need more work but overall very strong session.",
        duration: "60 min",
      },
      {
        id: 2,
        date: "27 Oct",
        sport: "Yoga",
        emoji: "🧘",
        title: "Recovery Session",
        status: "completed",
        rating: 8,
        notes: "Good flexibility progress. Hip mobility improving.",
        duration: "45 min",
      },
      {
        id: 3,
        date: "25 Oct",
        sport: "Strength",
        emoji: "💪",
        title: "Strength Circuit",
        status: "missed",
        notes: "Client did not show up. Follow-up scheduled.",
        duration: "60 min",
      },
      {
        id: 4,
        date: "23 Oct",
        sport: "Boxing",
        emoji: "🥊",
        title: "Sparring Practice",
        status: "completed",
        rating: 9,
        notes: "Best sparring session yet. Defensive techniques showing real improvement.",
        duration: "90 min",
      },
      {
        id: 5,
        date: "21 Oct",
        sport: "Running",
        emoji: "🏃",
        title: "Cardio Endurance",
        status: "completed",
        rating: 7,
        notes: "Good pace maintained. Breathing technique needs refinement.",
        duration: "45 min",
      },
    ],
    goals: [
      { title: "Master defensive movement", progress: 70, status: "On Track" },
      { title: "Improve 3-round stamina", progress: 45, status: "In Progress" },
      { title: "Maintain consistency streak", progress: 100, status: "Active 🔥" },
    ],
    coachNotes: [
      {
        date: "28 Oct",
        note: "Good focus on footwork. Next session: improve guard transitions.",
        shared: true,
      },
      {
        date: "20 Oct",
        note: "Client mentioned feeling fatigued. Adjust intensity next week.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "coach", message: "Great session today. Footwork much sharper!", time: "2h ago" },
      { sender: "client", message: "Thanks! Will drill it again tomorrow 👊", time: "1h ago" },
    ],
  },
  "2": {
    name: "Linh Tran",
    location: "🇻🇳 Hanoi",
    trainingFocus: "Yoga & Mindfulness",
    flowIndex: 58,
    totalSessions: 86,
    totalHours: 129,
    currentStreak: 8,
    status: "Active",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 52 },
      { date: "Week 2", flow: 54 },
      { date: "Week 3", flow: 55 },
      { date: "Week 4", flow: 56 },
      { date: "Week 5", flow: 57 },
      { date: "Week 6", flow: 58 },
    ],
    attendanceData: [
      { week: "W1", sessions: 3 },
      { week: "W2", sessions: 4 },
      { week: "W3", sessions: 3 },
      { week: "W4", sessions: 3 },
    ],
    metrics: [
      { name: "Flexibility", value: 82, change: "+12%", color: "#c6ff00" },
      { name: "Balance", value: 75, change: "+8%", color: "#00d9ff" },
      { name: "Mindfulness", value: 88, change: "+15%", color: "#ff00d9" },
      { name: "Strength", value: 65, change: "+4%", color: "#ffa500" },
    ],
    aiInsight: "Flexibility gains are exceptional (+12%). Consider adding advanced poses to challenge growth.",
    sessions: [
      {
        id: 1,
        date: "01 Nov",
        sport: "Yoga",
        emoji: "🧘",
        title: "Vinyasa Flow",
        status: "completed",
        rating: 9,
        notes: "Beautiful flow today. Headstand hold improved significantly.",
        duration: "60 min",
      },
      {
        id: 2,
        date: "29 Oct",
        sport: "Meditation",
        emoji: "🧘‍♀️",
        title: "Meditation & Breathwork",
        status: "completed",
        rating: 10,
        notes: "Deep meditation session. Client reports reduced stress levels.",
        duration: "30 min",
      },
      {
        id: 3,
        date: "27 Oct",
        sport: "Yoga",
        emoji: "🧘",
        title: "Restorative Yoga",
        status: "completed",
        rating: 8,
        notes: "Focused on hip openers. Good progress on pigeon pose.",
        duration: "45 min",
      },
      {
        id: 4,
        date: "25 Oct",
        sport: "Yoga",
        emoji: "🧘",
        title: "Power Yoga",
        status: "completed",
        rating: 7,
        notes: "Challenging session. Build more gradually next time.",
        duration: "60 min",
      },
    ],
    goals: [
      { title: "Achieve 5-min headstand", progress: 60, status: "On Track" },
      { title: "Daily meditation habit", progress: 85, status: "Nearly There" },
      { title: "Improve hamstring flexibility", progress: 75, status: "On Track" },
    ],
    coachNotes: [
      {
        date: "01 Nov",
        note: "Headstand hold improved from 30s to 90s. Ready for advanced variations.",
        shared: true,
      },
      {
        date: "25 Oct",
        note: "Watch for lower back strain in forward folds. Cue to engage core.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "coach", message: "Amazing progress on your headstand! 🎉", time: "3h ago" },
      { sender: "client", message: "Thank you! Feeling so much stronger 💪", time: "2h ago" },
    ],
  },
  "3": {
    name: "Khoa Le",
    location: "🇻🇳 Da Nang",
    trainingFocus: "Strength & Hypertrophy",
    flowIndex: 45,
    totalSessions: 42,
    totalHours: 63,
    currentStreak: 3,
    status: "Rehab Phase",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 62 },
      { date: "Week 2", flow: 58 },
      { date: "Week 3", flow: 52 },
      { date: "Week 4", flow: 48 },
      { date: "Week 5", flow: 46 },
      { date: "Week 6", flow: 45 },
    ],
    attendanceData: [
      { week: "W1", sessions: 3 },
      { week: "W2", sessions: 2 },
      { week: "W3", sessions: 1 },
      { week: "W4", sessions: 2 },
    ],
    metrics: [
      { name: "Strength", value: 72, change: "-5%", color: "#ff6b6b" },
      { name: "Power", value: 68, change: "-3%", color: "#ff6b6b" },
      { name: "Recovery", value: 55, change: "+10%", color: "#c6ff00" },
      { name: "Mobility", value: 80, change: "+15%", color: "#00d9ff" },
    ],
    aiInsight: "Client recovering from shoulder injury. Mobility improving (+15%). Recommend 2 more weeks of rehab before returning to heavy lifts.",
    sessions: [
      {
        id: 1,
        date: "30 Oct",
        sport: "Physical Therapy",
        emoji: "🩹",
        title: "Shoulder Rehab",
        status: "completed",
        rating: 7,
        notes: "Range of motion improving. Still some discomfort in overhead movements.",
        duration: "45 min",
      },
      {
        id: 2,
        date: "26 Oct",
        sport: "Mobility",
        emoji: "🤸",
        title: "Mobility & Stretching",
        status: "completed",
        rating: 8,
        notes: "Good session. Thoracic mobility much better.",
        duration: "30 min",
      },
      {
        id: 3,
        date: "23 Oct",
        sport: "Strength",
        emoji: "💪",
        title: "Lower Body Strength",
        status: "missed",
        notes: "Client reported shoulder pain flare-up. Rescheduled.",
        duration: "60 min",
      },
      {
        id: 4,
        date: "19 Oct",
        sport: "Physical Therapy",
        emoji: "🩹",
        title: "Shoulder Rehab",
        status: "completed",
        rating: 6,
        notes: "Slow progress this week. Patience required.",
        duration: "45 min",
      },
    ],
    goals: [
      { title: "Full shoulder ROM recovery", progress: 65, status: "In Progress" },
      { title: "Pain-free overhead press", progress: 40, status: "Needs Work" },
      { title: "Return to 3x/week training", progress: 50, status: "On Hold" },
    ],
    coachNotes: [
      {
        date: "30 Oct",
        note: "Shoulder rehab progressing well. Consider adding light band work next week.",
        shared: false,
      },
      {
        date: "19 Oct",
        note: "Client feeling discouraged. Remind them recovery takes time. Focus on wins.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "coach", message: "How's the shoulder feeling today?", time: "5h ago" },
      { sender: "client", message: "Better! Less pain in daily activities 👍", time: "4h ago" },
    ],
  },
  "4": {
    name: "Mai Pham",
    location: "🇻🇳 Ho Chi Minh City",
    trainingFocus: "Boxing & Competition Prep",
    flowIndex: 68,
    totalSessions: 98,
    totalHours: 147,
    currentStreak: 15,
    status: "Active",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 60 },
      { date: "Week 2", flow: 62 },
      { date: "Week 3", flow: 64 },
      { date: "Week 4", flow: 66 },
      { date: "Week 5", flow: 67 },
      { date: "Week 6", flow: 68 },
    ],
    attendanceData: [
      { week: "W1", sessions: 5 },
      { week: "W2", sessions: 6 },
      { week: "W3", sessions: 5 },
      { week: "W4", sessions: 6 },
    ],
    metrics: [
      { name: "Speed", value: 85, change: "+9%", color: "#c6ff00" },
      { name: "Power", value: 79, change: "+6%", color: "#00d9ff" },
      { name: "Stamina", value: 82, change: "+11%", color: "#ff00d9" },
      { name: "Technique", value: 88, change: "+7%", color: "#ffa500" },
    ],
    aiInsight: "Competition-ready metrics across the board. Speed +9%, stamina +11%. Maintain current intensity for peak performance.",
    sessions: [
      {
        id: 1,
        date: "01 Nov",
        sport: "Boxing",
        emoji: "🥊",
        title: "Sparring Competition Prep",
        status: "completed",
        rating: 10,
        notes: "Outstanding session! Dominated every round. Competition confidence high.",
        duration: "90 min",
      },
      {
        id: 2,
        date: "30 Oct",
        sport: "Boxing",
        emoji: "🥊",
        title: "Speed & Agility Drills",
        status: "completed",
        rating: 9,
        notes: "Fastest footwork I've seen from her. Hand speed exceptional.",
        duration: "60 min",
      },
      {
        id: 3,
        date: "28 Oct",
        sport: "Strength",
        emoji: "💪",
        title: "Power Development",
        status: "completed",
        rating: 8,
        notes: "Good strength gains. Power punches much more explosive.",
        duration: "60 min",
      },
      {
        id: 4,
        date: "26 Oct",
        sport: "Boxing",
        emoji: "🥊",
        title: "Technical Drills",
        status: "completed",
        rating: 9,
        notes: "Combinations flowing smoothly. Defense tight.",
        duration: "75 min",
      },
      {
        id: 5,
        date: "24 Oct",
        sport: "Cardio",
        emoji: "🏃",
        title: "Endurance Training",
        status: "completed",
        rating: 8,
        notes: "12-round simulation completed. Maintained power throughout.",
        duration: "90 min",
      },
    ],
    goals: [
      { title: "Win regional championship", progress: 90, status: "Competition Ready" },
      { title: "Increase punch power 15%", progress: 85, status: "Nearly There" },
      { title: "Master southpaw defense", progress: 80, status: "On Track" },
    ],
    coachNotes: [
      {
        date: "01 Nov",
        note: "Ready for competition. Confidence is high, technique is sharp. Focus on mental prep this week.",
        shared: true,
      },
      {
        date: "28 Oct",
        note: "Watch for overtraining. She's pushing hard. Ensure adequate recovery.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "client", message: "Coach, I'm ready for this fight! 🔥", time: "6h ago" },
      { sender: "coach", message: "You absolutely are! Your training has been phenomenal 💪", time: "5h ago" },
    ],
  },
  "5": {
    name: "Duc Phan",
    location: "🇻🇳 Can Tho",
    trainingFocus: "Marathon Training & Endurance",
    flowIndex: 62,
    totalSessions: 75,
    totalHours: 112,
    currentStreak: 10,
    status: "Active",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 56 },
      { date: "Week 2", flow: 57 },
      { date: "Week 3", flow: 59 },
      { date: "Week 4", flow: 60 },
      { date: "Week 5", flow: 61 },
      { date: "Week 6", flow: 62 },
    ],
    attendanceData: [
      { week: "W1", sessions: 4 },
      { week: "W2", sessions: 4 },
      { week: "W3", sessions: 5 },
      { week: "W4", sessions: 4 },
    ],
    metrics: [
      { name: "Endurance", value: 88, change: "+14%", color: "#c6ff00" },
      { name: "Pace", value: 76, change: "+5%", color: "#00d9ff" },
      { name: "Recovery", value: 70, change: "+8%", color: "#ff00d9" },
      { name: "Form", value: 82, change: "+6%", color: "#ffa500" },
    ],
    aiInsight: "Endurance improving rapidly (+14%). Marathon pace stabilizing. Recommend one more long run before taper phase.",
    sessions: [
      {
        id: 1,
        date: "31 Oct",
        sport: "Running",
        emoji: "🏃",
        title: "Long Run 32km",
        status: "completed",
        rating: 9,
        notes: "Longest run yet! Maintained target pace. Nutrition strategy worked perfectly.",
        duration: "180 min",
      },
      {
        id: 2,
        date: "29 Oct",
        sport: "Running",
        emoji: "🏃",
        title: "Tempo Run",
        status: "completed",
        rating: 8,
        notes: "Good tempo session. Heart rate zones perfect.",
        duration: "60 min",
      },
      {
        id: 3,
        date: "27 Oct",
        sport: "Strength",
        emoji: "💪",
        title: "Runner Strength Training",
        status: "completed",
        rating: 7,
        notes: "Focus on leg strength and core stability.",
        duration: "45 min",
      },
      {
        id: 4,
        date: "25 Oct",
        sport: "Running",
        emoji: "🏃",
        title: "Interval Training",
        status: "completed",
        rating: 8,
        notes: "Speed work improving. Recoveries getting shorter.",
        duration: "60 min",
      },
    ],
    goals: [
      { title: "Complete first marathon", progress: 85, status: "Nearly There" },
      { title: "Finish under 4 hours", progress: 75, status: "On Track" },
      { title: "Stay injury-free", progress: 100, status: "Perfect 🎯" },
    ],
    coachNotes: [
      {
        date: "31 Oct",
        note: "32km run completed! Ready for marathon distance. Start taper next week.",
        shared: true,
      },
      {
        date: "25 Oct",
        note: "Monitor for overuse injuries during high-mileage phase.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "coach", message: "Incredible 32km today! How do you feel?", time: "8h ago" },
      { sender: "client", message: "Tired but amazing! I can actually do this 🏃‍♂️", time: "7h ago" },
    ],
  },
  "6": {
    name: "Anh Nguyen",
    location: "🇻🇳 Nha Trang",
    trainingFocus: "Swimming & Triathlon",
    flowIndex: 71,
    totalSessions: 110,
    totalHours: 165,
    currentStreak: 14,
    status: "Active",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop",
    performanceData: [
      { date: "Week 1", flow: 65 },
      { date: "Week 2", flow: 66 },
      { date: "Week 3", flow: 68 },
      { date: "Week 4", flow: 69 },
      { date: "Week 5", flow: 70 },
      { date: "Week 6", flow: 71 },
    ],
    attendanceData: [
      { week: "W1", sessions: 5 },
      { week: "W2", sessions: 6 },
      { week: "W3", sessions: 5 },
      { week: "W4", sessions: 5 },
    ],
    metrics: [
      { name: "Speed", value: 84, change: "+10%", color: "#c6ff00" },
      { name: "Technique", value: 90, change: "+8%", color: "#00d9ff" },
      { name: "Endurance", value: 86, change: "+12%", color: "#ff00d9" },
      { name: "Power", value: 78, change: "+5%", color: "#ffa500" },
    ],
    aiInsight: "Technique refinement paying off - speed +10%, form efficiency excellent. Ready for competition distances.",
    sessions: [
      {
        id: 1,
        date: "01 Nov",
        sport: "Swimming",
        emoji: "🏊",
        title: "Open Water Practice",
        status: "completed",
        rating: 10,
        notes: "Perfect technique in open water conditions. Sighting and navigation excellent.",
        duration: "90 min",
      },
      {
        id: 2,
        date: "30 Oct",
        sport: "Swimming",
        emoji: "🏊",
        title: "Speed Intervals",
        status: "completed",
        rating: 9,
        notes: "Best interval times yet. Stroke technique very clean.",
        duration: "60 min",
      },
      {
        id: 3,
        date: "28 Oct",
        sport: "Cycling",
        emoji: "🚴",
        title: "Bike Endurance",
        status: "completed",
        rating: 8,
        notes: "60km ride completed. Good bike-run transition practice.",
        duration: "120 min",
      },
      {
        id: 4,
        date: "26 Oct",
        sport: "Running",
        emoji: "🏃",
        title: "Brick Workout",
        status: "completed",
        rating: 8,
        notes: "Bike-to-run transition smooth. Legs adapting well.",
        duration: "75 min",
      },
    ],
    goals: [
      { title: "Complete Olympic triathlon", progress: 88, status: "Nearly There" },
      { title: "Swim 1500m under 22min", progress: 92, status: "Almost There!" },
      { title: "Improve bike power output", progress: 70, status: "On Track" },
    ],
    coachNotes: [
      {
        date: "01 Nov",
        note: "Open water skills looking great. Triathlon race ready!",
        shared: true,
      },
      {
        date: "28 Oct",
        note: "Monitor nutrition during long sessions. Bonking on 60km+ rides.",
        shared: false,
      },
    ],
    chatMessages: [
      { sender: "client", message: "Open water felt so good today! 🌊", time: "4h ago" },
      { sender: "coach", message: "Your technique was perfect! Race day will be amazing 🏊‍♀️", time: "3h ago" },
    ],
  },
};

export function ClientDetail({ clientId, onBack }: ClientDetailProps) {
  const [expandedSession, setExpandedSession] = useState<number | null>(null);
  const [sessionFilter, setSessionFilter] = useState<"all" | "completed" | "missed" | "upcoming">("all");
  const [newNote, setNewNote] = useState("");
  const [shareNewNote, setShareNewNote] = useState(false);

  // Get client data based on ID, fallback to client 1
  const client = clientProfiles[clientId] || clientProfiles["1"];

  const filteredSessions = client.sessions.filter((session: any) => {
    if (sessionFilter === "all") return true;
    return session.status === sessionFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-[#c6ff00]/20 text-[#c6ff00] border-[#c6ff00]/30";
      case "Rest Week":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "Rehab Phase":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30";
      default:
        return "bg-white/10 text-white/60 border-white/20";
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] pb-32">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Clients</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - Left 2 columns */}
          <div className="lg:col-span-2 space-y-6">
            {/* 1️⃣ Client Snapshot Header */}
            <div className="bg-gradient-to-br from-[#0f0f0f] to-[#1a1a1a] rounded-[24px] p-6 border border-white/10">
              <div className="flex items-start gap-5 mb-6">
                <div className="relative">
                  <img
                    src={client.image}
                    alt={client.name}
                    className="w-24 h-24 rounded-2xl object-cover ring-2 ring-white/10"
                  />
                  <div className="absolute -bottom-2 -right-2 px-3 py-1 bg-[#c6ff00] text-black rounded-xl text-xs font-semibold">
                    Flow {client.flowIndex}
                  </div>
                </div>

                <div className="flex-1">
                  <h1 className="text-white text-2xl mb-1">{client.name}</h1>
                  <div className="flex items-center gap-2 text-white/60 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>{client.location}</span>
                  </div>
                  <div className="inline-block px-3 py-1 bg-white/5 text-white/80 rounded-lg text-sm mb-4">
                    {client.trainingFocus}
                  </div>
                  <div className={`inline-block px-3 py-1 rounded-full text-sm border ${getStatusColor(client.status)}`}>
                    {client.status}
                  </div>
                </div>
              </div>

              {/* Summary Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 text-white/60 text-xs mb-1">
                    <Calendar className="w-3 h-3" />
                    Sessions
                  </div>
                  <p className="text-white text-2xl">{client.totalSessions}</p>
                </div>
                <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 text-white/60 text-xs mb-1">
                    <Clock className="w-3 h-3" />
                    Hours
                  </div>
                  <p className="text-white text-2xl">{client.totalHours}</p>
                </div>
                <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 text-white/60 text-xs mb-1">
                    <Flame className="w-3 h-3 text-orange-500" />
                    Streak
                  </div>
                  <p className="text-white text-2xl">{client.currentStreak} 🔥</p>
                </div>
              </div>
            </div>

            {/* 2️⃣ Performance Overview */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Performance Overview</h2>

              {/* Charts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
                {/* Flow Index Chart */}
                <div>
                  <h3 className="text-white/80 text-sm mb-3">Flow Index Over Time</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={client.performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                      <XAxis dataKey="date" stroke="#9B9B9B" fontSize={11} />
                      <YAxis stroke="#9B9B9B" fontSize={11} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1a1a1a",
                          border: "1px solid #ffffff20",
                          borderRadius: "8px",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="flow"
                        stroke="#c6ff00"
                        strokeWidth={3}
                        dot={{ fill: "#c6ff00", r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Attendance Chart */}
                <div>
                  <h3 className="text-white/80 text-sm mb-3">Session Attendance</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={client.attendanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                      <XAxis dataKey="week" stroke="#9B9B9B" fontSize={11} />
                      <YAxis stroke="#9B9B9B" fontSize={11} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1a1a1a",
                          border: "1px solid #ffffff20",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="sessions" fill="#00d9ff" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
                {client.metrics.map((metric: any) => (
                  <div
                    key={metric.name}
                    className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 relative overflow-hidden"
                  >
                    <div
                      className="absolute inset-0 opacity-5"
                      style={{ background: `radial-gradient(circle at top right, ${metric.color}, transparent)` }}
                    />
                    <p className="text-white/60 text-xs mb-2">{metric.name}</p>
                    <p className="text-white text-2xl mb-1">{metric.value}%</p>
                    <p className="text-sm" style={{ color: metric.change.startsWith("+") ? "#c6ff00" : "#ff6b6b" }}>
                      {metric.change}
                    </p>
                    <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mt-2">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${metric.value}%`, backgroundColor: metric.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Insight */}
              <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-xl p-4 border border-[#c6ff00]/20">
                <div className="flex items-start gap-3">
                  <TrendingUp className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white/80 text-sm mb-1">AI Insight</p>
                    <p className="text-white/60 text-sm">{client.aiInsight}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 3️⃣ Session History */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-white text-xl">Session History</h2>
                <div className="flex gap-2">
                  {["all", "completed", "missed", "upcoming"].map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setSessionFilter(filter as any)}
                      className={`px-3 py-1 rounded-lg text-xs capitalize transition-colors ${
                        sessionFilter === filter
                          ? "bg-[#c6ff00] text-black"
                          : "bg-white/5 text-white/60 hover:bg-white/10"
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {filteredSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="bg-[#1a1a1a] rounded-xl border border-white/5 overflow-hidden"
                  >
                    <div
                      onClick={() => setExpandedSession(expandedSession === session.id ? null : session.id)}
                      className="p-4 cursor-pointer hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 flex-1">
                          <span className="text-2xl">{session.emoji}</span>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="text-white">{session.date} — {session.title}</p>
                              {session.status === "completed" && (
                                <CheckCircle className="w-4 h-4 text-[#c6ff00]" />
                              )}
                              {session.status === "missed" && (
                                <X className="w-4 h-4 text-orange-400" />
                              )}
                            </div>
                            <div className="flex items-center gap-3 text-xs text-white/60">
                              <span>{session.duration}</span>
                              {session.rating && (
                                <span className="text-[#c6ff00]">★ {session.rating}/10</span>
                              )}
                            </div>
                          </div>
                        </div>
                        {expandedSession === session.id ? (
                          <ChevronUp className="w-5 h-5 text-white/40" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-white/40" />
                        )}
                      </div>
                    </div>

                    {expandedSession === session.id && (
                      <div className="px-4 pb-4 pt-0 border-t border-white/5">
                        <p className="text-white/60 text-sm">{session.notes}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 4️⃣ Coach Notes & Feedback */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Coach Notes & Feedback</h2>

              {/* Add New Note */}
              <div className="mb-5">
                <Textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Add a new note..."
                  className="bg-[#1a1a1a] border-white/10 text-white placeholder:text-white/40 mb-3"
                  rows={3}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Switch checked={shareNewNote} onCheckedChange={setShareNewNote} />
                    <span className="text-white/60 text-sm">Share with client</span>
                  </div>
                  <button className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors">
                    Add Note
                  </button>
                </div>
              </div>

              {/* Past Notes */}
              <div className="space-y-3">
                {client.coachNotes.map((note: any, idx: number) => (
                  <div key={idx} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <span className="text-white/60 text-xs">{note.date}</span>
                      {note.shared ? (
                        <span className="flex items-center gap-1 px-2 py-0.5 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
                          <Share2 className="w-3 h-3" />
                          Shared
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-white/5 text-white/60 rounded text-xs">
                          Private
                        </span>
                      )}
                    </div>
                    <p className="text-white/80 text-sm">{note.note}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* 5️⃣ Client Goals */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Current Goals</h2>
              <div className="space-y-4">
                {client.goals.map((goal: any, idx: number) => (
                  <div key={idx} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <div className="flex items-start gap-2 mb-3">
                      <Target className="w-4 h-4 text-[#c6ff00] flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-white text-sm mb-1">{goal.title}</p>
                        <p className="text-white/60 text-xs">{goal.status}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-white/60">Progress</span>
                        <span className="text-[#c6ff00]">{goal.progress}%</span>
                      </div>
                      <Progress value={goal.progress} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 6️⃣ Communication */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Quick Chat</h2>
              <div className="space-y-3 mb-4">
                {client.chatMessages.map((msg: any, idx: number) => (
                  <div
                    key={idx}
                    className={`rounded-xl p-3 ${
                      msg.sender === "coach"
                        ? "bg-[#c6ff00]/10 border border-[#c6ff00]/20"
                        : "bg-[#1a1a1a] border border-white/5"
                    }`}
                  >
                    <p className="text-white text-sm mb-1">{msg.message}</p>
                    <span className="text-white/40 text-xs">{msg.time}</span>
                  </div>
                ))}
              </div>
              <button className="w-full px-4 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors flex items-center justify-center gap-2">
                <MessageCircle className="w-4 h-4" />
                Open Full Chat
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 7️⃣ Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-t border-white/10 pb-[env(safe-area-inset-bottom,0px)]">
        <div className="max-w-7xl mx-auto px-5 py-4 flex items-center gap-3">
          <button className="flex-1 px-6 py-3 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-all hover:shadow-[0_0_20px_rgba(198,255,0,0.3)] flex items-center justify-center gap-2">
            <Calendar className="w-5 h-5" />
            <span className="hidden sm:inline">Schedule Next Session</span>
          </button>
          <button className="flex-1 px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all flex items-center justify-center gap-2">
            <Edit className="w-5 h-5" />
            <span className="hidden sm:inline">Add Progress Note</span>
          </button>
          <button className="flex-1 px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all flex items-center justify-center gap-2">
            <Send className="w-5 h-5" />
            <span className="hidden sm:inline">Send Message</span>
          </button>
        </div>
      </div>
    </div>
  );
}
