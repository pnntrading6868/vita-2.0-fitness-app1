import { Upload, Video, Image, FileText, Plus, Play, Edit, Trash2 } from "lucide-react";

export function CoachLibrary() {
  const media = [
    {
      id: 1,
      type: "video",
      title: "Defensive Boxing Techniques",
      thumbnail: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=400&h=300&fit=crop",
      duration: "2:34",
      tags: ["Boxing", "Technique", "Defense"],
      views: 145,
      date: "Oct 28, 2025",
    },
    {
      id: 2,
      type: "video",
      title: "Warmup Routine for Boxers",
      thumbnail: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&h=300&fit=crop",
      duration: "1:12",
      tags: ["Boxing", "Warmup"],
      views: 89,
      date: "Oct 25, 2025",
    },
    {
      id: 3,
      type: "video",
      title: "Core Stability Exercises",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
      duration: "3:45",
      tags: ["Strength", "Core"],
      views: 203,
      date: "Oct 20, 2025",
    },
  ];

  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-white text-2xl">Content Library</h1>
              <p className="text-white/60 text-sm mt-1">Manage your training videos and media</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors">
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">Upload Content</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Video className="w-4 h-4" />
              Videos
            </div>
            <p className="text-white text-2xl">12</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Image className="w-4 h-4" />
              Images
            </div>
            <p className="text-white text-2xl">28</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <FileText className="w-4 h-4" />
              Documents
            </div>
            <p className="text-white text-2xl">6</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Play className="w-4 h-4" />
              Total Views
            </div>
            <p className="text-white text-2xl">437</p>
          </div>
        </div>

        {/* AI Editor Teaser */}
        <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-5 border border-[#c6ff00]/20">
          <div className="flex items-start gap-3">
            <Video className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white mb-2">AI Video Editor (Coming Soon)</p>
              <p className="text-white/60 text-sm mb-3">
                Automatically cut 10-second highlight reels from your training videos for VITA Reels
                and social media. AI-powered scene detection and auto-captioning.
              </p>
              <button className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors">
                Join Beta Waitlist
              </button>
            </div>
          </div>
        </div>

        {/* Media Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white text-xl">Uploaded Videos</h2>
            <div className="flex gap-2">
              <button className="px-3 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm border border-white/10 transition-colors">
                All
              </button>
              <button className="px-3 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm border border-white/10 transition-colors">
                Videos
              </button>
              <button className="px-3 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm border border-white/10 transition-colors">
                Images
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {media.map((item) => (
              <div
                key={item.id}
                className="bg-[#0f0f0f] rounded-[20px] overflow-hidden border border-white/10 hover:border-white/20 transition-all group"
              >
                <div className="relative">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button className="w-12 h-12 bg-[#c6ff00] rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 text-black" />
                    </button>
                  </div>
                  {item.type === "video" && (
                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-white text-xs">
                      {item.duration}
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="text-white mb-2">{item.title}</h3>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {item.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 bg-white/5 text-white/60 rounded text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between text-xs text-white/60">
                    <span>{item.views} views</span>
                    <span>{item.date}</span>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button className="flex-1 px-3 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-1">
                      <Edit className="w-3 h-3" />
                      Edit
                    </button>
                    <button className="px-3 py-2 bg-white/5 hover:bg-red-500/20 text-white/60 hover:text-red-400 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* VITA Creator Teaser */}
        <div className="bg-gradient-to-br from-purple-500/10 to-transparent rounded-[24px] p-6 border border-purple-500/20">
          <h3 className="text-white mb-2">VITA Creator Platform (Q1 2026)</h3>
          <p className="text-white/60 text-sm mb-4">
            Build and sell complete online courses. Turn your expertise into passive income with
            our course builder, student management, and monetization tools.
          </p>
          <button className="px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-lg text-sm transition-colors">
            Early Access Application
          </button>
        </div>
      </div>
    </div>
  );
}
