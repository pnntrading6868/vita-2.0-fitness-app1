import { useState } from "react";
import { Camera, Award, TrendingUp, MapPin, Edit, Trophy, Clock, Flame, Target, Zap, Activity, CheckCircle2, ChevronRight, Wallet as WalletIcon, Share2, MoreVertical, ChevronDown, Sparkles, BarChart3, Users, Star, Play, ArrowUpRight, Dumbbell, Heart } from "lucide-react";
import { Wallet } from "./Wallet";

const mockUserData = {
  name: "Sofia Martinez",
  level: "Intermediate Athlete",
  location: "Dubai, UAE",
  memberSince: "January 2024",
  avatar: "https://images.unsplash.com/photo-1649258535778-39f1cc2d0f05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
  verified: true,
  sports: ["Boxing", "Yoga", "Tennis"],
  flowIndex: 72
};

interface Coach {
  id: number;
  name: string;
  sport: string;
  imageUrl: string;
  totalSessions: number;
  rating: number;
  feedback: string;
}

interface PerformanceMetric {
  category: string;
  current: number;
  improvement: number;
  color: string;
}

interface Milestone {
  id: number;
  title: string;
  description: string;
  icon: string;
  date: string;
  type: "achievement" | "ranking" | "milestone";
}

interface TrainingLog {
  id: number;
  title: string;
  thumbnail: string;
  sport: string;
  date: string;
  type: "video" | "stats";
}

const quickStats = {
  totalSessions: 124,
  activeStreak: 12,
  totalHours: 186,
  coachesWorkedWith: 5
};

const performanceMetrics: PerformanceMetric[] = [
  { category: "Strength", current: 82, improvement: 12, color: "blue" },
  { category: "Speed", current: 76, improvement: 8, color: "purple" },
  { category: "Endurance", current: 88, improvement: 15, color: "green" },
  { category: "Technique", current: 79, improvement: 6, color: "orange" }
];

const trainingVolume = {
  totalSessions: 124,
  totalHours: 186,
  avgDuration: 90
};

const disciplineBreakdown = [
  { sport: "Boxing", sessions: 48, percentage: 39, color: "#ef4444" },
  { sport: "Yoga", sessions: 45, percentage: 36, color: "#8b5cf6" },
  { sport: "Tennis", sessions: 31, percentage: 25, color: "#3b82f6" }
];

const milestones: Milestone[] = [
  {
    id: 1,
    title: "Top 10 National Ranking",
    description: "Ranked #7 in Boxing - Dubai",
    icon: "trophy",
    date: "Oct 15, 2025",
    type: "ranking"
  },
  {
    id: 2,
    title: "100 Sessions Milestone",
    description: "Completed 100th training session",
    icon: "target",
    date: "Oct 10, 2025",
    type: "milestone"
  },
  {
    id: 3,
    title: "12-Day Flow Streak",
    description: "Current active training streak",
    icon: "flame",
    date: "Ongoing",
    type: "achievement"
  },
  {
    id: 4,
    title: "Cross-Training Champion",
    description: "Trained 3 sports in one month",
    icon: "zap",
    date: "Sep 30, 2025",
    type: "achievement"
  }
];

const coaches: Coach[] = [
  {
    id: 1,
    name: "Marcus Johnson",
    sport: "Boxing",
    imageUrl: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop",
    totalSessions: 48,
    rating: 5.0,
    feedback: "Disciplined and sharp. Excellent progress on technique."
  },
  {
    id: 2,
    name: "Elena Rodriguez",
    sport: "Yoga & Mobility",
    imageUrl: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=400&fit=crop",
    totalSessions: 45,
    rating: 5.0,
    feedback: "Focused mindset. Great consistency and form improvement."
  },
  {
    id: 3,
    name: "Sarah Mitchell",
    sport: "Tennis",
    imageUrl: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&h=400&fit=crop",
    totalSessions: 31,
    rating: 4.8,
    feedback: "Strong work ethic. Serve technique improving rapidly."
  }
];

const aiInsights = [
  "You're most efficient in morning sessions. Try scheduling 3x morning workouts next week.",
  "Your footwork efficiency improved by +12% this month. Keep this rhythm going!",
  "Recovery pattern optimal. Consider adding one more rest day between boxing sessions."
];

const trainingLogs: TrainingLog[] = [
  {
    id: 1,
    title: "Sparring Session - 3 Rounds",
    thumbnail: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=600&h=400&fit=crop",
    sport: "Boxing",
    date: "Oct 20, 2025",
    type: "video"
  },
  {
    id: 2,
    title: "Week 1 → Week 8 Progress",
    thumbnail: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&h=400&fit=crop",
    sport: "Overall",
    date: "Oct 15, 2025",
    type: "stats"
  }
];

const getSportIcon = (sport: string) => {
  switch (sport) {
    case "Boxing":
      return Dumbbell;
    case "Yoga":
      return Heart;
    case "Tennis":
      return Target;
    default:
      return Activity;
  }
};

export function Profile() {
  const [showWallet, setShowWallet] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    performance: true,
    milestones: true,
    coaches: true,
    ai: true,
    logs: true
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  if (showWallet) {
    return <Wallet onBack={() => setShowWallet(false)} />;
  }

  return (
    <div className="h-full bg-[#0f0f0f] overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10 z-10">
        <div className="max-w-md mx-auto px-5 py-4 flex items-center justify-between">
          <h1 className="text-white tracking-tight">Profile</h1>
          <div className="flex items-center gap-2">
            <button className="w-9 h-9 flex items-center justify-center hover:bg-white/10 rounded-xl transition-all duration-200">
              <Share2 className="w-5 h-5 text-white" strokeWidth={2} />
            </button>
            <button className="w-9 h-9 flex items-center justify-center hover:bg-white/10 rounded-xl transition-all duration-200">
              <MoreVertical className="w-5 h-5 text-white" strokeWidth={2} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-5 pb-24">
        {/* Identity Card */}
        <div className="pt-5 pb-6 border-b border-white/10">
          <div className="flex items-start gap-4 mb-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#1a1a1a] border-2 border-white/10">
                <img 
                  src={mockUserData.avatar} 
                  alt={mockUserData.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#c6ff00] hover:bg-[#b5e600] rounded-full flex items-center justify-center shadow-lg transition-all duration-200">
                <Camera className="w-4 h-4 text-black" strokeWidth={2.5} />
              </button>
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-white tracking-tight">{mockUserData.name}</h2>
                {mockUserData.verified && (
                  <div className="w-5 h-5 bg-[#c6ff00] rounded-full flex items-center justify-center">
                    <svg className="w-3 h-3 text-black" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" />
                    </svg>
                  </div>
                )}
              </div>
              <p className="text-sm text-[#c6ff00] mb-2">{mockUserData.level}</p>
              <div className="flex items-center gap-2 text-xs text-white/60">
                <MapPin className="w-3.5 h-3.5" strokeWidth={2} />
                <span>{mockUserData.location}</span>
              </div>
            </div>

            <button className="px-3 py-2 bg-white/10 hover:bg-white/15 rounded-xl border border-white/20 transition-all duration-200 flex items-center gap-2">
              <Edit className="w-4 h-4 text-white" strokeWidth={2} />
              <span className="text-sm text-white">Edit</span>
            </button>
          </div>

          {/* Sport Focus Icons */}
          <div className="flex items-center gap-2 mb-4">
            {mockUserData.sports.map((sport, index) => {
              const IconComponent = getSportIcon(sport);
              return (
                <div
                  key={index}
                  className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-sm flex items-center gap-2"
                >
                  <IconComponent className="w-4 h-4 text-white" />
                  <span className="text-white">{sport}</span>
                </div>
              );
            })}
          </div>

          {/* Flow Index - Signature Metric */}
          <div className="bg-gradient-to-br from-[#c6ff00]/20 to-[#b5e600]/10 border border-[#c6ff00]/30 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-[#c6ff00]" />
                  <span className="text-sm text-white/60">Flow Index</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl text-white">{mockUserData.flowIndex}</span>
                  <span className="text-sm text-white/60">/100</span>
                </div>
                <p className="text-xs text-white/50 mt-1">Performance × Consistency composite score</p>
              </div>
              <div className="relative w-16 h-16">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="32"
                    cy="32"
                    r="28"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="none"
                    className="text-white/10"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="28"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 28}`}
                    strokeDashoffset={`${2 * Math.PI * 28 * (1 - mockUserData.flowIndex / 100)}`}
                    className="text-[#c6ff00] transition-all duration-1000"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-[#c6ff00]" fill="currentColor" />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats Bar */}
          <div className="grid grid-cols-4 gap-2 mt-4">
            <div className="text-center">
              <div className="text-xl text-white mb-0.5">{quickStats.totalSessions}</div>
              <div className="text-xs text-white/40">Sessions</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-0.5">
                <Flame className="w-4 h-4 text-orange-400" />
                <span className="text-xl text-white">{quickStats.activeStreak}</span>
              </div>
              <div className="text-xs text-white/40">Day Streak</div>
            </div>
            <div className="text-center">
              <div className="text-xl text-white mb-0.5">{quickStats.totalHours}h</div>
              <div className="text-xs text-white/40">Total Hours</div>
            </div>
            <div className="text-center">
              <div className="text-xl text-white mb-0.5">{quickStats.coachesWorkedWith}</div>
              <div className="text-xs text-white/40">Coaches</div>
            </div>
          </div>
        </div>

        {/* Wallet Button */}
        <button
          onClick={() => setShowWallet(true)}
          className="w-full my-5 p-4 bg-gradient-to-br from-[#c6ff00] to-[#b5e600] hover:from-[#b5e600] hover:to-[#9fd600] rounded-2xl transition-all duration-300 flex items-center justify-between group shadow-[0_4px_24px_rgba(198,255,0,0.25)] hover:shadow-[0_8px_32px_rgba(198,255,0,0.35)] active:scale-[0.98]"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-black/10 rounded-xl flex items-center justify-center">
              <WalletIcon className="w-6 h-6 text-black" strokeWidth={2.5} />
            </div>
            <div className="text-left">
              <div className="text-black">My Wallet</div>
              <div className="text-black/70 text-sm">Manage deposits & funds</div>
            </div>
          </div>
          <ChevronRight className="w-6 h-6 text-black/70 group-hover:translate-x-1 transition-transform duration-300" strokeWidth={2.5} />
        </button>

        {/* Performance Metrics */}
        <div className="mb-6">
          <button
            onClick={() => toggleSection('performance')}
            className="w-full flex items-center justify-between mb-4"
          >
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#c6ff00]" />
              <h3 className="text-white">Performance Metrics</h3>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.performance ? 'rotate-180' : ''}`} />
          </button>

          {expandedSections.performance && (
            <div className="space-y-4">
              {/* Training Volume */}
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                <h4 className="text-white mb-4">Training Volume</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-2xl text-[#c6ff00] mb-1">{trainingVolume.totalSessions}</div>
                    <div className="text-xs text-white/40">Total Sessions</div>
                  </div>
                  <div>
                    <div className="text-2xl text-[#c6ff00] mb-1">{trainingVolume.totalHours}h</div>
                    <div className="text-xs text-white/40">Total Hours</div>
                  </div>
                  <div>
                    <div className="text-2xl text-[#c6ff00] mb-1">{trainingVolume.avgDuration}m</div>
                    <div className="text-xs text-white/40">Avg Duration</div>
                  </div>
                </div>
              </div>

              {/* Progress Metrics */}
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                <h4 className="text-white mb-4">Progress Over Time</h4>
                <div className="space-y-4">
                  {performanceMetrics.map((metric, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-white">{metric.category}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-white">{metric.current}%</span>
                          <div className="flex items-center gap-1 text-xs text-green-400">
                            <ArrowUpRight className="w-3 h-3" />
                            <span>+{metric.improvement}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-1000 ${
                            metric.color === 'blue' ? 'bg-blue-500' :
                            metric.color === 'purple' ? 'bg-purple-500' :
                            metric.color === 'green' ? 'bg-green-500' :
                            'bg-orange-500'
                          }`}
                          style={{ width: `${metric.current}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Discipline Breakdown */}
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                <h4 className="text-white mb-4">Discipline Breakdown</h4>
                
                {/* Bar Chart */}
                <div className="flex items-end gap-2 h-32 mb-4">
                  {disciplineBreakdown.map((discipline, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center gap-2">
                      <div className="w-full flex items-end justify-center h-24">
                        <div
                          className="w-full rounded-t-lg transition-all duration-1000"
                          style={{ 
                            height: `${discipline.percentage * 0.8}%`,
                            backgroundColor: discipline.color
                          }}
                        />
                      </div>
                      <span className="text-xs text-white/60 text-center">
                        {discipline.sport.slice(0, 3)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Legend */}
                <div className="space-y-2">
                  {disciplineBreakdown.map((discipline, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: discipline.color }}
                        />
                        <span className="text-sm text-white">{discipline.sport}</span>
                      </div>
                      <div className="text-sm text-white/60">{discipline.sessions} sessions ({discipline.percentage}%)</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Milestones & Achievements */}
        <div className="mb-6">
          <button
            onClick={() => toggleSection('milestones')}
            className="w-full flex items-center justify-between mb-4"
          >
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-[#c6ff00]" />
              <h3 className="text-white">Milestones & Achievements</h3>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.milestones ? 'rotate-180' : ''}`} />
          </button>

          {expandedSections.milestones && (
            <div className="space-y-3">
              {milestones.map((milestone) => (
                <div
                  key={milestone.id}
                  className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4 hover:border-[#c6ff00]/30 transition-all duration-200"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      milestone.type === 'ranking' ? 'bg-yellow-500/10 border border-yellow-500/30' :
                      milestone.type === 'milestone' ? 'bg-blue-500/10 border border-blue-500/30' :
                      'bg-orange-500/10 border border-orange-500/30'
                    }`}>
                      {milestone.icon === 'trophy' && <Trophy className="w-6 h-6 text-yellow-400" />}
                      {milestone.icon === 'target' && <Target className="w-6 h-6 text-blue-400" />}
                      {milestone.icon === 'flame' && <Flame className="w-6 h-6 text-orange-400" />}
                      {milestone.icon === 'zap' && <Zap className="w-6 h-6 text-purple-400" />}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white mb-1">{milestone.title}</h4>
                      <p className="text-sm text-white/60 mb-2">{milestone.description}</p>
                      <div className="text-xs text-white/40">{milestone.date}</div>
                    </div>
                    {milestone.type === 'achievement' && (
                      <CheckCircle2 className="w-5 h-5 text-[#c6ff00] flex-shrink-0" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Coach Connections */}
        <div className="mb-6">
          <button
            onClick={() => toggleSection('coaches')}
            className="w-full flex items-center justify-between mb-4"
          >
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-[#c6ff00]" />
              <h3 className="text-white">Coach Connections</h3>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.coaches ? 'rotate-180' : ''}`} />
          </button>

          {expandedSections.coaches && (
            <div className="space-y-3">
              {coaches.map((coach) => (
                <div
                  key={coach.id}
                  className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-all duration-200"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className="relative flex-shrink-0">
                      <img
                        src={coach.imageUrl}
                        alt={coach.name}
                        className="w-14 h-14 rounded-full object-cover"
                      />
                      <div className="absolute -bottom-1 -right-1 bg-[#c6ff00] text-black text-xs px-2 py-0.5 rounded-full">
                        {coach.totalSessions}
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-white">{coach.name}</h4>
                        <div className="px-2 py-0.5 bg-[#c6ff00]/20 border border-[#c6ff00]/30 rounded text-[#c6ff00] text-xs">
                          Coach
                        </div>
                      </div>
                      <p className="text-sm text-white/60 mb-2">{coach.sport}</p>
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < Math.floor(coach.rating)
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-white/20'
                            }`}
                          />
                        ))}
                        <span className="text-xs text-white/60 ml-1">{coach.rating}</span>
                      </div>
                    </div>
                  </div>
                  <div className="pl-0 border-l-0 border-white/10">
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-xs text-white/70 italic">"{coach.feedback}"</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI Insights */}
        <div className="mb-6">
          <button
            onClick={() => toggleSection('ai')}
            className="w-full flex items-center justify-between mb-4"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              <h3 className="text-white">AI Insights</h3>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.ai ? 'rotate-180' : ''}`} />
          </button>

          {expandedSections.ai && (
            <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h4 className="text-white">VITA AI Analysis</h4>
                  <p className="text-xs text-white/60">Auto-updates weekly</p>
                </div>
              </div>
              <div className="space-y-3">
                {aiInsights.map((insight, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-sm text-white/80 leading-relaxed">{insight}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Training Logs */}
        <div className="mb-6">
          <button
            onClick={() => toggleSection('logs')}
            className="w-full flex items-center justify-between mb-4"
          >
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#c6ff00]" />
              <h3 className="text-white">Training Logs</h3>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.logs ? 'rotate-180' : ''}`} />
          </button>

          {expandedSections.logs && (
            <div className="space-y-3">
              {trainingLogs.map((log) => (
                <div
                  key={log.id}
                  className="bg-[#1a1a1a] border border-white/10 rounded-xl overflow-hidden hover:border-[#c6ff00]/30 transition-all duration-200 group cursor-pointer"
                >
                  <div className="relative h-40">
                    <img
                      src={log.thumbnail}
                      alt={log.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    {log.type === 'video' && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-14 h-14 bg-white/10 backdrop-blur-xl rounded-full flex items-center justify-center border border-white/20 group-hover:bg-white/20 transition-all duration-200">
                          <Play className="w-6 h-6 text-white ml-1" fill="currentColor" />
                        </div>
                      </div>
                    )}
                    <div className="absolute top-3 right-3 px-2 py-1 bg-black/50 backdrop-blur-xl rounded text-white text-xs border border-white/20">
                      {log.sport}
                    </div>
                    <div className="absolute bottom-3 left-3 right-3">
                      <h4 className="text-white mb-1">{log.title}</h4>
                      <div className="text-xs text-white/60">{log.date}</div>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Add More Button */}
              <button className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-white text-sm transition-all duration-200 flex items-center justify-center gap-2">
                <span>Add Training Log</span>
                <Camera className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}