# Coach Interface Taskbar Navigation Guide

## Overview
The coach interface now features a bottom taskbar navigation system with 8 comprehensive modules, providing a complete business management platform for fitness coaches.

## Architecture Change

### Before (Old Structure)
- Single-page dashboard with sidebar
- All features on one scrollable page
- Limited organization

### After (New Structure)
- Bottom taskbar with 8 dedicated tabs
- Modular component architecture
- Each tab is a separate, focused experience
- Consistent top header across all tabs

---

## Taskbar Modules

### 1. 🏠 Dashboard (Overview)
**Component**: `CoachOverview.tsx`

**Purpose**: Command center with quick stats and daily insights

**Features**:
- ✅ Quick Stats Cards (Revenue, Sessions, Clients, Rating)
- ✅ Weekly Earnings Chart (Bar chart)
- ✅ Performance Highlights (Retention, Session Quality, Success Rate)
- ✅ AI Recommendations (Business growth, Content strategy)
- ✅ Today's Schedule (Upcoming sessions sidebar)
- ✅ Quick Actions (Add Session, Message Clients, View Analytics)

**Use Case**: First screen coaches see - daily overview and action items

---

### 2. 👥 Clients Module
**Component**: `CoachClients.tsx`

**Purpose**: Manage all clients like a personal training roster

**Features**:
- ✅ **Search & Filters**: 
  - Search by name
  - Filter by sport (Boxing, Yoga, Strength, etc.)
  - Filter by status (Active, At Risk, Inactive)
  - Sort by Flow Index, Name, Recent Activity
  
- ✅ **Client Statistics Dashboard**:
  - Total Clients count
  - Active clients
  - At-risk clients
  - Average Flow Index

- ✅ **AI Alert System**:
  - Auto-detect clients at risk of drop-off
  - Suggest retention actions (e.g., "Khoa hasn't trained in 5 days")
  - One-click message suggestions

- ✅ **Client Cards** (Grid view):
  - Client photo with hover effects
  - Flow Index with progress bar
  - Current streak (fire icon)
  - Total sessions
  - Current goals (2 displayed)
  - Last session date
  - Status badges (Active/At Risk/Inactive)
  - Trend indicators (Improving/Stable/At Risk)
  - Alert banners for concerning patterns

- ✅ **Click → Client Detail**:
  - Each card is clickable
  - Opens full Client Detail Dashboard
  - Shows comprehensive performance data

**Navigation**:
```
Clients Tab → Click Client Card → Client Detail Screen
```

**AI Integration**:
- Retention risk detection
- Auto-suggest engagement actions
- Pattern analysis (e.g., "5 days no training")

---

### 3. 📅 Sessions Module
**Component**: `CoachSessions.tsx`

**Purpose**: Schedule, track, and manage all training sessions

**Features**:
- ✅ **View Modes**:
  - List View (detailed session cards)
  - Calendar View (date-based organization)

- ✅ **Filters**:
  - All / Upcoming / Completed / Missed
  - Active filter highlighting

- ✅ **Today's Sessions** (Priority section):
  - Highlighted in lime gradient
  - Shows all sessions for current day
  - Countdown to next session

- ✅ **Session Cards**:
  - Client photo and name
  - Sport emoji (🥊, 🧘, 💪, 🏃)
  - Date and time
  - Duration
  - Location (with MapPin icon)
  - Status badge (Upcoming/Completed/Missed)
  - Session notes
  - Color-coded status icons

- ✅ **Calendar Integration**:
  - ShadCN Calendar component
  - Click date → View sessions for that day
  - Visual indicators for scheduled days

- ✅ **AI Schedule Optimization**:
  - Detects open time slots
  - Example: "You have 3 open slots on Friday"
  - Suggests clients to fill gaps
  - "Auto-Fill Slots" button

- ✅ **Add Session**:
  - Quick modal (basic for now)
  - Full scheduling interface coming soon

**Future Integration**:
- Google Calendar sync
- Apple Calendar sync
- Recurring session patterns

---

### 4. 📦 Packages & Services
**Component**: `CoachPackages.tsx`

**Purpose**: Create, edit, and manage training programs

**Features**:
- ✅ **Package Overview Stats**:
  - Total packages count
  - Total revenue from packages
  - Total purchases
  - Average rating

- ✅ **Package Cards** (Grid layout):
  - Sport emoji indicator
  - Title and category
  - Description
  - Price, Duration, Session count
  - Add-ons list (Nutrition, Video check-ins, etc.)
  - Visibility toggle (Public/Hidden eye icon)
  - Analytics (Purchases, Rating, Retention %)
  - Edit button

**Package Example**:
```
🥊 Boxing Fundamentals
$199 | 4 weeks | 10 sessions
+ Nutrition plan
+ Video check-ins

28 Purchases | 4.9★ | 93% Retention
```

- ✅ **Visibility Control**:
  - Eye icon toggle (Public/Hidden)
  - Hidden packages not visible to clients
  - Useful for drafts or exclusive offers

- ✅ **Analytics per Package**:
  - Purchase count
  - Star rating
  - Client retention rate
  - Revenue contribution

- ✅ **AI Business Insight**:
  - "Boxing package generates 60% revenue"
  - "Consider creating advanced version"
  - Upsell suggestions

- ✅ **VITA Marketplace Teaser**:
  - Coming soon feature
  - Sell digital programs beyond local area
  - Join waitlist button

**Future Features**:
- Package builder with drag-and-drop
- Pricing tiers
- Bundle discounts
- Seasonal packages

---

### 5. 💰 Earnings & Analytics
**Component**: `CoachEarnings.tsx`

**Purpose**: Business transparency + financial insights

**Features**:
- ✅ **Revenue Dashboard**:
  - Total Revenue (all-time)
  - This Month earnings
  - Available balance (after VITA 10% fee)
  - Pending amount (processing)

- ✅ **Charts**:
  - Line Chart: Revenue over time (6 months)
  - Pie Chart: Revenue by package breakdown
  - Color-coded segments

- ✅ **Package Profitability**:
  - Percentage breakdown
  - Top revenue generators highlighted
  - Visual pie chart with legend

- ✅ **AI Financial Insights**:
  - "Boxing package generates 60% income"
  - "Create advanced version → +35% LTV"
  - Upsell recommendations
  - Growth strategies

- ✅ **Payout Settings**:
  - Bank account details (masked)
  - Next payout date
  - Withdrawal button
  - Service fee transparency (10%)

- ✅ **Fee Structure**:
  - VITA takes 10-15% service fee
  - Displayed clearly
  - Industry standard comparison

**Graphs**:
- Monthly revenue trend (6-month view)
- Package distribution (pie chart)
- Top clients by spend (future)

---

### 6. 🧠 AI Coach Assistant
**Component**: `CoachAI.tsx`

**Purpose**: Personalized business intelligence and automation

**Features**:
- ✅ **Four AI Categories**:

  **1. Client Retention** (Users icon, Lime)
  - Risk detection ("Khoa hasn't trained in 5 days")
  - Milestone tracking ("3 clients approaching 30-day streak")
  - Benchmark comparison ("86% vs top 10% at 92%")

  **2. Business Growth** (TrendingUp icon, Blue)
  - Revenue optimization ("60% from boxing - create advanced version")
  - Content timing ("Best posting: Friday 6PM, +18% engagement")
  - Schedule optimization ("Fill 3 Friday slots automatically")

  **3. Content Strategy** (Lightbulb icon, Magenta)
  - Post suggestions ("30-sec recovery tip video")
  - Social proof prompts ("Share Mai's progress story")
  - Tutorial recommendations ("Create warmup tutorial")

  **4. Client Communication** (MessageCircle icon, Orange)
  - Auto-draft messages ("Congratulate Huy on 30-day streak")
  - Weekly summaries ("Send to 5 clients who prefer written feedback")
  - Follow-up reminders ("3 clients haven't responded")

- ✅ **Performance Benchmarks**:
  - Your metrics vs Top 10%
  - Client retention: 86% (vs 92%)
  - Response time: 12min (vs <15min)
  - Session quality: 4.9★ (vs 4.8+)
  - Visual progress bars

- ✅ **Quick Actions**:
  - "Generate Weekly Report"
  - "Auto-Draft Messages"
  - "Apply" buttons for each insight

- ✅ **Future Features Teaser**:
  - Auto-generate workout plans
  - Real-time form correction (computer vision)
  - Predictive churn prevention
  - Voice-activated notes
  - Automated progress reports

**Intelligence Layer**:
This becomes VITA's core AI advantage - not just analytics, but actionable insights.

---

### 7. 📚 Content & Media Library
**Component**: `CoachLibrary.tsx`

**Purpose**: Upload and manage training videos, clips, tutorials

**Features**:
- ✅ **Media Stats**:
  - Total videos count
  - Images count
  - Documents count
  - Total views across all content

- ✅ **Content Grid**:
  - Video thumbnails
  - Play button overlay on hover
  - Duration badge
  - Title and description
  - Tag system (Warmup, Technique, Strength, etc.)
  - View count
  - Upload date
  - Edit and Delete buttons

- ✅ **Tag System**:
  - Categorize content
  - Warmup, Technique, Strength, Mobility, etc.
  - Filter by tag

- ✅ **AI Video Editor** (Coming Soon):
  - Auto-cut 10-sec highlight reels
  - For VITA Reels and social media
  - AI-powered scene detection
  - Auto-captioning
  - Join Beta Waitlist button

- ✅ **Upload Button**:
  - Top-right action
  - Support for videos, images, documents

- ✅ **VITA Creator Platform** (Q1 2026):
  - Build and sell online courses
  - Course builder tools
  - Student management
  - Monetization features
  - Early access application

**Use Cases**:
- Store technique demonstration videos
- Library of workout plans
- Client progress photos
- Nutrition guides (PDFs)

**Future Integration**:
- VITA Reels (short-form content feed)
- Course platform
- Digital product sales

---

### 8. ⚙️ Profile & Settings
**Component**: `CoachProfile.tsx`

**Purpose**: Account management and business configuration

**Features**:
- ✅ **Profile Header**:
  - Profile photo with camera edit button
  - Name and title
  - Premium Coach badge
  - Verified badge

- ✅ **Personal Information**:
  - Full name
  - Email address
  - Phone number
  - Location (with flag)
  - Edit button

- ✅ **Certifications**:
  - List of verified credentials
  - Award icons
  - Verification badges
  - "Add Certificate" button
  - Examples:
    - WBC Professional Boxing Certification
    - ACE Personal Training Certificate

- ✅ **Business Settings**:
  - Payout method (bank account)
  - Availability calendar (Mon-Fri 6AM-8PM)
  - Edit buttons for each setting

- ✅ **App Settings**:
  - Push notifications toggle
  - Language selection
  - Region settings

- ✅ **Logout Button**:
  - Red accent (destructive action)
  - Confirmation required
  - Returns to Auth page

**Certification Verification**:
AI-powered verification system (future) will auto-verify credentials through image upload.

---

## Navigation Flow

### Complete User Journey
```
Auth Page → Sign Up as Coach
    ↓
Coach Dashboard (8-tab interface with bottom nav)
    ├── Dashboard (default view)
    ├── Clients
    │   └── Click client → Client Detail Screen
    │       └── Back button → Returns to Clients tab
    ├── Sessions
    │   ├── List View
    │   └── Calendar View
    ├── Packages
    ├── Earnings
    ├── AI Assistant
    ├── Library
    └── Profile
        └── Logout → Returns to Auth
```

### Tab Switching
- Bottom navigation always visible
- Active tab highlighted (lime background)
- Smooth transitions between tabs
- Top header remains fixed
- Each tab has independent scroll

---

## Component Architecture

### File Structure
```
/components
├── CoachDashboard.tsx ← Main container
├── CoachBottomNav.tsx ← Taskbar navigation
├── CoachOverview.tsx ← Dashboard tab
├── CoachClients.tsx ← Clients module
├── CoachSessions.tsx ← Sessions module
├── CoachPackages.tsx ← Packages module
├── CoachEarnings.tsx ← Earnings module
├── CoachAI.tsx ← AI Assistant module
├── CoachLibrary.tsx ← Content library
└── CoachProfile.tsx ← Settings & profile
```

### State Management
```typescript
// CoachDashboard.tsx
const [activeTab, setActiveTab] = useState<
  "dashboard" | "clients" | "sessions" | 
  "packages" | "earnings" | "ai" | 
  "library" | "profile"
>("dashboard");
```

### Conditional Rendering
```tsx
{activeTab === "dashboard" && <CoachOverview />}
{activeTab === "clients" && <CoachClients onClientSelect={onClientSelect} />}
{activeTab === "sessions" && <CoachSessions />}
// ... etc
```

---

## Design System

### Taskbar Styling
- Background: `#0f0f0f/95` with backdrop blur
- Border: Top border `white/10`
- Active tab: `#c6ff00/20` background, lime text
- Inactive: `white/60` with hover effects
- Icon size: 20px (w-5 h-5)
- Label: 10px text

### Tab Badges
```tsx
<span className="px-2 py-0.5 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
  COACH
</span>
```

### Consistent Header
Every tab has the same sticky header:
- VITΛ logo with COACH badge
- Notification bell (with red dot)
- Settings icon
- Profile avatar

---

## Responsive Design

### Desktop (1024px+)
- 8 tabs visible with labels
- Multi-column layouts
- Side-by-side charts

### Tablet (768px - 1023px)
- All tabs visible (may wrap)
- 2-column grids
- Stacked charts

### Mobile (<768px)
- Horizontal scroll for tabs (if needed)
- Icon-only labels (text-[10px])
- Single column layouts
- Touch-friendly targets

---

## AI Integration Points

### Across All Modules

**Clients Module**:
- Risk detection algorithms
- Engagement pattern analysis
- Retention predictions

**Sessions Module**:
- Schedule optimization
- Time slot recommendations
- Client-session matching

**Packages Module**:
- Revenue analysis
- Upsell suggestions
- Package performance comparison

**Earnings Module**:
- Financial insights
- Growth projections
- Profitability optimization

**AI Assistant**:
- Centralized intelligence hub
- Pattern recognition
- Actionable recommendations

**Library**:
- Auto-editing (future)
- Content suggestions
- Engagement analytics

---

## Key Differences from Athlete Interface

| Feature | Athlete UI | Coach UI |
|---------|-----------|----------|
| Tabs | 5 (Home, Calendar, Coaches, Messages, Profile) | 8 (Dashboard, Clients, Sessions, Packages, Earnings, AI, Library, Profile) |
| Focus | Training & booking | Business management |
| AI | Fitness recommendations | Business intelligence |
| Calendar | Personal training schedule | Client session management |
| Content | Social feed | Content library & creation |
| Payments | Wallet & deposits | Earnings & payouts |
| Clients | Book coaches | Manage roster |

---

## Testing Checklist

### Navigation
- ✅ Click each tab in bottom nav
- ✅ Verify active state highlighting
- ✅ Check tab transitions are smooth
- ✅ Test on mobile (horizontal scroll)

### Modules
- ✅ Dashboard loads with charts
- ✅ Clients tab shows grid of clients
- ✅ Click client → Opens Client Detail
- ✅ Back button → Returns to Clients tab
- ✅ Sessions toggle List/Calendar views
- ✅ Packages show with visibility toggle
- ✅ Earnings displays revenue charts
- ✅ AI shows categorized insights
- ✅ Library displays media grid
- ✅ Profile shows personal info
- ✅ Logout button works

### Responsiveness
- ✅ Desktop: All layouts render properly
- ✅ Tablet: Grids adjust to 2 columns
- ✅ Mobile: Single column stacking

---

## Future Enhancements

### Phase 2 Features
- [ ] Real API integration (replace mock data)
- [ ] Google/Apple Calendar sync
- [ ] Package builder with drag-and-drop
- [ ] Advanced AI predictions
- [ ] Video editing tools
- [ ] Course creation platform
- [ ] Marketplace integration
- [ ] Team coaching (multiple coaches)

### Performance Ranking Module (Future)
- Top coaches leaderboard
- Flow Score for coaches
- City/region rankings
- Highlight cards
- Status motivation system

---

## Summary

The coach interface transformation is complete:

**Before**: Single-page dashboard with sidebar
**After**: 8-module taskbar navigation system

**Benefits**:
1. ✅ Organized feature separation
2. ✅ Scalable architecture
3. ✅ Consistent navigation pattern (matches athlete UI)
4. ✅ Room for future expansion
5. ✅ Better mobile experience
6. ✅ Dedicated AI module
7. ✅ Comprehensive business tools
8. ✅ Professional coach platform

**Status**: ✅ Fully Implemented & Ready
**Last Updated**: November 2, 2025

---

**Navigation Summary**:
```
Dashboard → Overview & quick actions
Clients → Roster management & AI alerts
Sessions → Schedule & calendar
Packages → Service offerings
Earnings → Financial analytics
AI → Business intelligence
Library → Content management
Profile → Settings & logout
```

All features now accessible via intuitive bottom taskbar! 🎉
