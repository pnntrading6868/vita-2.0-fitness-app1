# VITA - Product Requirements Document
**Version:** 2.0  
**Last Updated:** November 4, 2025  
**Location:** Dubai, UAE

---

## Table of Contents
1. [Product Overview](#product-overview)
2. [Design System](#design-system)
3. [Core Features - Athlete Interface](#core-features---athlete-interface)
4. [Core Features - Coach Interface](#core-features---coach-interface)
5. [User Flows](#user-flows)
6. [Technical Specifications](#technical-specifications)
7. [Component Architecture](#component-architecture)
8. [Data Models](#data-models)
9. [Navigation Structure](#navigation-structure)

---

## Product Overview

### Product Name
**VITA** (styled as VIT**Λ** with reversed lambda)

### Product Vision
VITA is a premium sports fitness application designed for Dubai residents seeking world-class coaching across 14 different athletic disciplines. The app connects users with expert coaches, provides AI-powered fitness guidance, and delivers a seamless booking and payment experience. Version 2.0 introduces a comprehensive Coach Dashboard, enabling coaches to manage their business operations directly within the app.

### Target Audience
- **Athletes/Users:** Fitness enthusiasts in Dubai seeking professional coaching
- **Coaches:** Professional trainers looking to manage clients, sessions, and business operations
- **Individuals:** Looking for structured training programs across multiple sports
- **Multi-sport enthusiasts:** Interested in training packages with multiple coaches

### Core Value Proposition
- Access to 31+ verified expert coaches across 14 sports
- AI-powered fitness guidance and program recommendations
- Flexible scheduling with multi-session package options
- Integrated wallet system with multiple payment methods
- Comprehensive progress tracking and performance analytics
- **NEW:** Complete coach business management dashboard
- **NEW:** CRM-style client management with detailed profiles
- **NEW:** Mission-focused home dashboard with curated feeds
- **NEW:** Personal performance metrics and session history

---

## Design System

### Brand Identity

#### Color Palette (Dark Mode)
- **Primary Background:** `#0A0A0A` / `#0f0f0f` (Deep black)
- **Primary Accent:** `#c6ff00` (Vibrant lime green)
- **Secondary Accent:** `#b5e600` (Yellow-green)
- **Tertiary Accent:** `#9fd600` (Olive green)
- **Text Primary:** `#ffffff` (White)
- **Text Secondary:** `rgba(255, 255, 255, 0.6)` (60% white)
- **Text Tertiary:** `rgba(255, 255, 255, 0.4)` (40% white)
- **Border/Divider:** `rgba(255, 255, 255, 0.1)` (10% white)
- **Card Background:** `rgba(255, 255, 255, 0.05)` (5% white)

#### Typography
- **Font Family:** Inter
- **Font Weights:** 200 (Light), 400 (Regular), 500 (Medium), 600 (Semi-bold), 700 (Bold), 800 (Extra-bold)
- **Letter Spacing:** Negative spacing for premium feel
  - Headers: -0.02em to -0.005em
  - Body: -0.003em
  - Buttons: -0.005em
- **Base Font Size:** 16.5px

#### Spacing System
- Uses 5-unit increments (5px, 10px, 15px, 20px, 25px, etc.)
- Consistent padding and margins across components

#### Visual Effects
- **Glassmorphism:** Backdrop blur with semi-transparent backgrounds
- **Drop Shadows:** Strategic use on floating elements and buttons
- **Glows:** Green glow effects on active/selected states
- **Rounded Corners:** 12px-24px for cards and containers

### Logo
- Text: "VIT**Λ**" with reversed lambda (Λ)
- Letter spacing: 0.1em - 0.15em
- Font weight: 200 (Ultra light)
- Color: White with drop shadow

---

## Core Features - Athlete Interface

### 1. Home Page (Mission Dashboard)

#### Overview
The home page has been redesigned from a social media-style feed into a focused mission dashboard with four distinct feed sections.

#### Performance Feed
- **Personal Stats Display:**
  - Current weekly goal progress
  - Total sessions completed
  - Active streak counter
  - Calories burned this week
- **Quick Actions:**
  - Book next session
  - View full stats
  - Message coaches
- **Visual Design:**
  - Green gradient cards
  - Progress bars with animations
  - Trophy and achievement icons

#### Coach Spotlight Feed
- **Featured Coaches:**
  - Rotating spotlight on top-rated coaches
  - Specialization highlights
  - Available session counts
  - Direct booking CTAs
- **Coach Cards:**
  - Profile images with verified badges
  - Rating and review count
  - Hourly rate display
  - Quick view/book buttons

#### AI Curated Feed
- **Personalized Recommendations:**
  - AI-suggested workouts based on history
  - Recommended coaches matching goals
  - Package suggestions
  - Training tips and insights
- **AI Fitness Guide Button:**
  - Fixed position bottom-right
  - Green glow effect with pulse animation
  - Real-time chat interface
  - Contextual fitness advice

#### Weekly Highlights Section
- **Recent Achievements:**
  - Completed sessions summary
  - New personal records
  - Unlocked achievements
  - Milestone celebrations
- **Upcoming Sessions:**
  - Next 3 scheduled sessions
  - Coach information
  - Time and location
  - Quick reschedule options

#### Location Selector
- **Functionality:**
  - Dropdown selector for 8 Dubai areas
  - Current selection: Dubai Marina (default)
  - Available locations: Dubai Marina, Downtown Dubai, Jumeirah, Business Bay, DIFC, JBR, Palm Jumeirah, Dubai Hills
  - Affects coach distance calculations

### 2. Calendar Tab

#### Views
1. **Day View**
   - Hourly time slots (6 AM - 10 PM)
   - Booked sessions with coach info
   - Available time indicators
   - Real-time current time marker

2. **Week View**
   - 7-day grid layout
   - Compact session cards
   - Sport type indicators
   - Quick navigation between weeks

3. **Month View**
   - Traditional calendar grid
   - Session count dots per day
   - Visual density indicators
   - Month navigation

#### Session Cards
- Coach profile image
- Sport type with emoji
- Session time and duration
- Location information
- Quick actions (view details, cancel)

#### Session Management
- Click on session → View full details
- Session details include:
  - Coach profile link
  - Location with map preview
  - Session notes
  - Cancellation policy reminder

### 3. Coaches Profile

#### Sports Selection Grid
- **14 Sports:**
  1. Tennis 🎾
  2. Pickleball 🏓
  3. Paddle 🏓
  4. Badminton 🏸
  5. Yoga 🧘
  6. Pilates 🤸
  7. Strength Training 💪
  8. Weightlifting 🏋️
  9. CrossFit 🏃
  10. Boxing 🥊
  11. Muay Thai 🥋
  12. MMA 🥊
  13. BJJ 🥋
  14. Sports Therapy 💆

#### Coach Cards
- **Layout:** Full-screen immersive cards
- **Swipe Interaction:** Horizontal carousel
- **Information Displayed:**
  - Profile image
  - Name and specialty
  - Years of experience
  - Certifications (badges)
  - Rating (out of 5 stars)
  - Review count
  - Client count
  - Hourly rate (AED)
  - Location and distance
  - Bio
  - Reviews (3 most recent)

#### Filtering System
- **Filter Sheet:** Bottom drawer
- **Filter Options:**
  - Location (multiple selection)
  - Sports (multiple selection)
  - Price range (slider: AED 0-200)
  - Minimum rating (0-5 stars)
  - Maximum distance (slider: 0-50 km)

#### Coach Detail Profile
- **Accessed via:** Clicking coach card or coach image in packages
- **Sections:**
  1. **Cover Image & Header**
     - Hero image
     - Profile picture (24px rounded)
     - Name, sport, location
     - Rating and stats
  
  2. **Quick Stats Grid**
     - Years of experience
     - Sessions completed
     - Total reviews
  
  3. **Tabs:**
     - **About:** Bio, specialties, experience, certifications, service area, training gallery
     - **Reviews:** Client testimonials with verification badges
     - **Results:** Client transformations (images, videos, testimonials)
  
  4. **Available Packages**
     - Package name
     - Session count
     - Duration
     - Price (AED)
     - Click to book → Navigate to booking flow

#### Coach Database (31 Coaches)
- Marcus Johnson (Strength & Conditioning)
- Ahmed Al-Rashid (Running & HIIT)
- Elena Rodriguez (Yoga & Mobility)
- Carlos Rivera (Pickleball)
- Jackson Hayes (Boxing)
- Sarah Mitchell (Tennis)
- And 25+ more across all 14 sports

### 4. Messages Tab

#### Conversation List
- **Layout:** Chat list with preview
- **Information per chat:**
  - Coach profile image
  - Coach name
  - Last message preview
  - Timestamp
  - Unread indicator
  - Online status

#### Chat Interface
- **Features:**
  - Full-screen chat view
  - Message bubbles (sent/received)
  - Timestamp grouping
  - Quick replies
  - Attachment support
  - Voice message capability

### 5. Profile Tab (Redesigned)

#### Profile Header
- Cover image with camera button
- Profile picture (28x28 rounded)
- Name and username
- Edit profile button
- Bio text
- Location and join date

#### Wallet Integration
- **Prominent Green Button**
  - Gradient: `#c6ff00` to `#b5e600`
  - Shadow: `0_4px_24px_rgba(198,255,0,0.25)`
  - Icon: Wallet icon in black/10 background circle
  - Text: "My Wallet" with subtitle "Manage deposits & funds"
  - Opens wallet in full-screen modal

#### Personal Performance Metrics (NEW)

##### Flow Index Score
- **Large Featured Card:**
  - Circular progress indicator (0-100)
  - Current score: 72
  - Weekly trend indicator (+3 this week)
  - Color-coded performance levels:
    - 80-100: Green (Excellent)
    - 60-79: Yellow (Good)
    - 40-59: Orange (Fair)
    - 0-39: Red (Needs Work)
  - AI-generated insights

##### Performance Overview Grid
- **Total Sessions Card**
  - Large count display
  - Trophy icon
  - Trend indicator (+12% this month)

- **Training Hours**
  - Total hours tracked
  - Average per week

- **Secondary Stats Grid (3 columns):**
  - Current streak (flame icon)
  - Average rating received (star icon)
  - Active packages (target icon)

##### Weekly Goal Progress
- Progress bar with gradient
- Current vs. target sessions
- Motivational messaging
- Completion percentage

##### Weekly Activity Chart
- Bar chart (7 days)
- Height-based visualization
- Session count per day
- Green highlights for active days

##### Calories & Performance
- Total calories burned (all-time)
- Performance improvement percentage
- Monthly comparisons

#### Past Sessions Records (NEW)

##### Recent Sessions List
- **Expandable Cards:**
  - Coach name and profile image
  - Sport type with emoji
  - Date and time
  - Duration
  - Location
  - Session notes (when expanded)
  - Rating given
  - Photos/videos from session

##### Session History Filters
- Filter by sport
- Filter by coach
- Filter by date range
- Sort by recent/oldest

##### Session Statistics
- Total sessions by sport
- Most frequent coach
- Favorite training time
- Average session duration

#### Achievements
- **Grid Layout:** 2 columns
- **Achievement Types:**
  - First Step (complete first session)
  - Week Warrior (3 sessions in one week)
  - Consistency King (7-day streak)
  - Champion (50 total sessions)
  - Century Club (100 sessions)
  - Multi-Sport Athlete (3+ sports)
- **States:**
  - Unlocked: Green gradient with checkmark
  - Locked: Gray with progress bar

#### Past Coaches
- List of previous coaches
- Total sessions per coach
- Last session date
- Average rating given
- Quick rebook/message buttons

#### Training Packages & Sessions Tabs
- **Packages Tab:**
  - Active package progress
  - Completed packages
  - Package details (sessions, dates)
  - Progress percentage bars
  - Remaining sessions counter

- **Sessions Tab:**
  - Recent session history
  - Session details (coach, sport, date, time, duration)
  - Session ratings
  - Performance notes

### 6. Wallet (Accessed from Profile)

#### Balance Display
- **VITA Balance Card**
  - Gradient green background
  - Large balance display (AED)
  - "Available for sessions" label
  - Shadow with green tint

- **Token Balance Card**
  - Dark background
  - Token count
  - Purpose: Zero-fee cancellations

#### Quick Actions
- Deposit funds
- Transfer funds
- View transaction history
- Download statements

#### Deposit Flow
1. **Enter Amount**
   - Quick amount buttons (50, 100, 200, 500)
   - Custom amount input
   - Continue button

2. **Select Payment Method**
   - Bank Transfer (0% fee)
   - Debit Card (0% fee)
   - Credit Card (2.5% fee)
   - Visual indicators for each method

3. **Deposit Confirmation**
   - Amount summary
   - Payment method
   - Processing fees (if applicable)
   - Total breakdown
   - Bank transfer instructions (if selected)
   - Confirm button

#### Transaction History
- **List Format:**
  - Date
  - Type (deposit/session payment)
  - Amount (+ or -)
  - Status
  - Payment method or coach name
- **Export Options:**
  - PDF statement
  - CSV export
  - Date range selection

#### Binance-Style Interface
- Clean, minimalist design
- Clear hierarchy
- Real-time balance updates
- Transaction confirmation modals

### 7. Package Booking Flow

#### Step 1: Package Details & Price Breakdown
- **Package Overview:**
  - Package name and duration
  - Total sessions count
  - Discount indicator (15% OFF badge)

- **Coaching Team:**
  - List of assigned coaches
  - Sessions per coach
  - Sport specialization
  - Clickable to view coach profiles

- **Price Breakdown:**
  - Base price
  - Package discount (-15%)
  - Subtotal
  - VAT (5%)
  - **Total in green**
  - Info banner: Deposit requirement and cancellation policy

- **What's Included:**
  - Personalized training sessions
  - Multiple expert coaches
  - Progress tracking
  - Nutrition guidance
  - 24/7 chat support
  - Flexible scheduling
  - Video technique analysis

#### Step 2: Payment Options
- **Payment Plans:**
  1. **Pay in Full**
     - One-time payment
     - 5% savings bonus
     - Highlighted savings badge

  2. **3-Month Plan**
     - 20% deposit upfront
     - 3 monthly installments
     - 2% convenience fee
     - Monthly breakdown displayed

  3. **6-Month Plan**
     - 20% deposit upfront
     - 6 monthly installments
     - 4% convenience fee
     - Monthly breakdown displayed

- **Payment Method:**
  - VITA Wallet (shows current balance)
  - Credit/Debit Card

- **Payment Summary:**
  - Due today amount
  - Remaining payments (if installment)
  - Total overview

#### Step 3: Schedule Confirmation
- Success confirmation screen
- Calendar icon with animation
- Next steps instructions
- Individual coach booking reminders
- "Complete Purchase" button → Navigate to Calendar

#### Cancellation Policy
- **20% fee** for cash refunds
- **0% fee** for in-app token conversion
- **Maximum 15%** package discounts
- **20% deposit** required for all packages

### 8. Map View

#### Features
- Full-screen map interface
- Coach location markers
- Gym location markers
- Distance calculations
- Filter by sport type
- Back navigation to coaches list

---

## Core Features - Coach Interface

### Overview
The Coach Dashboard is a completely separate interface from the athlete view, accessed through coach login credentials. It features its own navigation system with 7 comprehensive modules for complete business management.

### Coach Dashboard Navigation

#### Top Header Bar (Fixed)
- **VITΛ Logo** with "COACH" badge in lime green
- **Notification Bell** with unread indicator
- **Settings Icon**
- **Coach Profile Picture** with status ring

#### Bottom Navigation (7 Modules)
1. **Dashboard** - Overview and earnings
2. **Clients** - Client management and CRM
3. **Sessions** - Schedule and session management
4. **Packages** - Package creation and management
5. **AI Assistant** - AI coaching tools
6. **Library** - Resources and content
7. **Profile** - Coach profile and settings

### 1. Dashboard Module

#### Quick Stats Grid (4 Cards)
- **Total Earnings (This Month)**
  - Large AED amount display
  - Month-over-month trend (+18.5%)
  - Green gradient background
  - Sparkline chart

- **Active Clients**
  - Current client count
  - New clients this month
  - Client retention rate

- **Sessions This Week**
  - Upcoming session count
  - Completed sessions
  - Cancellation rate

- **Avg Rating**
  - Star rating display (4.9/5.0)
  - Total reviews count
  - Recent feedback summary

#### Revenue Chart
- **Monthly Revenue Visualization:**
  - 6-month bar chart
  - Revenue trends
  - Comparison to previous period
  - Hover tooltips with details

#### Earnings Breakdown
- **Income Sources:**
  - Package sales revenue
  - Individual session revenue
  - Consultation fees
  - Commission breakdown
  - Pending payments
  - Payment schedule

#### Today's Schedule
- **Session Timeline:**
  - Time slots with client info
  - Sport type indicators
  - Location details
  - Quick actions (start/cancel/reschedule)
  - Travel time between sessions

#### Recent Activity Feed
- New client sign-ups
- Session completions
- Package purchases
- Review submissions
- Payment confirmations

### 2. Clients Module (CRM)

#### Client Overview
- **Search & Filter Bar:**
  - Search by name
  - Filter by sport
  - Filter by status (Active/Inactive/All)
  - Sort options (Name, Flow Index, Last Session)

#### AI Suggestions (Top Banner)
- **Automated Client Insights:**
  - "Emily needs attention - No session in 6 days"
  - "Schedule follow-up with David"
  - "Jessica ready for level progression"
  - One-click actions from suggestions

#### Client Statistics Grid
- Total active clients
- New clients this month
- Retention rate
- Average client LTV

#### Client List (15 Detailed Profiles)

Each client card features:

##### Collapsed View
- **Client Name** with profile image
- **Sport** with emoji indicator
- **Flow Index Score** (0-100 with color coding)
- **Trend Indicator** (Improving/Stable/Declining)
- **Current Streak** (days)
- **Last Session** (time ago)
- **Expand Button** (chevron icon)

##### Expanded View (Comprehensive CRM Data)

**1. Contact & Personal Information**
- Full name, age, gender
- Phone number (click to call)
- Email address (click to email)
- Location/address
- Emergency contact

**2. Goals & Progress**
- Primary fitness goals (list)
- Current progress status
- Goal achievement percentage
- Key milestones reached
- Target completion dates

**3. Package & Financials**
- Active package details
  - Package name
  - Sessions remaining (X of Y)
  - Package end date
  - Package value
- Payment status
- Outstanding balance
- Payment history
- Next payment due date
- Total lifetime value

**4. Recent Sessions**
- Last 5 sessions with dates
- Session duration
- Performance notes
- Client feedback
- No-shows/cancellations

**5. Achievements & Milestones**
- Personal records
- Skills acquired
- Improvement metrics
- Certificates earned
- Achievement badges

**6. Coach Notes (Private)**
- Free-form notes section
- Training observations
- Client preferences
- Areas of focus
- Injury considerations
- Progress notes with timestamps

**7. Medical Notes & Restrictions**
- Health conditions
- Injuries (current/past)
- Physical limitations
- Medication information
- Clearance status
- Doctor's notes

**8. Training Preferences**
- Preferred training times
- Location preferences
- Training intensity preference
- Music preferences
- Communication style
- Motivation factors

**9. Communications Log**
- Message history
- Last contact date
- Scheduled check-ins
- Important conversations
- Follow-up reminders

**10. Quick Actions**
- Schedule session button
- Send message button
- Add note button
- View full history button
- Edit client info button

#### Client Profiles Database (15 Clients)

1. **Huy Nguyen** (Boxing 🥊)
   - Flow Index: 72 (Improving)
   - Streak: 21 days
   - Goals: Competition prep, stamina building
   - Package: 12/20 sessions remaining

2. **Emily Carter** (Yoga 🧘)
   - Flow Index: 65 (Stable)
   - Streak: 14 days
   - Goals: Flexibility, stress relief
   - Package: 8/15 sessions remaining

3. **Marcus Lee** (Strength Training 💪)
   - Flow Index: 81 (Improving)
   - Streak: 28 days
   - Goals: Muscle gain, powerlifting
   - Package: 15/30 sessions remaining

4. **Sarah Johnson** (Tennis 🎾)
   - Flow Index: 58 (Declining)
   - Streak: 3 days
   - Goals: Tournament preparation
   - Package: 5/20 sessions remaining

5. **David Kim** (CrossFit 🏃)
   - Flow Index: 74 (Improving)
   - Streak: 19 days
   - Goals: Endurance, competition
   - Package: 22/40 sessions remaining

6. **Jessica Martinez** (Pilates 🤸)
   - Flow Index: 69 (Stable)
   - Streak: 12 days
   - Goals: Core strength, posture
   - Package: 10/15 sessions remaining

7. **Ahmed Hassan** (MMA 🥊)
   - Flow Index: 77 (Improving)
   - Streak: 25 days
   - Goals: Self-defense, fitness
   - Package: 18/25 sessions remaining

8. **Lisa Wong** (Badminton 🏸)
   - Flow Index: 63 (Stable)
   - Streak: 8 days
   - Goals: Competition play, agility
   - Package: 6/12 sessions remaining

9. **Ryan O'Connor** (Muay Thai 🥋)
   - Flow Index: 79 (Improving)
   - Streak: 31 days
   - Goals: Fight prep, technique
   - Package: 20/30 sessions remaining

10. **Nina Patel** (Weightlifting 🏋️)
    - Flow Index: 71 (Improving)
    - Streak: 16 days
    - Goals: Olympic lifts, strength
    - Package: 14/24 sessions remaining

11. **James Brown** (BJJ 🥋)
    - Flow Index: 66 (Stable)
    - Streak: 11 days
    - Goals: Belt progression, competition
    - Package: 9/18 sessions remaining

12. **Sophia Chen** (Sports Therapy 💆)
    - Flow Index: 60 (Recovering)
    - Streak: 5 days
    - Goals: Injury recovery, mobility
    - Package: 4/10 sessions remaining

13. **Carlos Rodriguez** (Paddle 🏓)
    - Flow Index: 75 (Improving)
    - Streak: 22 days
    - Goals: Tournament level, strategy
    - Package: 16/20 sessions remaining

14. **Emma Thompson** (Pickleball 🏓)
    - Flow Index: 68 (Stable)
    - Streak: 13 days
    - Goals: Social play, technique
    - Package: 11/15 sessions remaining

15. **Yuki Tanaka** (Tennis 🎾)
    - Flow Index: 82 (Improving)
    - Streak: 35 days
    - Goals: Professional development
    - Package: 25/40 sessions remaining

### 3. Sessions Module

#### Session Overview
- **Filter & Sort:**
  - View by date range
  - Filter by status (Upcoming/Completed/Cancelled)
  - Filter by client
  - Filter by location

#### AI Auto-Suggest (Top Banner)
- **Intelligent Scheduling:**
  - "Optimal time for Ahmed: Tomorrow 6 PM"
  - "Fill gap: Wednesday 2 PM available"
  - "Reschedule conflict detected"

#### Session Cards
- **Upcoming Sessions:**
  - Client name and photo
  - Sport type
  - Date and time
  - Duration
  - Location
  - Client notes/requests
  - Pre-session checklist
  - Start session button

- **Completed Sessions:**
  - Session summary
  - Duration tracked
  - Client attendance
  - Post-session notes
  - Client rating received
  - Add performance notes button

#### Session Actions
- Create new session
- Bulk reschedule
- Cancel with notification
- Mark as completed
- Add session notes
- Send pre-session reminders

#### Session Statistics
- Total sessions this month
- Completion rate
- Average session duration
- No-show rate
- Client satisfaction scores

### 4. Packages Module

#### Package Management
- **Create New Package Button** (Lime green CTA)

#### Active Packages List
- Package name and description
- Number of sessions included
- Duration/validity period
- Price (AED)
- Number of active clients
- Total revenue from package
- Edit/Duplicate/Archive buttons

#### Package Templates
- **Pre-built Templates:**
  - Beginner Package (10 sessions, 30 days)
  - Intermediate Package (20 sessions, 60 days)
  - Advanced Package (30 sessions, 90 days)
  - Competition Prep (40 sessions, 120 days)

#### Package Builder
- **Customization Options:**
  - Package name
  - Description
  - Session count
  - Validity period
  - Price
  - Discount options
  - Inclusions list
  - Terms & conditions

#### Package Analytics
- Most popular packages
- Conversion rates
- Average package value
- Package completion rates

### 5. AI Assistant Module

#### AI Coach Tools
- **Workout Plan Generator:**
  - Client goal input
  - AI-generated programs
  - Exercise library integration
  - Progressive overload planning

#### AI Chat Interface
- **Coaching Support:**
  - Program design questions
  - Client issue troubleshooting
  - Nutrition advice
  - Injury prevention tips
  - Business advice

#### AI Insights Dashboard
- **Automated Analytics:**
  - Client progress summaries
  - Training pattern analysis
  - Revenue optimization suggestions
  - Schedule efficiency tips

#### Content Generator
- **Marketing Tools:**
  - Social media post generator
  - Client newsletter templates
  - Promotional content
  - Success story formatter

### 6. Library Module

#### Resource Categories
- **Workout Templates:**
  - By sport type
  - By experience level
  - By goal type
  - Custom templates

- **Exercise Library:**
  - Video demonstrations
  - Written instructions
  - Muscle group targeting
  - Equipment requirements

- **Nutrition Plans:**
  - Meal plan templates
  - Macro calculators
  - Supplement guides
  - Hydration plans

- **Business Resources:**
  - Client onboarding docs
  - Contract templates
  - Waiver forms
  - Payment terms

#### Content Upload
- Upload custom videos
- Create exercise guides
- Save favorite resources
- Share with clients

#### Search & Filter
- Search by keyword
- Filter by category
- Filter by sport
- Recently used items

### 7. Profile Module

#### Coach Profile Display
- **Public Profile Preview:**
  - Profile photo
  - Cover image
  - Name and specialties
  - Bio
  - Certifications
  - Years of experience
  - Ratings and reviews
  - Gallery images

#### Profile Editor
- **Editable Fields:**
  - Personal information
  - Professional credentials
  - Specializations
  - Service areas
  - Pricing
  - Availability
  - About me section

#### Business Settings
- **Operational Controls:**
  - Working hours
  - Booking preferences
  - Cancellation policies
  - Payment settings
  - Notification preferences
  - Auto-reply messages

#### Performance Stats
- Total clients served
- Total sessions completed
- Average rating
- Total earnings
- Client retention rate
- Response time average

#### Certifications & Credentials
- Upload certificates
- Verification status
- Expiration tracking
- Professional memberships

#### Logout Button
- Sign out functionality
- Session cleanup
- Return to login screen

### Coach Dashboard Technical Features

#### Scrolling Behavior
- **Fixed Elements:**
  - Top header bar (sticky)
  - Bottom navigation bar (fixed)

- **Scrollable Content:**
  - Each module content area independently scrollable
  - Proper overflow handling
  - Bottom padding (pb-32) for navigation clearance
  - Smooth scroll performance

#### Responsive Layout
- Optimized for tablets and larger screens
- Max-width containers (7xl: 1280px)
- Flexible grid layouts
- Touch-optimized interactions

#### Real-time Updates
- Live session notifications
- Client activity updates
- Payment confirmations
- Schedule changes

---

## User Flows

### Athlete User Flows

#### 1. Discover & Book Package Flow
```
Home → Browse Package Feeds → View Package Details → Click Coach Card → 
View Coach Profile → Return to Package → Start Program → 
Price Breakdown → Select Payment Plan → Select Payment Method → 
Confirm Purchase → Navigate to Calendar
```

#### 2. Find & Book Individual Coach
```
Coaches Tab → Select Sport → Browse Coach Cards → View Coach Profile → 
View Available Packages → Select Package → Booking Flow → Confirmation
```

#### 3. Track Personal Performance
```
Profile → View Flow Index → Check Weekly Goals → Review Session History → 
View Achievements → Analyze Performance Trends
```

#### 4. Manage Wallet
```
Profile → Click "My Wallet" Button → View Balance → 
Deposit → Enter Amount → Select Method → Confirm → 
View Updated Balance → Download Statement
```

#### 5. Schedule Management
```
Calendar → Select View (Day/Week/Month) → View Sessions → 
Click Session → View Details → Contact Coach / Cancel Session
```

#### 6. AI Fitness Guidance
```
Home → Click AI Button → Chat Interface → Ask Question → 
Receive Recommendation → Apply to Training Plan
```

### Coach User Flows

#### 1. Client Management
```
Coach Dashboard → Clients Tab → Search/Filter Clients → 
Select Client → Expand Profile → Review Details → 
Add Notes → Schedule Session → Send Message
```

#### 2. Session Management
```
Coach Dashboard → Sessions Tab → View Schedule → 
Select Session → Review Client Info → Start Session → 
Complete → Add Performance Notes → Rate Session
```

#### 3. Package Creation
```
Coach Dashboard → Packages Tab → Create New Package → 
Enter Details → Set Pricing → Define Inclusions → 
Save Package → Publish to Profile
```

#### 4. Revenue Tracking
```
Coach Dashboard → Dashboard Tab → View Earnings → 
Analyze Revenue Chart → Review Payment Schedule → 
Export Financial Report
```

#### 5. AI-Assisted Coaching
```
Coach Dashboard → AI Assistant → Ask Question / Generate Plan → 
Review Suggestions → Customize → Save to Library → 
Share with Client
```

---

## Technical Specifications

### Technology Stack
- **Framework:** React with TypeScript
- **Styling:** Tailwind CSS v4.0
- **UI Components:** Shadcn/ui
- **Icons:** Lucide React
- **Build Tool:** Vite
- **State Management:** React Hooks (useState, useEffect)
- **Charts:** Recharts library
- **Image Handling:** ImageWithFallback component

### Performance Requirements
- **Initial Load:** < 2 seconds
- **Page Transitions:** < 300ms
- **Smooth Scrolling:** 60fps
- **Image Loading:** Progressive with fallbacks
- **Coach Dashboard Load:** < 1.5 seconds

### Responsive Design
- **Primary Target:** Mobile (375px - 428px)
- **Secondary Target:** Tablet/Desktop (768px - 1280px)
- **Max Width:** 448px (28rem) for athlete UI
- **Max Width:** 1280px (7xl) for coach dashboard
- **Safe Area:** iOS safe area inset support
- **Orientation:** Portrait optimized (athlete), Any (coach)

### Accessibility
- **Contrast Ratios:** WCAG AA compliant
- **Touch Targets:** Minimum 44x44px
- **Screen Reader:** Semantic HTML structure
- **Keyboard Navigation:** Full support
- **Focus Indicators:** Visible and clear

### Browser Support
- **iOS Safari:** 15+
- **Chrome Mobile:** Latest 2 versions
- **Chrome Desktop:** Latest 2 versions
- **Android WebView:** Latest
- **Safari Desktop:** Latest 2 versions

---

## Component Architecture

### Athlete Interface Components

#### Page Components

**Home.tsx**
- Props: `onNavigateToCoach`, `onStartPackage`
- State: `selectedLocation`, `showAIChat`
- Features: Performance feed, Coach spotlight, AI curated feed, Weekly highlights

**CoachesProfile.tsx**
- Props: `selectedSports`, `onOpenMap`, `onCoachClick`
- State: `selectedCoach`, `filters`, `displayedCoaches`
- Features: Sports grid, Coach cards, Filtering

**CoachDetailProfile.tsx**
- Props: `coachId`, `onBack`, `onBookPackage`
- State: `activeTab`, `selectedImage`
- Features: Profile header, Tabs, Packages, Gallery

**Calendar.tsx**
- Props: `onNavigateToCoach`
- State: `view`, `selectedDate`, `sessions`
- Features: Day/Week/Month views, Session management

**Profile.tsx**
- Props: None
- State: `selectedTab`, `showWallet`
- Features: Performance metrics, Flow index, Session history, Achievements

**Messages.tsx**
- State: `selectedChat`, `messages`
- Features: Chat list, Message interface

**Wallet.tsx**
- Props: `onBack`
- State: `view`, `depositAmount`, `selectedMethod`
- Features: Balance display, Deposit flow, Transaction history

**PackageBookingFlow.tsx**
- Props: `packageData`, `onBack`, `onComplete`
- State: `step`, `selectedPlan`, `selectedPaymentMethod`
- Features: Price breakdown, Payment options, Confirmation

### Coach Interface Components

#### Main Component

**CoachDashboard.tsx**
- Props: `onLogout`, `onClientSelect`
- State: `activeTab`
- Features: Header bar, Tab navigation, Module rendering
- Layout: Flexbox with fixed header/footer, scrollable content

#### Module Components

**CoachOverview.tsx**
- Features: Stats grid, Revenue chart, Earnings breakdown, Schedule
- State: Chart data, Recent activity

**CoachClients.tsx**
- Props: `onClientSelect`
- State: `expandedClient`, `searchQuery`, `filters`, `sortBy`
- Features: Client cards (15 profiles), Search, Filter, AI suggestions
- Data: Comprehensive CRM information per client

**CoachSessions.tsx**
- State: `selectedSession`, `filters`
- Features: Session timeline, Session cards, AI auto-suggest, Statistics

**CoachPackages.tsx**
- State: `packages`, `editingPackage`
- Features: Package list, Package builder, Templates, Analytics

**CoachAI.tsx**
- State: `chatMessages`, `generatedContent`
- Features: AI chat, Workout generator, Insights dashboard

**CoachLibrary.tsx**
- State: `selectedCategory`, `searchQuery`
- Features: Resource categories, Content upload, Search

**CoachProfile.tsx**
- Props: `onLogout`
- State: `editMode`, `profileData`
- Features: Profile editor, Settings, Stats, Logout

**CoachBottomNav.tsx**
- Props: `activeTab`, `onTabChange`
- Features: 7-tab navigation with icons and labels

### Shared Components

**CoachCard.tsx**
- Swipeable coach profile card
- Displays coach information
- Integrated review system

**FilterSheet.tsx**
- Bottom drawer filter interface
- Multi-select options
- Range sliders

**Auth.tsx**
- Login/Signup interface
- User type selection (Athlete/Coach)
- Form validation

---

## Data Models

### Athlete Data Models

#### Coach
```typescript
interface Coach {
  id: number;
  name: string;
  specialty: string;
  experience: number;
  certifications: string[];
  rating: number;
  reviewCount: number;
  clientCount: number;
  hourlyRate: number;
  location: string;
  distance: string;
  bio: string;
  image: string;
  reviews: Review[];
  gallery?: string[];
  packages?: CoachPackage[];
}
```

#### Package
```typescript
interface Package {
  id: string;
  title: string;
  duration: string;
  goal: string;
  image: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  coaches: PackageCoach[];
  description: string;
  highlights: string[];
  expectedResults: string[];
  price: number;
  discount?: number;
}
```

#### Session
```typescript
interface Session {
  id: number;
  coachName: string;
  coachImage: string;
  sport: string;
  date: string;
  time: string;
  duration: string;
  location: string;
  rating?: number;
  notes?: string;
  status: "upcoming" | "completed" | "cancelled";
}
```

#### UserProfile
```typescript
interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  profileImage: string;
  coverImage: string;
  bio: string;
  location: string;
  joinDate: string;
  flowIndex: number;
  totalSessions: number;
  trainingHours: number;
  currentStreak: number;
  achievements: Achievement[];
  weeklyGoal: number;
  weeklyProgress: number;
}
```

### Coach Data Models

#### Client
```typescript
interface Client {
  id: number;
  name: string;
  age: number;
  gender: string;
  location: string;
  phone: string;
  email: string;
  sport: string;
  emoji: string;
  flowIndex: number;
  trend: "improving" | "stable" | "declining";
  streak: number;
  lastSession: string;
  profileImage: string;
  
  // Goals & Progress
  goals: string[];
  progress: string;
  goalsProgress: number;
  milestones: string[];
  
  // Package & Financials
  activePackage: {
    name: string;
    sessionsTotal: number;
    sessionsRemaining: number;
    endDate: string;
    value: number;
  };
  paymentStatus: "paid" | "pending" | "overdue";
  outstandingBalance: number;
  lifetimeValue: number;
  
  // Recent Sessions
  recentSessions: {
    date: string;
    duration: string;
    notes: string;
    rating: number;
  }[];
  
  // Achievements
  achievements: string[];
  personalRecords: string[];
  
  // Notes
  coachNotes: {
    note: string;
    timestamp: string;
  }[];
  medicalNotes: {
    condition: string;
    severity: "low" | "medium" | "high";
  }[];
  
  // Preferences
  trainingPreferences: {
    preferredTimes: string[];
    location: string;
    intensity: string;
    motivation: string;
  };
  
  // Communications
  communicationsLog: {
    date: string;
    type: "message" | "call" | "email";
    summary: string;
  }[];
  
  status: "active" | "inactive" | "paused";
}
```

#### CoachSession
```typescript
interface CoachSession {
  id: number;
  clientName: string;
  clientImage: string;
  sport: string;
  date: string;
  time: string;
  duration: string;
  location: string;
  status: "upcoming" | "completed" | "cancelled";
  clientNotes?: string;
  coachNotes?: string;
  rating?: number;
  attendance: boolean;
}
```

#### CoachPackage
```typescript
interface CoachPackage {
  id: string;
  name: string;
  description: string;
  sessions: number;
  duration: number;
  price: number;
  discount?: number;
  activeClients: number;
  totalRevenue: number;
  inclusions: string[];
  terms: string;
}
```

#### CoachEarnings
```typescript
interface CoachEarnings {
  totalThisMonth: number;
  trend: number;
  chartData: {
    month: string;
    amount: number;
  }[];
  breakdown: {
    packages: number;
    sessions: number;
    consultations: number;
  };
  pendingPayments: {
    client: string;
    amount: number;
    dueDate: string;
  }[];
}
```

### Shared Data Models

#### Review
```typescript
interface Review {
  id: string;
  clientName: string;
  clientImage: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
}
```

#### Transaction
```typescript
interface Transaction {
  id: number;
  type: "deposit" | "session" | "refund" | "package";
  amount: number;
  date: string;
  status: "pending" | "completed" | "failed";
  method?: string;
  coach?: string;
  description: string;
}
```

#### PaymentPlan
```typescript
interface PaymentPlan {
  id: string;
  name: string;
  installments: number;
  upfront: number;
  monthly: number;
  total: number;
  savings?: number;
  fee?: number;
}
```

---

## Navigation Structure

### Athlete Bottom Navigation (5 tabs)
1. **Home** (Home icon) - Mission dashboard
2. **Calendar** (Calendar icon) - Schedule views
3. **Coaches** (Users icon) - Coach discovery
4. **Messages** (MessageCircle icon) - Chat
5. **Profile** (User icon) - Performance & settings

### Coach Bottom Navigation (7 modules)
1. **Dashboard** (LayoutDashboard icon) - Overview & earnings
2. **Clients** (Users icon) - Client CRM
3. **Sessions** (Calendar icon) - Session management
4. **Packages** (Package icon) - Package management
5. **AI Assistant** (Bot icon) - AI coaching tools
6. **Library** (Library icon) - Resources
7. **Profile** (User icon) - Coach profile & settings

### Active State Indicators
- Icon color: `#c6ff00` (lime green)
- Glow effect: `drop-shadow-[0_0_12px_rgba(198,255,0,0.6)]`
- Label text: Green for active, white/60 for inactive
- Inactive icons: 40% white opacity

### Headers

#### Athlete Header
- **Logo:** "VITΛ"
- **Position:** Centered
- **Styling:** Ultra-light (200 weight), letter-spacing 0.15em
- **Hidden on:** Map view, Full-screen modals

#### Coach Header
- **Logo:** "VITΛ" with "COACH" badge
- **Position:** Left-aligned
- **Right Side:** Notifications, Settings, Profile
- **Always Visible:** Sticky on scroll

### Safe Area Handling
- Bottom safe area inset for iOS
- Gradient background extension
- Proper padding calculations
- Touch target sizing

---

## Key Interactions

### Gestures
- **Horizontal Swipe:** Coach card carousel, Calendar week navigation
- **Vertical Scroll:** All list views, Feeds, CRM data
- **Tap:** Primary action, Card expansion
- **Long Press:** Context menus (future)
- **Pull to Refresh:** Lists and feeds
- **Pinch to Zoom:** Gallery images

### Animations
- **Duration:** 300ms standard, 200ms quick
- **Easing:** `cubic-bezier(0.16, 1, 0.3, 1)` for slides
- **Transitions:** All state changes animated
- **Hover Effects:** Scale (1.05), glow intensity, opacity
- **Expand/Collapse:** Height transitions with opacity
- **Loading States:** Skeleton screens, Shimmer effects

### Feedback
- **Visual:** Color change, scale, glow, check marks
- **Haptic:** Button presses (native)
- **Sound:** None (silent app)
- **Toast Notifications:** Success/Error confirmations

---

## Content Guidelines

### Tone of Voice
- **Professional** yet approachable
- **Motivational** without being pushy
- **Clear** and concise
- **Action-oriented**
- **Empowering** for both athletes and coaches

### Messaging Principles
- Focus on results and progress
- Emphasize expert coaching
- Highlight convenience and flexibility
- Promote community and support
- Data-driven insights
- Transparent pricing

### Placeholder Text
- Realistic coach names and bios
- Authentic-sounding reviews
- Achievable goals and results
- Dubai-specific locations
- Professional coach communications
- Detailed client progress notes

---

## Future Enhancements

### Athlete Interface
1. Video calls with coaches
2. Workout video library with playback
3. Nutrition meal plans with tracking
4. Progress photo comparisons
5. Social feed and community
6. Achievement sharing to social media
7. Referral program with rewards
8. Group training sessions
9. Live class streaming
10. Wearable device integration (Apple Watch, Fitbit)
11. Voice-controlled AI assistant
12. Augmented reality form checking

### Coach Interface
1. Automated scheduling AI
2. Revenue forecasting tools
3. Client retention analytics
4. Marketing campaign builder
5. Automated email/SMS campaigns
6. Advanced financial reporting
7. Tax document generation
8. Multi-coach team management
9. Facility management integration
10. Equipment inventory tracking
11. Certification renewal reminders
12. Professional development tracking

### Platform Features
1. Multi-city expansion (Abu Dhabi, Sharjah)
2. International currency support
3. Multiple language support (Arabic, Hindi)
4. Enhanced coach verification system
5. Background check integration
6. Insurance partnerships
7. Corporate wellness packages
8. Gym partnership programs
9. Retail merchandise integration
10. Event and competition hosting

---

## Success Metrics

### Athlete KPIs
- **User Acquisition:** New sign-ups per month
- **Booking Rate:** % of users who book within 7 days
- **Session Completion:** % of booked sessions attended
- **Wallet Adoption:** % of users with wallet balance
- **Package Purchase:** % choosing packages vs. individual sessions
- **Retention Rate:** 30-day and 90-day retention
- **Average Revenue Per User (ARPU)**
- **Net Promoter Score (NPS)**
- **Session Frequency:** Average sessions per user per month
- **Flow Index Improvement:** Average improvement over 90 days

### Coach KPIs
- **Coach Acquisition:** New coaches onboarded per month
- **Client Capacity:** Average clients per coach
- **Session Utilization:** % of available time slots filled
- **Revenue Per Coach:** Monthly average earnings
- **Client Retention:** % of clients renewing packages
- **Response Time:** Average time to respond to inquiries
- **Package Conversion:** % of profile views to package purchases
- **Coach Rating:** Average rating across all coaches
- **Platform Engagement:** Daily active coach users
- **CRM Utilization:** % of coaches actively using client notes

### Platform KPIs
- **Gross Merchandise Value (GMV):** Total transaction volume
- **Take Rate:** Platform commission percentage
- **Coach-Client Match Rate:** Successful bookings per search
- **Platform Revenue:** Monthly recurring revenue
- **Churn Rate:** User and coach attrition
- **Customer Acquisition Cost (CAC)**
- **Lifetime Value (LTV)**
- **LTV:CAC Ratio**

### Analytics Events

#### Athlete Events
- Home dashboard viewed
- Performance feed interaction
- Coach spotlight clicked
- AI assistant opened
- AI recommendation applied
- Package viewed
- Coach profile viewed
- Filter applied
- Map view opened
- Booking initiated
- Booking completed
- Payment successful
- Session attended
- Session cancelled
- Review submitted
- Wallet deposit
- Achievement unlocked
- Flow index improved

#### Coach Events
- Dashboard viewed
- Client profile expanded
- Client note added
- Session created
- Session completed
- Session notes added
- Package created
- Package sold
- AI assistant query
- Library resource accessed
- Profile updated
- Earnings report viewed
- Client message sent
- Schedule optimization used

---

## Compliance & Legal

### Data Protection
- GDPR compliant data handling
- UAE data residency requirements
- Secure payment processing (PCI DSS)
- User consent management
- Data encryption in transit and at rest
- Regular security audits
- Breach notification procedures

### Terms of Service
- Cancellation policies clearly stated
- Refund terms (20% fee or token conversion)
- Coach-client agreement templates
- Liability waivers
- Insurance requirements
- Platform usage terms
- Intellectual property rights

### Privacy
- No PII collection beyond necessary
- Encrypted data transmission
- Secure storage with backups
- User data export capability
- Right to deletion (GDPR)
- Cookie policy
- Third-party data sharing disclosure

### Coach Compliance
- Professional certification verification
- Background check requirements
- Insurance validation
- First aid certification
- Code of conduct agreement
- Client confidentiality
- Dispute resolution process

---

## Support & Documentation

### User Support
- In-app help center
- FAQ section with search
- Coach contact via messages
- Email support: support@vita.ae
- Response time: < 12 hours
- Video tutorials
- Onboarding guide

### Coach Support
- Coach onboarding guide
- Best practices documentation
- Payment processing help
- Technical support
- Community forum
- Monthly webinars
- Success manager (for top coaches)
- Knowledge base

### Technical Documentation
- API documentation (future)
- Integration guides
- Troubleshooting guide
- System status page
- Release notes
- Migration guides

---

## Deployment & Infrastructure

### Environments
- **Development:** Local development servers
- **Staging:** Pre-production testing
- **Production:** Live application

### Hosting (Recommended)
- **Frontend:** Vercel / Netlify
- **Backend:** (Future) AWS / Google Cloud
- **Database:** (Future) PostgreSQL / MongoDB
- **File Storage:** AWS S3 / Cloudflare R2
- **CDN:** Cloudflare

### Monitoring
- Error tracking (Sentry)
- Analytics (Google Analytics / Mixpanel)
- Performance monitoring (Web Vitals)
- Uptime monitoring
- User session recording (Hotjar)

### Security
- HTTPS/TLS encryption
- Regular security scans
- Dependency updates
- Rate limiting
- DDoS protection
- Authentication (OAuth 2.0)
- Role-based access control

---

## Design Assets

### Required Assets
- Logo variations (light/dark, various sizes)
- App icon (iOS/Android)
- Splash screen
- Coach profile placeholder images
- Sport emoji/icons
- Achievement badge graphics
- Empty state illustrations
- Loading animations

### Image Specifications
- **Profile Photos:** 400x400px, JPG/WebP
- **Cover Images:** 1200x400px, JPG/WebP
- **Gallery Images:** 800x600px, JPG/WebP
- **Sport Icons:** SVG vector
- **Achievement Badges:** PNG with transparency

---

## Appendix

### Glossary
- **Flow Index:** Proprietary metric (0-100) measuring client fitness progress and engagement
- **VITA Balance:** In-app wallet balance in AED
- **Tokens:** Zero-fee cancellation credits
- **Package:** Pre-paid bundle of training sessions
- **CRM:** Customer Relationship Management
- **Session:** Individual training appointment
- **Coach Dashboard:** Separate interface for coach business management

### Version History
- **v1.0** (October 27, 2025): Initial athlete interface
- **v2.0** (November 4, 2025): 
  - Added Coach Dashboard with 7 modules
  - Added 15 detailed client profiles with CRM
  - Redesigned Home page to mission dashboard
  - Enhanced Profile with Flow Index and session history
  - Improved scrolling behavior across all coach modules
  - Reverted to dark mode design system

### Contributors
- Product Design: VITA Design Team
- Development: VITA Engineering Team
- Content: VITA Content Team

---

**End of Product Requirements Document**

---

*This PRD represents the current state of VITA as of November 4, 2025. It includes both the athlete-facing interface and the comprehensive coach business management dashboard. For technical implementation details, refer to the codebase documentation and component files.*

**Key Files:**
- Athlete Interface: `/App.tsx`, `/components/Home.tsx`, `/components/Profile.tsx`, `/components/Calendar.tsx`, `/components/CoachesProfile.tsx`, `/components/Messages.tsx`, `/components/Wallet.tsx`
- Coach Interface: `/components/CoachDashboard.tsx`, `/components/CoachOverview.tsx`, `/components/CoachClients.tsx`, `/components/CoachSessions.tsx`, `/components/CoachPackages.tsx`, `/components/CoachAI.tsx`, `/components/CoachLibrary.tsx`, `/components/CoachProfile.tsx`
- Navigation: `/components/CoachBottomNav.tsx`
- Authentication: `/components/Auth.tsx`

**Total Components:** 30+ React components
**Total Lines of Code:** 15,000+
**Supported Sports:** 14
**Coach Profiles:** 31
**Client Profiles:** 15
**UI Components:** 40+ Shadcn components
