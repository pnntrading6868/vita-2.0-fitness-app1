import { Sparkles, TrendingUp, MessageCircle, Target, Users, Lightbulb } from "lucide-react";

export function CoachAI() {
  const suggestions = [
    {
      category: "Client Retention",
      icon: Users,
      color: "#c6ff00",
      insights: [
        "Khoa Le hasn't trained in 5 days - send encouragement or offer discount",
        "3 clients approaching 30-day milestone - prepare celebration messages",
        "Average retention: 86% (Top 10%: 92%) - implement weekly check-ins",
      ],
    },
    {
      category: "Business Growth",
      icon: TrendingUp,
      color: "#00d9ff",
      insights: [
        "Boxing package generates 60% revenue - create advanced upsell version",
        "Best posting time for content: Friday 6PM (18% higher engagement)",
        "Unused time slots on Fridays - auto-suggest 3 clients to fill them",
      ],
    },
    {
      category: "Content Strategy",
      icon: Lightbulb,
      color: "#ff00d9",
      insights: [
        "Post 30-sec recovery tip video this week for engagement boost",
        "Share client success story (Mai Pham's progress) for social proof",
        "Create warmup tutorial - high demand from your client base",
      ],
    },
    {
      category: "Client Communication",
      icon: MessageCircle,
      color: "#ffa500",
      insights: [
        "Draft congratulations for Huy's 30-day streak (tomorrow)",
        "Send weekly summary to 5 clients who prefer written feedback",
        "3 clients haven't responded to last message - gentle follow-up",
      ],
    },
  ];

  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-[#c6ff00]" />
            <div>
              <h1 className="text-white text-2xl" data-testid="text-page-title">AI Coach Assistant</h1>
              <p className="text-white/60 text-sm" data-testid="text-page-subtitle">Your intelligent business partner</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* Welcome Card */}
        <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-6 border border-[#c6ff00]/20" data-testid="card-ai-welcome">
          <h2 className="text-white text-xl mb-2">Personalized Coaching Intelligence</h2>
          <p className="text-white/60 text-sm mb-4">
            AI-powered insights to help you retain clients, grow your business, and optimize your
            coaching impact. All recommendations are based on your data and industry benchmarks.
          </p>
          <div className="flex gap-3">
            <button 
              className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors"
              data-testid="button-generate-weekly-report"
            >
              Generate Weekly Report
            </button>
            <button 
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-lg text-sm transition-colors"
              data-testid="button-auto-draft-messages"
            >
              Auto-Draft Messages
            </button>
          </div>
        </div>

        {/* Insights Categories */}
        {suggestions.map((category, categoryIdx) => {
          const Icon = category.icon;
          return (
            <div
              key={category.category}
              className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10"
              data-testid={`card-category-${category.category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex items-center gap-3 mb-5">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: `${category.color}20` }}
                >
                  <Icon className="w-5 h-5" style={{ color: category.color }} />
                </div>
                <h2 className="text-white text-xl" data-testid={`text-category-title-${categoryIdx}`}>{category.category}</h2>
              </div>

              <div className="space-y-3">
                {category.insights.map((insight, idx) => (
                  <div
                    key={idx}
                    className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 hover:border-white/10 transition-all"
                    data-testid={`card-insight-${categoryIdx}-${idx}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-white/80 text-sm flex-1" data-testid={`text-insight-${categoryIdx}-${idx}`}>{insight}</p>
                      <button 
                        className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg text-xs transition-colors whitespace-nowrap"
                        data-testid={`button-apply-insight-${categoryIdx}-${idx}`}
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Performance Analysis */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-performance-analysis">
          <h2 className="text-white text-xl mb-5">Your Performance vs Benchmarks</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5" data-testid="card-metric-retention">
              <p className="text-white/60 text-sm mb-2">Client Retention</p>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-white text-2xl" data-testid="text-retention-value">86%</span>
                <span className="text-white/60 text-sm mb-1">(Top 10%: 92%)</span>
              </div>
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-[#c6ff00] rounded-full" style={{ width: "86%" }} data-testid="progress-retention" />
              </div>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5" data-testid="card-metric-response-time">
              <p className="text-white/60 text-sm mb-2">Response Time</p>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-white text-2xl" data-testid="text-response-time-value">12min</span>
                <span className="text-white/60 text-sm mb-1">(Top 10%: &lt;15min)</span>
              </div>
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-[#c6ff00] rounded-full" style={{ width: "95%" }} data-testid="progress-response-time" />
              </div>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5" data-testid="card-metric-session-quality">
              <p className="text-white/60 text-sm mb-2">Session Quality</p>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-white text-2xl" data-testid="text-session-quality-value">4.9</span>
                <span className="text-white/60 text-sm mb-1">(Top 10%: 4.8+)</span>
              </div>
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-[#c6ff00] rounded-full" style={{ width: "98%" }} data-testid="progress-session-quality" />
              </div>
            </div>
          </div>
        </div>

        {/* Future Features Teaser */}
        <div className="bg-gradient-to-br from-purple-500/10 to-transparent rounded-[24px] p-6 border border-purple-500/20" data-testid="card-future-features">
          <div className="flex items-start gap-4">
            <Sparkles className="w-6 h-6 text-purple-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-white mb-2">Coming Soon: Advanced AI Features</h3>
              <ul className="space-y-2 text-white/60 text-sm">
                <li>• Auto-generate personalized workout plans</li>
                <li>• Real-time form correction with computer vision</li>
                <li>• Predictive client churn prevention</li>
                <li>• Voice-activated session notes</li>
                <li>• Automated progress report generation</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
