import { useState } from "react";
import {
  Plus,
  Edit,
  Eye,
  EyeOff,
  TrendingUp,
  DollarSign,
  Users,
  Star,
  Package as PackageIcon,
} from "lucide-react";

export function CoachPackages() {
  const [packages, setPackages] = useState([
    {
      id: 1,
      title: "Boxing Fundamentals",
      description: "Master the basics of boxing with personalized coaching",
      price: 199,
      duration: "4 weeks",
      sessions: 10,
      category: "Boxing",
      emoji: "🥊",
      isPublic: true,
      purchases: 28,
      rating: 4.9,
      retention: 93,
      addOns: ["Nutrition plan", "Video check-ins"],
    },
    {
      id: 2,
      title: "Advanced Sparring Program",
      description: "Competitive training for experienced boxers",
      price: 349,
      duration: "8 weeks",
      sessions: 20,
      category: "Boxing",
      emoji: "🥊",
      isPublic: true,
      purchases: 15,
      rating: 5.0,
      retention: 96,
      addOns: ["Competition prep", "Diet consultation"],
    },
    {
      id: 3,
      title: "Yoga & Mindfulness",
      description: "Find balance through guided yoga practice",
      price: 149,
      duration: "4 weeks",
      sessions: 8,
      category: "Yoga",
      emoji: "🧘",
      isPublic: true,
      purchases: 42,
      rating: 4.8,
      retention: 88,
      addOns: ["Meditation guide"],
    },
    {
      id: 4,
      title: "Elite Strength Training",
      description: "Build muscle and power with structured programming",
      price: 299,
      duration: "6 weeks",
      sessions: 15,
      category: "Strength",
      emoji: "💪",
      isPublic: false,
      purchases: 0,
      rating: 0,
      retention: 0,
      addOns: ["Meal planning", "Progress tracking"],
    },
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);

  const toggleVisibility = (id: number) => {
    setPackages(
      packages.map((pkg) =>
        pkg.id === id ? { ...pkg, isPublic: !pkg.isPublic } : pkg
      )
    );
  };

  const totalRevenue = packages.reduce((acc, pkg) => acc + pkg.price * pkg.purchases, 0);
  const totalPurchases = packages.reduce((acc, pkg) => acc + pkg.purchases, 0);
  const avgRating = packages.filter(p => p.rating > 0).reduce((acc, pkg) => acc + pkg.rating, 0) / packages.filter(p => p.rating > 0).length;

  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-white text-2xl" data-testid="text-page-title">Packages & Services</h1>
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors"
              data-testid="button-create-package"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Package</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10" data-testid="card-stat-total-packages">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <PackageIcon className="w-4 h-4" />
              Total Packages
            </div>
            <p className="text-white text-2xl" data-testid="text-total-packages">{packages.length}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10" data-testid="card-stat-revenue">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <DollarSign className="w-4 h-4" />
              Revenue
            </div>
            <p className="text-[#c6ff00] text-2xl" data-testid="text-total-revenue">${totalRevenue.toLocaleString()}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10" data-testid="card-stat-purchases">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Users className="w-4 h-4" />
              Purchases
            </div>
            <p className="text-white text-2xl" data-testid="text-total-purchases">{totalPurchases}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10" data-testid="card-stat-avg-rating">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Star className="w-4 h-4" />
              Avg Rating
            </div>
            <p className="text-white text-2xl" data-testid="text-avg-rating">{avgRating.toFixed(1)}</p>
          </div>
        </div>

        {/* AI Insight */}
        <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-5 border border-[#c6ff00]/20" data-testid="card-ai-insight">
          <div className="flex items-start gap-3">
            <TrendingUp className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white/80 text-sm mb-1">AI Business Insight</p>
              <p className="text-white/60 text-sm" data-testid="text-ai-insight">
                Your "Boxing Fundamentals" package generates 60% of your income. Consider creating an
                advanced version to upsell existing clients and increase retention.
              </p>
            </div>
          </div>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-[#0f0f0f] rounded-[20px] p-5 border border-white/10 hover:border-white/20 transition-all"
              data-testid={`card-package-${pkg.id}`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#c6ff00]/20 to-[#c6ff00]/5 rounded-xl flex items-center justify-center text-2xl">
                    {pkg.emoji}
                  </div>
                  <div>
                    <h3 className="text-white mb-1" data-testid={`text-package-title-${pkg.id}`}>{pkg.title}</h3>
                    <span className="px-2 py-0.5 bg-white/5 text-white/60 rounded-full text-xs" data-testid={`text-package-category-${pkg.id}`}>
                      {pkg.category}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => toggleVisibility(pkg.id)}
                  className="p-2 hover:bg-white/5 rounded-lg transition-colors"
                  data-testid={`button-toggle-visibility-${pkg.id}`}
                >
                  {pkg.isPublic ? (
                    <Eye className="w-4 h-4 text-[#c6ff00]" />
                  ) : (
                    <EyeOff className="w-4 h-4 text-white/40" />
                  )}
                </button>
              </div>

              {/* Description */}
              <p className="text-white/60 text-sm mb-4" data-testid={`text-package-description-${pkg.id}`}>{pkg.description}</p>

              {/* Package Details */}
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-[#1a1a1a] rounded-lg p-3" data-testid={`card-package-price-${pkg.id}`}>
                  <p className="text-white/60 text-xs mb-1">Price</p>
                  <p className="text-white" data-testid={`text-package-price-${pkg.id}`}>${pkg.price}</p>
                </div>
                <div className="bg-[#1a1a1a] rounded-lg p-3" data-testid={`card-package-duration-${pkg.id}`}>
                  <p className="text-white/60 text-xs mb-1">Duration</p>
                  <p className="text-white" data-testid={`text-package-duration-${pkg.id}`}>{pkg.duration}</p>
                </div>
                <div className="bg-[#1a1a1a] rounded-lg p-3" data-testid={`card-package-sessions-${pkg.id}`}>
                  <p className="text-white/60 text-xs mb-1">Sessions</p>
                  <p className="text-white" data-testid={`text-package-sessions-${pkg.id}`}>{pkg.sessions}</p>
                </div>
              </div>

              {/* Add-ons */}
              {pkg.addOns.length > 0 && (
                <div className="mb-4">
                  <p className="text-white/60 text-xs mb-2">Includes:</p>
                  <div className="flex flex-wrap gap-2">
                    {pkg.addOns.map((addon, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-[#c6ff00]/10 text-[#c6ff00] rounded-lg text-xs"
                        data-testid={`badge-addon-${pkg.id}-${idx}`}
                      >
                        {addon}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Analytics */}
              {pkg.isPublic && pkg.purchases > 0 && (
                <div className="pt-4 border-t border-white/5">
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div>
                      <p className="text-white/60 text-xs mb-1">Purchases</p>
                      <p className="text-white" data-testid={`text-package-purchases-${pkg.id}`}>{pkg.purchases}</p>
                    </div>
                    <div>
                      <p className="text-white/60 text-xs mb-1">Rating</p>
                      <p className="text-white flex items-center gap-1" data-testid={`text-package-rating-${pkg.id}`}>
                        {pkg.rating}
                        <Star className="w-3 h-3 text-[#c6ff00] fill-[#c6ff00]" />
                      </p>
                    </div>
                    <div>
                      <p className="text-white/60 text-xs mb-1">Retention</p>
                      <p className="text-white" data-testid={`text-package-retention-${pkg.id}`}>{pkg.retention}%</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Status Badge */}
              {!pkg.isPublic && (
                <div className="pt-4 border-t border-white/5">
                  <span className="px-3 py-1 bg-white/5 text-white/60 rounded-full text-xs" data-testid={`badge-package-hidden-${pkg.id}`}>
                    Hidden - Not visible to clients
                  </span>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 mt-4">
                <button 
                  className="flex-1 px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                  data-testid={`button-edit-package-${pkg.id}`}
                >
                  <Edit className="w-4 h-4" />
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* VITA Marketplace Teaser */}
        <div className="bg-gradient-to-br from-purple-500/10 to-transparent rounded-[24px] p-6 border border-purple-500/20" data-testid="card-marketplace-teaser">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-white mb-2">Coming Soon: VITA Marketplace</h3>
              <p className="text-white/60 text-sm mb-4">
                Monetize your digital programs, sell workout plans, and reach thousands of athletes
                beyond your local area. Build your coaching empire.
              </p>
              <button 
                className="px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-lg text-sm transition-colors"
                data-testid="button-join-marketplace-waitlist"
              >
                Join Waitlist
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Create Package Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" data-testid="modal-create-package">
          <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10 max-w-md w-full">
            <h3 className="text-white text-xl mb-4">Create New Package</h3>
            <p className="text-white/60 text-sm mb-4">
              Package builder with full customization coming soon
            </p>
            <button
              onClick={() => setShowCreateModal(false)}
              className="w-full px-4 py-3 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors"
              data-testid="button-close-modal"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
