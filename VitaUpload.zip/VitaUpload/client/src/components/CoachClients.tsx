import { useState } from "react";
import {
  Search,
  Filter,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertCircle,
  Flame,
  Target,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Calendar,
  BarChart3,
  Phone,
  Mail,
  MapPin,
  Award,
  Clock,
  DollarSign,
  Activity,
  Heart,
  Star,
  CheckCircle,
  X,
  User,
} from "lucide-react";
import { Input } from "./ui/input";
import { Progress } from "./ui/progress";

interface CoachClientsProps {
  onClientSelect: (clientId: string) => void;
}

const clients = [
  {
    id: 1,
    name: "Huy Nguyen",
    age: 28,
    gender: "Male",
    location: "District 1, HCMC",
    phone: "+84 90 123 4567",
    email: "huy.nguyen@email.com",
    sport: "Boxing",
    emoji: "🥊",
    flowIndex: 72,
    trend: "improving",
    streak: 21,
    lastSession: "Today",
    totalSessions: 124,
    memberSince: "Jan 2024",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Master defensive movement", progress: 70, targetDate: "Dec 2025" },
      { title: "Improve 3-round stamina", progress: 45, targetDate: "Nov 2025" },
      { title: "Compete in amateur tournament", progress: 60, targetDate: "Jan 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 5 - 9:00 AM",
    package: "Boxing Fundamentals",
    packageExpiry: "Dec 15, 2025",
    sessionsRemaining: 8,
    monthlyRevenue: "$480",
    totalRevenue: "$5,280",
    notes: "Footwork improving consistently. Ready for advanced sparring. Watch right shoulder - occasional tension.",
    medicalNotes: "Mild left knee pain (old injury). Cleared by doctor for full training.",
    preferences: "Prefers morning sessions, likes high-intensity workouts, responds well to competitive drills",
    recentSessions: [
      { date: "Nov 3", type: "Boxing Drills", duration: "60 min", rating: 9, notes: "Excellent footwork" },
      { date: "Nov 1", type: "Sparring", duration: "90 min", rating: 8, notes: "Good defense" },
      { date: "Oct 30", type: "Conditioning", duration: "45 min", rating: 9, notes: "High energy" },
      { date: "Oct 28", type: "Technical", duration: "60 min", rating: 8, notes: "Combo work improved" },
    ],
    achievements: [
      "🏆 100 Session Milestone",
      "🔥 20-Day Streak",
      "⚡ Flow Index +15 (Last 3 months)",
    ],
    communications: [
      { date: "Nov 2", type: "message", content: "Great session today! See you Friday" },
      { date: "Oct 28", type: "note", content: "Discussed tournament preparation plan" },
    ],
  },
  {
    id: 2,
    name: "Linh Tran",
    age: 32,
    gender: "Female",
    location: "Tay Ho, Hanoi",
    phone: "+84 91 234 5678",
    email: "linh.tran@email.com",
    sport: "Yoga",
    emoji: "🧘",
    flowIndex: 58,
    trend: "improving",
    streak: 8,
    lastSession: "1 day ago",
    totalSessions: 86,
    memberSince: "Mar 2024",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "5-min headstand hold", progress: 60, targetDate: "Dec 2025" },
      { title: "Daily meditation practice", progress: 85, targetDate: "Nov 2025" },
      { title: "Full splits", progress: 75, targetDate: "Jan 2026" },
    ],
    activityLevel: "Medium",
    nextSession: "Nov 4 - 6:00 PM",
    package: "Yoga & Mindfulness",
    packageExpiry: "Jan 10, 2026",
    sessionsRemaining: 12,
    monthlyRevenue: "$320",
    totalRevenue: "$2,560",
    notes: "Headstand hold improved from 30s to 90s. Excellent progress. Very dedicated to practice.",
    medicalNotes: "History of lower back pain - improving with core strengthening. No restrictions.",
    preferences: "Evening sessions preferred, loves restorative yoga, interested in meditation workshops",
    recentSessions: [
      { date: "Nov 2", type: "Vinyasa Flow", duration: "60 min", rating: 9, notes: "Beautiful practice" },
      { date: "Oct 31", type: "Yin Yoga", duration: "45 min", rating: 10, notes: "Deep relaxation" },
      { date: "Oct 29", type: "Power Yoga", duration: "60 min", rating: 8, notes: "Challenging but great" },
      { date: "Oct 27", type: "Meditation", duration: "30 min", rating: 9, notes: "Peaceful session" },
    ],
    achievements: [
      "🧘 Headstand Progress +200%",
      "🎯 Flexibility Gains Exceptional",
      "⭐ Perfect Attendance (3 months)",
    ],
    communications: [
      { date: "Nov 1", type: "message", content: "Thank you for the meditation tips!" },
      { date: "Oct 25", type: "note", content: "Interested in advanced workshop next month" },
    ],
  },
  {
    id: 3,
    name: "Khoa Le",
    age: 35,
    gender: "Male",
    location: "Son Tra, Da Nang",
    phone: "+84 92 345 6789",
    email: "khoa.le@email.com",
    sport: "Strength",
    emoji: "💪",
    flowIndex: 45,
    trend: "at-risk",
    streak: 3,
    lastSession: "5 days ago",
    totalSessions: 42,
    memberSince: "Aug 2024",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    status: "at-risk",
    alert: "No training in 5 days - shoulder rehab",
    goals: [
      { title: "Full shoulder ROM recovery", progress: 65, targetDate: "Jan 2026" },
      { title: "Pain-free overhead press", progress: 40, targetDate: "Dec 2025" },
      { title: "Return to 3x/week training", progress: 50, targetDate: "Dec 2025" },
    ],
    activityLevel: "Low",
    nextSession: "Nov 7 - 10:00 AM",
    package: "Rehab & Recovery",
    packageExpiry: "Feb 20, 2026",
    sessionsRemaining: 15,
    monthlyRevenue: "$180",
    totalRevenue: "$720",
    notes: "Shoulder rehab progressing slowly. Needs encouragement and patience. Very motivated but frustrated with slow progress.",
    medicalNotes: "Rotator cuff injury (Sept 2024). PT clearance for light training. No heavy overhead movements until cleared.",
    preferences: "Flexible schedule, prefers detailed explanations, needs positive reinforcement",
    recentSessions: [
      { date: "Oct 29", type: "Shoulder Rehab", duration: "45 min", rating: 7, notes: "ROM improving slowly" },
      { date: "Oct 25", type: "Mobility Work", duration: "30 min", rating: 8, notes: "Good effort" },
      { date: "Oct 22", type: "Light Strength", duration: "45 min", rating: 6, notes: "Some discomfort" },
    ],
    achievements: [
      "💪 ROM Improved 15%",
      "🎯 Consistent PT Exercises",
    ],
    communications: [
      { date: "Oct 30", type: "call", content: "Check-in about progress - feeling discouraged" },
      { date: "Oct 20", type: "note", content: "Remind about patience in recovery process" },
    ],
  },
  {
    id: 4,
    name: "Mai Pham",
    age: 26,
    gender: "Female",
    location: "District 3, HCMC",
    phone: "+84 93 456 7890",
    email: "mai.pham@email.com",
    sport: "Boxing",
    emoji: "🥊",
    flowIndex: 68,
    trend: "improving",
    streak: 15,
    lastSession: "Today",
    totalSessions: 98,
    memberSince: "Feb 2024",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Win regional championship", progress: 90, targetDate: "Dec 2025" },
      { title: "Increase punch power 15%", progress: 85, targetDate: "Nov 2025" },
      { title: "Master southpaw defense", progress: 80, targetDate: "Dec 2025" },
    ],
    activityLevel: "High",
    nextSession: "Nov 4 - 2:00 PM",
    package: "Competition Prep Elite",
    packageExpiry: "Mar 1, 2026",
    sessionsRemaining: 24,
    monthlyRevenue: "$640",
    totalRevenue: "$6,080",
    notes: "Competition ready. Speed and stamina at peak. Maintain intensity. Mental game very strong - champion mindset.",
    medicalNotes: "No current injuries. Excellent physical condition. Regular sports massage recommended.",
    preferences: "Afternoon sessions, loves sparring, highly competitive, responds to challenges",
    recentSessions: [
      { date: "Nov 3", type: "Sparring - Competition Prep", duration: "90 min", rating: 10, notes: "Dominated all rounds" },
      { date: "Nov 1", type: "Speed & Agility", duration: "60 min", rating: 9, notes: "Fastest footwork yet" },
      { date: "Oct 30", type: "Power Development", duration: "60 min", rating: 8, notes: "Explosive punches" },
      { date: "Oct 28", type: "Technical Drills", duration: "75 min", rating: 9, notes: "Combinations flowing" },
    ],
    achievements: [
      "🏆 Competition Ready Status",
      "⚡ Speed Improved +9%",
      "💪 Stamina Increased +11%",
      "🥊 15-Day Streak",
    ],
    communications: [
      { date: "Nov 2", type: "message", content: "Coach, I'm ready for this fight! 🔥" },
      { date: "Oct 28", type: "note", content: "Competition mindset excellent - maintain confidence" },
    ],
  },
  {
    id: 5,
    name: "Duc Phan",
    age: 34,
    gender: "Male",
    location: "Ninh Kieu, Can Tho",
    phone: "+84 94 567 8901",
    email: "duc.phan@email.com",
    sport: "Running",
    emoji: "🏃",
    flowIndex: 62,
    trend: "improving",
    streak: 10,
    lastSession: "1 day ago",
    totalSessions: 75,
    memberSince: "May 2024",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Complete first marathon", progress: 85, targetDate: "Dec 2025" },
      { title: "Finish under 4 hours", progress: 75, targetDate: "Dec 2025" },
      { title: "Stay injury-free", progress: 100, targetDate: "Ongoing" },
    ],
    activityLevel: "High",
    nextSession: "Nov 5 - 7:00 AM",
    package: "Marathon Training Program",
    packageExpiry: "Jan 30, 2026",
    sessionsRemaining: 16,
    monthlyRevenue: "$420",
    totalRevenue: "$2,940",
    notes: "32km long run completed successfully. Ready for taper phase. Nutrition strategy working perfectly. Very disciplined athlete.",
    medicalNotes: "Slight IT band tightness - managed with stretching. No major concerns. Excellent recovery habits.",
    preferences: "Early morning sessions, enjoys long runs, data-driven, likes detailed training plans",
    recentSessions: [
      { date: "Nov 2", type: "Long Run 32km", duration: "180 min", rating: 9, notes: "Target pace maintained" },
      { date: "Oct 31", type: "Tempo Run", duration: "60 min", rating: 8, notes: "HR zones perfect" },
      { date: "Oct 29", type: "Strength Training", duration: "45 min", rating: 7, notes: "Leg strength work" },
      { date: "Oct 27", type: "Interval Training", duration: "60 min", rating: 8, notes: "Speed improving" },
    ],
    achievements: [
      "🏃 32km Long Run Completed",
      "📈 Endurance +14%",
      "🎯 Perfect Training Plan Adherence",
      "💪 Injury-Free Status",
    ],
    communications: [
      { date: "Nov 2", type: "message", content: "Incredible 32km today! I can actually do this 🏃‍♂️" },
      { date: "Oct 28", type: "note", content: "Begin taper phase next week - reduce volume" },
    ],
  },
  {
    id: 6,
    name: "Anh Nguyen",
    age: 29,
    gender: "Female",
    location: "Nha Trang",
    phone: "+84 95 678 9012",
    email: "anh.nguyen@email.com",
    sport: "Swimming",
    emoji: "🏊",
    flowIndex: 71,
    trend: "improving",
    streak: 14,
    lastSession: "Today",
    totalSessions: 110,
    memberSince: "Jan 2024",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Complete Olympic triathlon", progress: 88, targetDate: "Jan 2026" },
      { title: "1500m swim under 22min", progress: 92, targetDate: "Dec 2025" },
      { title: "Improve bike power output", progress: 70, targetDate: "Feb 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 4 - 5:00 PM",
    package: "Triathlon Elite Package",
    packageExpiry: "Mar 15, 2026",
    sessionsRemaining: 20,
    monthlyRevenue: "$560",
    totalRevenue: "$6,160",
    notes: "Open water technique excellent. Triathlon race ready! Bike-to-run transitions smooth. Elite multisport athlete.",
    medicalNotes: "No injuries. Outstanding cardiovascular fitness. Monitor nutrition during long sessions.",
    preferences: "Flexible schedule, loves variety, goal-oriented, responds well to data/metrics",
    recentSessions: [
      { date: "Nov 3", type: "Open Water Practice", duration: "90 min", rating: 10, notes: "Perfect technique" },
      { date: "Nov 1", type: "Speed Intervals", duration: "60 min", rating: 9, notes: "Best times yet" },
      { date: "Oct 30", type: "Bike Endurance", duration: "120 min", rating: 8, notes: "60km completed" },
      { date: "Oct 28", type: "Brick Workout", duration: "75 min", rating: 8, notes: "Smooth transitions" },
    ],
    achievements: [
      "🏊 1500m PB: 21:48",
      "🚴 60km Bike Strong",
      "📈 Technique Score 90/100",
      "🔥 14-Day Streak",
    ],
    communications: [
      { date: "Nov 3", type: "message", content: "Open water felt so good today! 🌊" },
      { date: "Oct 29", type: "note", content: "Ready for triathlon distance - register for race" },
    ],
  },
  {
    id: 7,
    name: "Tuan Vo",
    age: 31,
    gender: "Male",
    location: "District 7, HCMC",
    phone: "+84 96 789 0123",
    email: "tuan.vo@email.com",
    sport: "Cycling",
    emoji: "🚴",
    flowIndex: 55,
    trend: "stable",
    streak: 6,
    lastSession: "2 days ago",
    totalSessions: 48,
    memberSince: "Jun 2024",
    image: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Century ride (100km)", progress: 65, targetDate: "Feb 2026" },
      { title: "Improve climbing ability", progress: 50, targetDate: "Jan 2026" },
      { title: "Join group rides regularly", progress: 40, targetDate: "Dec 2025" },
    ],
    activityLevel: "Medium",
    nextSession: "Nov 6 - 8:00 AM",
    package: "Cycling Development",
    packageExpiry: "Feb 10, 2026",
    sessionsRemaining: 14,
    monthlyRevenue: "$280",
    totalRevenue: "$1,680",
    notes: "Building endurance steadily. Need to work on hill climbing technique. Good basic fitness foundation.",
    medicalNotes: "Minor saddle discomfort - bike fit adjustment recommended. Otherwise healthy.",
    preferences: "Weekend morning sessions, prefers outdoor rides, social rider, needs encouragement on hills",
    recentSessions: [
      { date: "Nov 1", type: "Endurance Ride", duration: "90 min", rating: 7, notes: "50km completed" },
      { date: "Oct 29", type: "Hill Repeats", duration: "60 min", rating: 6, notes: "Challenging but improving" },
      { date: "Oct 26", type: "Recovery Ride", duration: "45 min", rating: 8, notes: "Easy pace" },
      { date: "Oct 24", type: "Interval Training", duration: "60 min", rating: 7, notes: "Power building" },
    ],
    achievements: [
      "🚴 Longest Ride: 50km",
      "⛰️ First Hill Climb Completed",
      "📊 Consistent Weekly Training",
    ],
    communications: [
      { date: "Oct 30", type: "message", content: "Hills are tough but I'm getting better!" },
      { date: "Oct 22", type: "note", content: "Interested in joining weekend group rides" },
    ],
  },
  {
    id: 8,
    name: "Minh Tran",
    age: 27,
    gender: "Male",
    location: "Hai Ba Trung, Hanoi",
    phone: "+84 97 890 1234",
    email: "minh.tran@email.com",
    sport: "CrossFit",
    emoji: "🏋️",
    flowIndex: 77,
    trend: "improving",
    streak: 18,
    lastSession: "Today",
    totalSessions: 156,
    image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Rx all WODs consistently", progress: 88, targetDate: "Dec 2025" },
      { title: "300lb back squat", progress: 95, targetDate: "Nov 2025" },
      { title: "Muscle-up mastery", progress: 75, targetDate: "Jan 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 5 - 6:00 AM",
    package: "CrossFit Elite Unlimited",
    packageExpiry: "Apr 1, 2026",
    sessionsRemaining: "Unlimited",
    monthlyRevenue: "$720",
    totalRevenue: "$10,080",
    notes: "Exceptional consistency. All lifts progressing well. Back squat at 285lb - close to 300lb goal. Elite athlete mentality.",
    medicalNotes: "No injuries. Excellent recovery capacity. Former competitive athlete. Monitor for overtraining.",
    preferences: "Early morning sessions, loves competition, tracks all PRs, very detail-oriented",
    recentSessions: [
      { date: "Nov 3", type: "Strength - Back Squat", duration: "75 min", rating: 10, notes: "285lb x 5 reps!" },
      { date: "Nov 2", type: "WOD - Fran", duration: "45 min", rating: 9, notes: "Sub-3 minute time" },
      { date: "Nov 1", type: "Gymnastic Skills", duration: "60 min", rating: 8, notes: "Muscle-up practice" },
      { date: "Oct 31", type: "Olympic Lifting", duration: "60 min", rating: 9, notes: "Clean PR 225lb" },
    ],
    achievements: [
      "🏋️ Back Squat 285lb",
      "⚡ Fran Under 3min",
      "🔥 18-Day Streak",
      "📈 All Lifts +15% (6 months)",
      "🎯 150 Session Milestone",
    ],
    communications: [
      { date: "Nov 3", type: "message", content: "285lb felt solid! 300lb here I come! 💪" },
      { date: "Oct 28", type: "note", content: "Consider competition prep - ready for local comp" },
    ],
  },
  {
    id: 9,
    name: "Thao Nguyen",
    age: 38,
    gender: "Female",
    location: "Ba Dinh, Hanoi",
    phone: "+84 98 901 2345",
    email: "thao.nguyen@email.com",
    sport: "Pilates",
    emoji: "🤸",
    flowIndex: 64,
    trend: "stable",
    streak: 12,
    lastSession: "1 day ago",
    totalSessions: 92,
    memberSince: "Apr 2024",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Master reformer advanced exercises", progress: 70, targetDate: "Feb 2026" },
      { title: "Improve core stability", progress: 85, targetDate: "Dec 2025" },
      { title: "Correct postural imbalances", progress: 80, targetDate: "Jan 2026" },
    ],
    activityLevel: "Medium",
    nextSession: "Nov 5 - 11:00 AM",
    package: "Pilates Reformer Package",
    packageExpiry: "Jan 25, 2026",
    sessionsRemaining: 16,
    monthlyRevenue: "$340",
    totalRevenue: "$2,720",
    notes: "Core control excellent. Posture significantly improved. Very focused and precise in movements. Great mind-body connection.",
    medicalNotes: "History of office-related back pain - now resolved. No current issues. Desk ergonomics improved.",
    preferences: "Late morning sessions, prefers detailed cueing, enjoys reformer work, quality over quantity",
    recentSessions: [
      { date: "Nov 2", type: "Reformer Advanced", duration: "55 min", rating: 9, notes: "Excellent control" },
      { date: "Oct 31", type: "Mat Pilates", duration: "50 min", rating: 8, notes: "Strong core work" },
      { date: "Oct 29", type: "Reformer Flow", duration: "55 min", rating: 9, notes: "Beautiful precision" },
      { date: "Oct 27", type: "Core Stability", duration: "45 min", rating: 8, notes: "Challenging session" },
    ],
    achievements: [
      "🎯 Posture Improvement 80%",
      "💪 Core Strength Elite Level",
      "✨ 12-Session Consistency",
    ],
    communications: [
      { date: "Nov 1", type: "message", content: "My back feels amazing! Thank you!" },
      { date: "Oct 25", type: "note", content: "Ready for advanced reformer choreography" },
    ],
  },
  {
    id: 10,
    name: "Long Pham",
    age: 30,
    gender: "Male",
    location: "District 2, HCMC",
    phone: "+84 99 012 3456",
    email: "long.pham@email.com",
    sport: "MMA",
    emoji: "🥋",
    flowIndex: 69,
    trend: "improving",
    streak: 9,
    lastSession: "Today",
    totalSessions: 88,
    memberSince: "Mar 2024",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Earn BJJ blue belt", progress: 75, targetDate: "Feb 2026" },
      { title: "Competition ready (amateur)", progress: 65, targetDate: "Mar 2026" },
      { title: "Master takedown defense", progress: 70, targetDate: "Jan 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 4 - 4:00 PM",
    package: "MMA Complete Program",
    packageExpiry: "Mar 10, 2026",
    sessionsRemaining: 22,
    monthlyRevenue: "$580",
    totalRevenue: "$4,640",
    notes: "Ground game improving rapidly. Competition skills developing well. Natural grappler - strong wrestling base. Very coachable.",
    medicalNotes: "Cauliflower ear (minor). Taped fingers. No significant injuries. Good conditioning.",
    preferences: "Afternoon sessions, loves rolling/sparring, competitive mindset, watches UFC regularly",
    recentSessions: [
      { date: "Nov 3", type: "BJJ Rolling", duration: "90 min", rating: 9, notes: "Submissions improving" },
      { date: "Nov 1", type: "MMA Sparring", duration: "75 min", rating: 8, notes: "Takedown defense solid" },
      { date: "Oct 30", type: "Striking", duration: "60 min", rating: 8, notes: "Combos flowing" },
      { date: "Oct 28", type: "Grappling Drills", duration: "90 min", rating: 9, notes: "Guard work excellent" },
    ],
    achievements: [
      "🥋 BJJ Stripe Progress",
      "💪 Ground Game +40%",
      "🎯 Takedown Defense Improving",
    ],
    communications: [
      { date: "Nov 2", type: "message", content: "That submission felt smooth! 🥋" },
      { date: "Oct 27", type: "note", content: "Ready for blue belt test in next 2-3 months" },
    ],
  },
  // ... I'll continue with more diverse profiles
  {
    id: 11,
    name: "Hoa Le",
    age: 25,
    gender: "Female",
    location: "Dong Da, Hanoi",
    phone: "+84 90 234 5678",
    email: "hoa.le@email.com",
    sport: "Dance",
    emoji: "💃",
    flowIndex: 60,
    trend: "stable",
    streak: 7,
    lastSession: "2 days ago",
    totalSessions: 54,
    memberSince: "Jul 2024",
    image: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Master salsa advanced patterns", progress: 70, targetDate: "Jan 2026" },
      { title: "Perform in showcase", progress: 80, targetDate: "Dec 2025" },
      { title: "Improve musicality", progress: 65, targetDate: "Feb 2026" },
    ],
    activityLevel: "Medium",
    nextSession: "Nov 5 - 7:00 PM",
    package: "Dance Fitness Premium",
    packageExpiry: "Feb 5, 2026",
    sessionsRemaining: 18,
    monthlyRevenue: "$300",
    totalRevenue: "$1,500",
    notes: "Rhythm and coordination excellent. Ready for performance showcase. Natural performer - confident on stage.",
    medicalNotes: "Ankle sprain (healed - Aug 2024). Full clearance. Good flexibility.",
    preferences: "Evening sessions, loves partner work, performance-focused, music-driven",
    recentSessions: [
      { date: "Nov 1", type: "Salsa Technique", duration: "60 min", rating: 9, notes: "Turns perfected" },
      { date: "Oct 29", type: "Choreography", duration: "75 min", rating: 8, notes: "Showcase prep" },
      { date: "Oct 26", type: "Footwork Drills", duration: "45 min", rating: 8, notes: "Timing improved" },
      { date: "Oct 24", type: "Partner Dancing", duration: "60 min", rating: 9, notes: "Great connection" },
    ],
    achievements: [
      "💃 Performance Ready",
      "🎵 Musicality Score High",
      "✨ Advanced Patterns Mastered",
    ],
    communications: [
      { date: "Oct 30", type: "message", content: "So excited for the showcase! 💃" },
      { date: "Oct 22", type: "note", content: "Choreography finalized - ready to perform" },
    ],
  },
  {
    id: 12,
    name: "Bao Nguyen",
    age: 33,
    gender: "Male",
    location: "Thanh Khe, Da Nang",
    phone: "+84 91 345 6789",
    email: "bao.nguyen@email.com",
    sport: "Climbing",
    emoji: "🧗",
    flowIndex: 66,
    trend: "improving",
    streak: 11,
    lastSession: "1 day ago",
    totalSessions: 72,
    memberSince: "May 2024",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Lead climb 6a consistently", progress: 80, targetDate: "Jan 2026" },
      { title: "Build finger strength", progress: 75, targetDate: "Dec 2025" },
      { title: "Complete outdoor climbing trip", progress: 60, targetDate: "Mar 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 4 - 3:00 PM",
    package: "Climbing Advanced",
    packageExpiry: "Feb 15, 2026",
    sessionsRemaining: 19,
    monthlyRevenue: "$440",
    totalRevenue: "$3,080",
    notes: "Finger strength improving well. Ready for 6a lead attempts. Good problem-solving skills on routes. Patient climber.",
    medicalNotes: "Finger pulley strain (healed). Proper taping technique learned. No current issues.",
    preferences: "Afternoon sessions, enjoys bouldering, analytical approach, likes route planning",
    recentSessions: [
      { date: "Nov 2", type: "Lead Climbing", duration: "90 min", rating: 9, notes: "Clean 5c ascent" },
      { date: "Oct 31", type: "Bouldering", duration: "75 min", rating: 8, notes: "Problem-solving excellent" },
      { date: "Oct 29", type: "Technique Training", duration: "60 min", rating: 9, notes: "Footwork precise" },
      { date: "Oct 27", type: "Strength Training", duration: "45 min", rating: 7, notes: "Finger board work" },
    ],
    achievements: [
      "🧗 First 5c Lead Climb",
      "💪 Finger Strength +35%",
      "🎯 Route Success Rate 85%",
    ],
    communications: [
      { date: "Nov 1", type: "message", content: "That 5c felt great! Ready for 6a 🧗" },
      { date: "Oct 25", type: "note", content: "Planning outdoor climbing trip - provide beta" },
    ],
  },
  {
    id: 13,
    name: "Lan Pham",
    age: 29,
    gender: "Female",
    location: "District 10, HCMC",
    phone: "+84 92 456 7890",
    email: "lan.pham@email.com",
    sport: "Tennis",
    emoji: "🎾",
    flowIndex: 52,
    trend: "stable",
    streak: 5,
    lastSession: "3 days ago",
    totalSessions: 38,
    memberSince: "Aug 2024",
    image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Consistent serve technique", progress: 60, targetDate: "Feb 2026" },
      { title: "Improve backhand power", progress: 50, targetDate: "Jan 2026" },
      { title: "Join club tournaments", progress: 40, targetDate: "Mar 2026" },
    ],
    activityLevel: "Medium",
    nextSession: "Nov 6 - 4:00 PM",
    package: "Tennis Development",
    packageExpiry: "Jan 20, 2026",
    sessionsRemaining: 15,
    monthlyRevenue: "$260",
    totalRevenue: "$1,040",
    notes: "Serve power increasing gradually. Backhand needs more practice and confidence. Good court positioning awareness.",
    medicalNotes: "Tennis elbow (minor - managed). Using proper grip technique. Ice after sessions.",
    preferences: "Late afternoon, prefers singles practice, detail-oriented, likes video analysis",
    recentSessions: [
      { date: "Oct 31", type: "Serve Practice", duration: "60 min", rating: 7, notes: "Power improving" },
      { date: "Oct 28", type: "Rally Training", duration: "75 min", rating: 8, notes: "Good consistency" },
      { date: "Oct 25", type: "Backhand Drills", duration: "60 min", rating: 6, notes: "Needs more work" },
      { date: "Oct 22", type: "Match Play", duration: "90 min", rating: 7, notes: "Competitive spirit" },
    ],
    achievements: [
      "🎾 Serve Speed +12%",
      "📊 Rally Consistency 75%",
      "🎯 First Match Win",
    ],
    communications: [
      { date: "Oct 29", type: "message", content: "Serve felt stronger today!" },
      { date: "Oct 20", type: "note", content: "Consider video analysis for backhand improvement" },
    ],
  },
  {
    id: 14,
    name: "Quan Vo",
    age: 22,
    gender: "Male",
    location: "Cau Giay, Hanoi",
    phone: "+84 93 567 8901",
    email: "quan.vo@email.com",
    sport: "Basketball",
    emoji: "🏀",
    flowIndex: 48,
    trend: "declining",
    streak: 2,
    lastSession: "4 days ago",
    totalSessions: 31,
    memberSince: "Sep 2024",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    status: "at-risk",
    alert: "Attendance dropping - check in needed",
    goals: [
      { title: "Improve 3-point consistency", progress: 35, targetDate: "Feb 2026" },
      { title: "Increase vertical jump 4 inches", progress: 25, targetDate: "Mar 2026" },
      { title: "Make varsity team", progress: 40, targetDate: "Jan 2026" },
    ],
    activityLevel: "Low",
    nextSession: "Nov 8 - 5:00 PM",
    package: "Basketball Skills Basic",
    packageExpiry: "Dec 30, 2025",
    sessionsRemaining: 12,
    monthlyRevenue: "$160",
    totalRevenue: "$480",
    notes: "Motivation seems low recently. Schedule check-in call to address concerns. Natural talent but needs consistency.",
    medicalNotes: "No injuries. Good athletic baseline. May be dealing with academic stress.",
    preferences: "Evening sessions, prefers scrimmage games, social player, needs structure",
    recentSessions: [
      { date: "Oct 30", type: "Shooting Drills", duration: "60 min", rating: 6, notes: "Seemed distracted" },
      { date: "Oct 25", type: "Skills Training", duration: "45 min", rating: 7, notes: "Energy low" },
      { date: "Oct 20", type: "Scrimmage", duration: "75 min", rating: 8, notes: "Engaged in game" },
    ],
    achievements: [
      "🏀 3-Point Progress Started",
      "⚡ Jump Training Baseline",
    ],
    communications: [
      { date: "Oct 31", type: "call", content: "Check-in scheduled - discuss motivation" },
      { date: "Oct 18", type: "note", content: "Student athlete - may need flexible scheduling" },
    ],
  },
  {
    id: 15,
    name: "Kim Tran",
    age: 27,
    gender: "Female",
    location: "District 1, HCMC",
    phone: "+84 94 678 9012",
    email: "kim.tran@email.com",
    sport: "Kickboxing",
    emoji: "🦵",
    flowIndex: 74,
    trend: "improving",
    streak: 16,
    lastSession: "Today",
    totalSessions: 102,
    memberSince: "Feb 2024",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop",
    status: "active",
    alert: null,
    goals: [
      { title: "Master roundhouse power", progress: 90, targetDate: "Nov 2025" },
      { title: "Fight camp preparation", progress: 85, targetDate: "Jan 2026" },
      { title: "Compete in local tournament", progress: 75, targetDate: "Feb 2026" },
    ],
    activityLevel: "High",
    nextSession: "Nov 5 - 5:00 PM",
    package: "Kickboxing Pro Unlimited",
    packageExpiry: "Apr 5, 2026",
    sessionsRemaining: "Unlimited",
    monthlyRevenue: "$620",
    totalRevenue: "$6,200",
    notes: "Roundhouse kick power exceptional. Fight prep on track. Excellent technique and discipline. Championship potential.",
    medicalNotes: "Shin conditioning good. Minor bruising normal. No injuries. Excellent fitness.",
    preferences: "Afternoon/evening, loves pad work, competitive, wants fight opportunities",
    recentSessions: [
      { date: "Nov 3", type: "Fight Camp Training", duration: "90 min", rating: 10, notes: "Explosive power" },
      { date: "Nov 2", type: "Technical Sparring", duration: "75 min", rating: 9, notes: "Clean technique" },
      { date: "Nov 1", type: "Pad Work", duration: "60 min", rating: 10, notes: "Perfect form" },
      { date: "Oct 31", type: "Conditioning", duration: "45 min", rating: 8, notes: "High intensity" },
    ],
    achievements: [
      "🦵 Roundhouse Power Peak",
      "🔥 16-Day Streak",
      "🥊 100 Session Milestone",
      "⚡ Fight Ready Status",
    ],
    communications: [
      { date: "Nov 2", type: "message", content: "Ready to compete! Let's find a tournament 🥊" },
      { date: "Oct 28", type: "note", content: "Register for local kickboxing event in Feb" },
    ],
  },
];

const aiSuggestions = [
  {
    clientId: 3,
    clientName: "Khoa Le",
    type: "retention",
    message: "Khoa hasn't trained in 5 days (shoulder rehab). Consider sending an encouragement message about recovery progress.",
    action: "Send Message",
  },
  {
    clientId: 14,
    clientName: "Quan Vo",
    type: "retention",
    message: "Quan's attendance dropping (4 days since last session). Motivation check-in recommended.",
    action: "Schedule Call",
  },
  {
    clientId: 1,
    clientName: "Huy Nguyen",
    type: "celebration",
    message: "Huy reaches 21-day streak tomorrow! Send congratulations message to maintain momentum.",
    action: "Celebrate",
  },
];

export function CoachClients({ onClientSelect }: CoachClientsProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSport, setFilterSport] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"name" | "flowIndex" | "lastSession">("flowIndex");
  const [expandedClient, setExpandedClient] = useState<number | null>(null);

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return <TrendingUp className="w-4 h-4 text-[#c6ff00]" />;
      case "declining":
        return <TrendingDown className="w-4 h-4 text-orange-400" />;
      case "at-risk":
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Minus className="w-4 h-4 text-blue-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return "bg-[#c6ff00]/20 text-[#c6ff00]";
      case "at-risk":
        return "bg-orange-500/20 text-orange-400";
      case "inactive":
        return "bg-white/5 text-white/40";
      default:
        return "bg-white/10 text-white/60";
    }
  };

  const filteredClients = clients
    .filter((client) => {
      const matchesSearch = client.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSport = filterSport === "all" || client.sport === filterSport;
      const matchesStatus = filterStatus === "all" || client.status === filterStatus;
      return matchesSearch && matchesSport && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "flowIndex") return b.flowIndex - a.flowIndex;
      if (sortBy === "lastSession") {
        const order = ["Today", "1 day ago", "2 days ago", "3 days ago", "4 days ago", "5 days ago", "6 days ago"];
        return order.indexOf(a.lastSession) - order.indexOf(b.lastSession);
      }
      return 0;
    });

  const sports = ["all", ...new Set(clients.map((c) => c.sport))];

  const toggleExpand = (clientId: number) => {
    setExpandedClient(expandedClient === clientId ? null : clientId);
  };

  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <h1 className="text-white text-2xl mb-4">Your Clients</h1>
          
          {/* Search & Filters */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                data-testid="input-search-clients"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search clients..."
                className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/40"
              />
            </div>
            
            <div className="flex gap-2">
              <select
                data-testid="select-filter-sport"
                value={filterSport}
                onChange={(e) => setFilterSport(e.target.value)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm"
              >
                <option value="all">All Sports</option>
                {sports.slice(1).map((sport) => (
                  <option key={sport} value={sport}>
                    {sport}
                  </option>
                ))}
              </select>

              <select
                data-testid="select-filter-status"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="at-risk">At Risk</option>
                <option value="inactive">Inactive</option>
              </select>

              <select
                data-testid="select-sort-by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm"
              >
                <option value="flowIndex">Flow Index</option>
                <option value="name">Name</option>
                <option value="lastSession">Recent Activity</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* AI Suggestions */}
        {aiSuggestions.length > 0 && (
          <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-5 border border-[#c6ff00]/20">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-white mb-1">AI Client Alerts</h3>
                <p className="text-white/60 text-sm">Automated retention insights</p>
              </div>
            </div>
            
            {aiSuggestions.map((suggestion, index) => (
              <div
                key={suggestion.clientId}
                data-testid={`ai-suggestion-${index}`}
                className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5 mb-3 last:mb-0"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <p className="text-white mb-1">
                      <span className="font-medium">{suggestion.clientName}</span>
                    </p>
                    <p className="text-white/60 text-sm mb-3">{suggestion.message}</p>
                    <button 
                      data-testid={`button-ai-action-${suggestion.clientId}`}
                      className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors"
                    >
                      {suggestion.action}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Client Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <p className="text-white/60 text-sm mb-1">Total Clients</p>
            <p className="text-white text-2xl">{clients.length}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <p className="text-white/60 text-sm mb-1">Active</p>
            <p className="text-[#c6ff00] text-2xl">
              {clients.filter((c) => c.status === "active").length}
            </p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <p className="text-white/60 text-sm mb-1">At Risk</p>
            <p className="text-orange-400 text-2xl">
              {clients.filter((c) => c.status === "at-risk").length}
            </p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <p className="text-white/60 text-sm mb-1">Avg Flow</p>
            <p className="text-white text-2xl">
              {Math.round(clients.reduce((acc, c) => acc + c.flowIndex, 0) / clients.length)}
            </p>
          </div>
        </div>

        {/* Client Grid */}
        <div className="grid grid-cols-1 gap-4">
          {filteredClients.map((client) => (
            <div
              key={client.id}
              data-testid={`client-card-${client.id}`}
              className={`bg-[#0f0f0f] rounded-[20px] border border-white/10 transition-all ${
                expandedClient === client.id 
                  ? "border-[#c6ff00]/30 shadow-[0_0_30px_rgba(198,255,0,0.15)]" 
                  : "hover:border-[#c6ff00]/20"
              }`}
            >
              {/* Collapsed View */}
              <div className="p-5">
                {/* Alert Banner */}
                {client.alert && (
                  <div className="mb-3 px-3 py-2 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-orange-400 flex-shrink-0" />
                    <span className="text-orange-400 text-xs">{client.alert}</span>
                  </div>
                )}

                <div className="flex items-start gap-4">
                  {/* Client Avatar & Basic Info */}
                  <img
                    src={client.image}
                    alt={client.name}
                    className="w-20 h-20 rounded-2xl object-cover ring-2 ring-white/10"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-white text-lg">{client.name}</h3>
                      <span className="text-2xl">{client.emoji}</span>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadge(client.status)}`}>
                        {client.status}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-white/60 mb-3">
                      <span>{client.age}yo • {client.gender}</span>
                      <span>{client.sport}</span>
                      <span>{client.package}</span>
                    </div>

                    {/* Quick Stats Row */}
                    <div className="grid grid-cols-4 gap-3 mb-3">
                      <div className="bg-[#1a1a1a] rounded-lg p-2">
                        <div className="flex items-center gap-1 text-xs text-white/60 mb-1">
                          <Activity className="w-3 h-3" />
                          Flow
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-white">{client.flowIndex}</span>
                          {getTrendIcon(client.trend)}
                        </div>
                      </div>
                      
                      <div className="bg-[#1a1a1a] rounded-lg p-2">
                        <div className="flex items-center gap-1 text-xs text-white/60 mb-1">
                          <Flame className="w-3 h-3 text-orange-500" />
                          Streak
                        </div>
                        <span className="text-white">{client.streak}d</span>
                      </div>

                      <div className="bg-[#1a1a1a] rounded-lg p-2">
                        <div className="flex items-center gap-1 text-xs text-white/60 mb-1">
                          <Calendar className="w-3 h-3" />
                          Sessions
                        </div>
                        <span className="text-white">{client.totalSessions}</span>
                      </div>

                      <div className="bg-[#1a1a1a] rounded-lg p-2">
                        <div className="flex items-center gap-1 text-xs text-white/60 mb-1">
                          <DollarSign className="w-3 h-3 text-[#c6ff00]" />
                          Revenue
                        </div>
                        <span className="text-[#c6ff00] text-sm">{client.monthlyRevenue}</span>
                      </div>
                    </div>

                    {/* Action Buttons Row */}
                    <div className="flex gap-2">
                      <button
                        data-testid={`button-toggle-profile-${client.id}`}
                        onClick={() => toggleExpand(client.id)}
                        className="flex-1 px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                      >
                        {expandedClient === client.id ? (
                          <>
                            <ChevronUp className="w-4 h-4" />
                            Hide Full Profile
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-4 h-4" />
                            View Full Profile
                          </>
                        )}
                      </button>
                      
                      <button 
                        data-testid={`button-message-${client.id}`}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg border border-white/10 text-sm transition-colors flex items-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        Message
                      </button>

                      <button 
                        data-testid={`button-detail-view-${client.id}`}
                        onClick={() => onClientSelect(client.id.toString())}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg border border-white/10 text-sm transition-colors flex items-center gap-2"
                      >
                        <BarChart3 className="w-4 h-4" />
                        Detail View
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Expanded View - Full Client Profile */}
              {expandedClient === client.id && (
                <div className="border-t border-white/10 bg-[#0a0a0a]/50 p-5 space-y-5 animate-in slide-in-from-top-2">
                  {/* Contact Information */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-3 flex items-center gap-2">
                      <User className="w-4 h-4 text-[#c6ff00]" />
                      Contact Information
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-white/40" />
                        <span className="text-white/60">Phone:</span>
                        <span className="text-white">{client.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-white/40" />
                        <span className="text-white/60">Email:</span>
                        <span className="text-white">{client.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-white/40" />
                        <span className="text-white/60">Location:</span>
                        <span className="text-white">{client.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-white/40" />
                        <span className="text-white/60">Member Since:</span>
                        <span className="text-white">{client.memberSince}</span>
                      </div>
                    </div>
                  </div>

                  {/* Goals & Progress */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4 text-[#c6ff00]" />
                      Goals & Progress
                    </h4>
                    <div className="space-y-3">
                      {client.goals.map((goal, idx) => (
                        <div key={idx} className="bg-[#0f0f0f] rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white text-sm">{goal.title}</span>
                            <span className="text-[#c6ff00] text-xs">{goal.progress}%</span>
                          </div>
                          <Progress value={goal.progress} className="h-2 mb-2" />
                          <div className="flex items-center justify-between text-xs text-white/60">
                            <span>Target: {goal.targetDate}</span>
                            <span>{goal.progress >= 75 ? "On Track 🎯" : goal.progress >= 50 ? "In Progress" : "Needs Attention"}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Package & Financials */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                      <h4 className="text-white mb-3 text-sm">Package Details</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-white/60">Current Package:</span>
                          <span className="text-white">{client.package}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">Expires:</span>
                          <span className="text-white">{client.packageExpiry}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">Sessions Remaining:</span>
                          <span className="text-[#c6ff00]">{client.sessionsRemaining}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                      <h4 className="text-white mb-3 text-sm">Revenue</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-white/60">Monthly:</span>
                          <span className="text-[#c6ff00]">{client.monthlyRevenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">Total Lifetime:</span>
                          <span className="text-[#c6ff00]">{client.totalRevenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">Next Session:</span>
                          <span className="text-white">{client.nextSession}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Recent Sessions */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-3 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#c6ff00]" />
                      Recent Sessions
                    </h4>
                    <div className="space-y-2">
                      {client.recentSessions.map((session, idx) => (
                        <div key={idx} className="bg-[#0f0f0f] rounded-lg p-3 flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-white text-sm">{session.date}</span>
                              <span className="text-white/60 text-xs">•</span>
                              <span className="text-white text-sm">{session.type}</span>
                              <span className="text-white/60 text-xs">({session.duration})</span>
                            </div>
                            <p className="text-white/60 text-xs">{session.notes}</p>
                          </div>
                          <div className="flex items-center gap-1 text-[#c6ff00]">
                            <Star className="w-4 h-4 fill-current" />
                            <span className="text-sm">{session.rating}/10</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Achievements */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-3 flex items-center gap-2">
                      <Award className="w-4 h-4 text-[#c6ff00]" />
                      Achievements
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {client.achievements.map((achievement, idx) => (
                        <span 
                          key={idx} 
                          className="px-3 py-1 bg-[#c6ff00]/10 border border-[#c6ff00]/20 rounded-full text-[#c6ff00] text-xs"
                        >
                          {achievement}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Notes & Medical */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                      <h4 className="text-white mb-2 text-sm">Coach Notes</h4>
                      <p className="text-white/80 text-xs leading-relaxed">{client.notes}</p>
                    </div>

                    <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                      <h4 className="text-white mb-2 text-sm flex items-center gap-2">
                        <Heart className="w-4 h-4 text-red-400" />
                        Medical Notes
                      </h4>
                      <p className="text-white/80 text-xs leading-relaxed">{client.medicalNotes}</p>
                    </div>
                  </div>

                  {/* Preferences */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-2 text-sm">Training Preferences</h4>
                    <p className="text-white/80 text-xs leading-relaxed">{client.preferences}</p>
                  </div>

                  {/* Communications Log */}
                  <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <h4 className="text-white mb-3 flex items-center gap-2">
                      <MessageCircle className="w-4 h-4 text-[#c6ff00]" />
                      Recent Communications
                    </h4>
                    <div className="space-y-2">
                      {client.communications.map((comm, idx) => (
                        <div key={idx} className="bg-[#0f0f0f] rounded-lg p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-white/60 text-xs">{comm.date}</span>
                            <span className="px-2 py-0.5 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
                              {comm.type}
                            </span>
                          </div>
                          <p className="text-white/80 text-xs">{comm.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredClients.length === 0 && (
          <div className="text-center py-12">
            <p className="text-white/60">No clients found matching your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
