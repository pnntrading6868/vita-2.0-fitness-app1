import {
  DollarSign,
  Calendar,
  Users,
  Star,
  TrendingUp,
  Clock,
  Target,
  Award,
  CreditCard,
  Download,
  PieChart as PieChartIcon,
  Sparkles,
  MessageCircle,
  Lightbulb,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const weeklyEarnings = [
  { day: "Mon", amount: 340 },
  { day: "Tue", amount: 520 },
  { day: "Wed", amount: 380 },
  { day: "Thu", amount: 640 },
  { day: "Fri", amount: 480 },
  { day: "Sat", amount: 280 },
  { day: "Sun", amount: 200 },
];

const monthlyRevenue = [
  { month: "Jun", revenue: 3200 },
  { month: "Jul", revenue: 3800 },
  { month: "Aug", revenue: 4200 },
  { month: "Sep", revenue: 4800 },
  { month: "Oct", revenue: 5400 },
  { month: "Nov", revenue: 6200 },
];

const packageBreakdown = [
  { name: "Boxing Fundamentals", value: 60, color: "#c6ff00" },
  { name: "Advanced Sparring", value: 25, color: "#00d9ff" },
  { name: "Yoga & Mindfulness", value: 15, color: "#ff00d9" },
];

const upcomingSessions = [
  {
    id: 1,
    time: "09:00 AM",
    client: "Huy Nguyen",
    sport: "Boxing",
    emoji: "🥊",
    duration: "60 min",
  },
  {
    id: 2,
    time: "11:00 AM",
    client: "Linh Tran",
    sport: "Yoga",
    emoji: "🧘",
    duration: "45 min",
  },
  {
    id: 3,
    time: "02:00 PM",
    client: "Mai Pham",
    sport: "Boxing",
    emoji: "🥊",
    duration: "90 min",
  },
];

export function CoachOverview() {
  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <h1 className="text-white text-2xl">Dashboard Overview</h1>
          <p className="text-white/60 text-sm mt-1">Welcome back, Coach!</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div data-testid="stat-week-earnings" className="bg-gradient-to-br from-[#c6ff00]/20 to-[#0f0f0f] rounded-xl p-4 border border-[#c6ff00]/30">
            <div className="flex items-center gap-2 text-[#c6ff00] text-sm mb-1">
              <DollarSign className="w-4 h-4" />
              This Week
            </div>
            <p className="text-white text-2xl mb-1">$2,840</p>
            <p className="text-[#c6ff00] text-xs">+18% vs last week</p>
          </div>

          <div data-testid="stat-sessions" className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Calendar className="w-4 h-4" />
              Sessions
            </div>
            <p className="text-white text-2xl">18</p>
          </div>

          <div data-testid="stat-active-clients" className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Users className="w-4 h-4" />
              Active Clients
            </div>
            <p className="text-white text-2xl">24</p>
          </div>

          <div data-testid="stat-rating" className="bg-[#0f0f0f] rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-1">
              <Star className="w-4 h-4" />
              Avg Rating
            </div>
            <p className="text-white text-2xl">4.9</p>
          </div>
        </div>

        {/* Earnings Section - Integrated */}
        <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-6 border border-[#c6ff00]/20">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-white text-xl mb-1">Earnings & Revenue</h2>
              <p className="text-white/60 text-sm">Your financial performance</p>
            </div>
            <button data-testid="button-view-report" className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl text-sm transition-colors">
              View Full Report
            </button>
          </div>

          {/* Revenue Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div data-testid="stat-total-revenue" className="bg-[#0f0f0f]/80 rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-[#c6ff00] text-sm mb-2">
                <DollarSign className="w-4 h-4" />
                Total Revenue
              </div>
              <p className="text-white text-2xl mb-1">$28,600</p>
              <p className="text-[#c6ff00] text-xs flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +24% this month
              </p>
            </div>

            <div data-testid="stat-month-revenue" className="bg-[#0f0f0f]/80 rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
                <Calendar className="w-4 h-4" />
                This Month
              </div>
              <p className="text-white text-2xl mb-1">$6,200</p>
              <p className="text-white/60 text-xs">Nov 2025</p>
            </div>

            <div data-testid="stat-available-revenue" className="bg-[#0f0f0f]/80 rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
                <CreditCard className="w-4 h-4" />
                Available
              </div>
              <p className="text-white text-2xl mb-1">$5,580</p>
              <p className="text-white/60 text-xs">After 10% fee</p>
            </div>

            <div data-testid="stat-pending-revenue" className="bg-[#0f0f0f]/80 rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
                <Download className="w-4 h-4" />
                Pending
              </div>
              <p className="text-white text-2xl mb-1">$620</p>
              <p className="text-white/60 text-xs">Processing</p>
            </div>
          </div>

          {/* Revenue Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Monthly Revenue Trend */}
            <div data-testid="chart-revenue-over-time" className="bg-[#0f0f0f]/80 rounded-xl p-5 border border-white/10">
              <h3 className="text-white mb-4">Revenue Over Time</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={monthlyRevenue}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                  <XAxis dataKey="month" stroke="#9B9B9B" fontSize={11} />
                  <YAxis stroke="#9B9B9B" fontSize={11} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #ffffff20",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="#c6ff00"
                    strokeWidth={3}
                    dot={{ fill: "#c6ff00", r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Package Breakdown */}
            <div data-testid="chart-revenue-by-package" className="bg-[#0f0f0f]/80 rounded-xl p-5 border border-white/10">
              <h3 className="text-white mb-4">Revenue by Package</h3>
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={packageBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {packageBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 mt-2">
                {packageBreakdown.map((item) => (
                  <div key={item.name} data-testid={`stat-package-${item.name.toLowerCase().replace(/\s+/g, '-')}`} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-white/80 text-xs">{item.name}</span>
                    </div>
                    <span className="text-white text-sm">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* AI Financial Insight */}
          <div data-testid="activity-financial-insight" className="mt-6 bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5">
            <div className="flex items-start gap-3">
              <TrendingUp className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-white text-sm mb-1">AI Financial Insights</p>
                <p className="text-white/60 text-xs">
                  Your "Boxing Fundamentals" package generates 60% of your income. Consider creating
                  an advanced version to upsell and increase average client lifetime value by an
                  estimated 35%.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left - Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Weekly Earnings Chart */}
            <div data-testid="chart-weekly-earnings" className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Weekly Earnings</h2>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={weeklyEarnings}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                  <XAxis dataKey="day" stroke="#9B9B9B" fontSize={12} />
                  <YAxis stroke="#9B9B9B" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #ffffff20",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="amount" fill="#c6ff00" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Performance Highlights */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Performance Highlights</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div data-testid="stat-client-retention" className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-[#c6ff00]" />
                    <span className="text-white/60 text-sm">Client Retention</span>
                  </div>
                  <p className="text-white text-2xl mb-1">87.5%</p>
                  <p className="text-white/60 text-xs">21 of 24 clients active</p>
                </div>

                <div data-testid="stat-avg-session" className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-blue-400" />
                    <span className="text-white/60 text-sm">Avg Session</span>
                  </div>
                  <p className="text-white text-2xl mb-1">68 min</p>
                  <p className="text-white/60 text-xs">Consistent quality</p>
                </div>

                <div data-testid="stat-success-rate" className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="w-5 h-5 text-orange-400" />
                    <span className="text-white/60 text-sm">Success Rate</span>
                  </div>
                  <p className="text-white text-2xl mb-1">94%</p>
                  <p className="text-white/60 text-xs">Goals achieved</p>
                </div>
              </div>
            </div>

            {/* AI Recommendations */}
            <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-6 border border-[#c6ff00]/20">
              <div className="flex items-start gap-3 mb-5">
                <Sparkles className="w-6 h-6 text-[#c6ff00] flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-white text-lg mb-1">AI Coach Assistant</h3>
                  <p className="text-white/60 text-sm">Personalized insights to grow your business</p>
                </div>
              </div>

              <div className="space-y-4 mb-4">
                <div data-testid="ai-insight-retention" className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-[#c6ff00]" />
                        <p className="text-white text-sm font-medium">Client Retention</p>
                      </div>
                      <p className="text-white/60 text-sm">
                        Khoa Le hasn't trained in 5 days - send encouragement or offer discount
                      </p>
                    </div>
                    <button className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg text-xs transition-colors whitespace-nowrap">
                      Apply
                    </button>
                  </div>
                </div>

                <div data-testid="ai-insight-growth" className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-[#00d9ff]" />
                        <p className="text-white text-sm font-medium">Business Growth</p>
                      </div>
                      <p className="text-white/60 text-sm">
                        Boxing package generates 60% revenue - create advanced upsell version
                      </p>
                    </div>
                    <button className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg text-xs transition-colors whitespace-nowrap">
                      Apply
                    </button>
                  </div>
                </div>

                <div data-testid="ai-insight-content" className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Lightbulb className="w-4 h-4 text-[#ff00d9]" />
                        <p className="text-white text-sm font-medium">Content Strategy</p>
                      </div>
                      <p className="text-white/60 text-sm">
                        Post 30-sec recovery tip video this week for engagement boost
                      </p>
                    </div>
                    <button className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg text-xs transition-colors whitespace-nowrap">
                      Apply
                    </button>
                  </div>
                </div>

                <div data-testid="ai-insight-communication" className="bg-[#0f0f0f]/50 rounded-xl p-4 border border-white/5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageCircle className="w-4 h-4 text-[#ffa500]" />
                        <p className="text-white text-sm font-medium">Client Communication</p>
                      </div>
                      <p className="text-white/60 text-sm">
                        Draft congratulations for Huy's 30-day streak (tomorrow)
                      </p>
                    </div>
                    <button className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg text-xs transition-colors whitespace-nowrap">
                      Apply
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 px-3 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-xs transition-colors">
                  Weekly Report
                </button>
                <button className="flex-1 px-3 py-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-lg text-xs transition-colors">
                  Auto-Draft
                </button>
              </div>
            </div>
          </div>

          {/* Right - Today's Schedule */}
          <div className="space-y-6">
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h2 className="text-white text-xl mb-5">Today's Schedule</h2>
              <div className="space-y-3">
                {upcomingSessions.map((session) => (
                  <div
                    key={session.id}
                    data-testid={`session-${session.id}`}
                    className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 hover:border-[#c6ff00]/20 transition-all cursor-pointer"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">{session.emoji}</span>
                      <div className="flex-1">
                        <p className="text-white text-sm">{session.client}</p>
                        <p className="text-white/60 text-xs">{session.sport}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-white/60">{session.time}</span>
                      <span className="text-white/60">{session.duration}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
              <h3 className="text-white mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <button data-testid="button-add-session" className="w-full px-4 py-3 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl transition-colors text-sm">
                  Add New Session
                </button>
                <button data-testid="button-message-clients" className="w-full px-4 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors text-sm">
                  Message Clients
                </button>
                <button data-testid="button-withdraw-earnings" className="w-full px-4 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors text-sm">
                  Withdraw Earnings
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
