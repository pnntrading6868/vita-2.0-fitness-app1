import {
  User,
  Mail,
  Phone,
  MapPin,
  Award,
  DollarSign,
  Calendar,
  LogOut,
  Edit,
  Camera,
  Settings as SettingsIcon,
  Bell,
  Globe,
  Package as PackageIcon,
  Plus,
  Eye,
  EyeOff,
  Star,
  Users,
} from "lucide-react";

interface CoachProfileProps {
  onLogout: () => void;
}

export function CoachProfile({ onLogout }: CoachProfileProps) {
  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <h1 className="text-white text-2xl" data-testid="text-page-title">Profile & Settings</h1>
          <p className="text-white/60 text-sm mt-1" data-testid="text-page-subtitle">Manage your account and preferences</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-5 py-6 space-y-6">
        {/* Profile Header */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-profile-header">
          <div className="flex items-start gap-5">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop"
                alt="Coach Profile"
                className="w-24 h-24 rounded-2xl object-cover"
                data-testid="img-profile-photo"
              />
              <button 
                className="absolute -bottom-2 -right-2 w-10 h-10 bg-[#c6ff00] hover:bg-[#b8f000] rounded-xl flex items-center justify-center transition-colors"
                data-testid="button-upload-photo"
              >
                <Camera className="w-5 h-5 text-black" />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-white text-2xl mb-1" data-testid="text-profile-name">Coach Marcus</h2>
              <p className="text-white/60 mb-3" data-testid="text-profile-title">Professional Boxing & Fitness Coach</p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded-full text-sm" data-testid="badge-premium-coach">
                  Premium Coach
                </span>
                <span className="px-3 py-1 bg-white/5 text-white/60 rounded-full text-sm" data-testid="badge-verified">
                  Verified
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Personal Information */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-personal-info">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-white text-xl">Personal Information</h3>
            <button 
              className="p-2 hover:bg-white/5 rounded-lg transition-colors"
              data-testid="button-edit-personal-info"
            >
              <Edit className="w-4 h-4 text-white/60" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3" data-testid="info-full-name">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <User className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Full Name</p>
                <p className="text-white" data-testid="text-full-name">Marcus Johnson</p>
              </div>
            </div>

            <div className="flex items-center gap-3" data-testid="info-email">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Email</p>
                <p className="text-white" data-testid="text-email">marcus.j@vita.app</p>
              </div>
            </div>

            <div className="flex items-center gap-3" data-testid="info-phone">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Phone</p>
                <p className="text-white" data-testid="text-phone">+84 90 123 4567</p>
              </div>
            </div>

            <div className="flex items-center gap-3" data-testid="info-location">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-white/60" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Location</p>
                <p className="text-white" data-testid="text-location">Ho Chi Minh City, Vietnam</p>
              </div>
            </div>
          </div>
        </div>

        {/* Certifications */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-certifications">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-white text-xl">Certifications</h3>
            <button 
              className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors"
              data-testid="button-add-certificate"
            >
              Add Certificate
            </button>
          </div>

          <div className="space-y-3">
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 flex items-center gap-3" data-testid="card-certification-1">
              <Award className="w-5 h-5 text-[#c6ff00]" />
              <div className="flex-1">
                <p className="text-white" data-testid="text-cert-title-1">Certified Boxing Trainer</p>
                <p className="text-white/60 text-sm" data-testid="text-cert-org-1">WBC Professional Certification</p>
              </div>
              <span className="px-2 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs" data-testid="badge-cert-verified-1">
                Verified
              </span>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 flex items-center gap-3" data-testid="card-certification-2">
              <Award className="w-5 h-5 text-[#c6ff00]" />
              <div className="flex-1">
                <p className="text-white" data-testid="text-cert-title-2">Personal Training Certificate</p>
                <p className="text-white/60 text-sm" data-testid="text-cert-org-2">ACE Certified</p>
              </div>
              <span className="px-2 py-1 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs" data-testid="badge-cert-verified-2">
                Verified
              </span>
            </div>
          </div>
        </div>

        {/* Business Settings */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-business-settings">
          <h3 className="text-white text-xl mb-5">Business Settings</h3>

          <div className="space-y-4">
            <div className="flex items-center gap-3" data-testid="setting-payout-method">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white/60" />
              </div>
              <div className="flex-1">
                <p className="text-white">Payout Method</p>
                <p className="text-white/60 text-sm" data-testid="text-payout-method">Bank Account •••• 4532</p>
              </div>
              <button 
                className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors"
                data-testid="button-edit-payout-method"
              >
                Edit
              </button>
            </div>

            <div className="flex items-center gap-3" data-testid="setting-availability">
              <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white/60" />
              </div>
              <div className="flex-1">
                <p className="text-white">Availability</p>
                <p className="text-white/60 text-sm" data-testid="text-availability">Mon-Fri: 6AM-8PM</p>
              </div>
              <button 
                className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors"
                data-testid="button-edit-availability"
              >
                Edit
              </button>
            </div>
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-app-settings">
          <h3 className="text-white text-xl mb-5">App Settings</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between" data-testid="setting-notifications">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-white/60" />
                <div>
                  <p className="text-white">Push Notifications</p>
                  <p className="text-white/60 text-sm">Session reminders and updates</p>
                </div>
              </div>
              <div 
                className="w-12 h-6 bg-[#c6ff00] rounded-full p-1 cursor-pointer"
                data-testid="toggle-notifications"
              >
                <div className="w-4 h-4 bg-black rounded-full ml-auto" />
              </div>
            </div>

            <div className="flex items-center justify-between" data-testid="setting-language">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-white/60" />
                <div>
                  <p className="text-white">Language</p>
                  <p className="text-white/60 text-sm" data-testid="text-language">English (US)</p>
                </div>
              </div>
              <button 
                className="text-[#c6ff00] hover:text-[#b8f000] text-sm transition-colors"
                data-testid="button-change-language"
              >
                Change
              </button>
            </div>
          </div>
        </div>

        {/* Packages Section */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10" data-testid="card-packages">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-white text-xl">My Packages</h3>
              <p className="text-white/60 text-sm mt-1">Manage your training packages</p>
            </div>
            <button
              className="flex items-center gap-2 px-3 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg transition-colors"
              data-testid="button-create-package"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm">New</span>
            </button>
          </div>

          {/* Package Stats */}
          <div className="grid grid-cols-3 gap-3 mb-5">
            <div className="bg-[#1a1a1a] rounded-xl p-3 border border-white/5">
              <div className="text-white/60 text-xs mb-1">Total</div>
              <p className="text-white text-lg">4</p>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 border border-white/5">
              <div className="text-white/60 text-xs mb-1">Revenue</div>
              <p className="text-white text-lg">$11.8k</p>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 border border-white/5">
              <div className="text-white/60 text-xs mb-1">Avg Rating</div>
              <p className="text-white text-lg">4.9</p>
            </div>
          </div>

          {/* Package List */}
          <div className="space-y-3">
            {[
              {
                title: "Boxing Fundamentals",
                price: 199,
                emoji: "🥊",
                purchases: 28,
                rating: 4.9,
                isPublic: true,
              },
              {
                title: "Advanced Sparring",
                price: 349,
                emoji: "🥊",
                purchases: 15,
                rating: 5.0,
                isPublic: true,
              },
              {
                title: "Yoga & Mindfulness",
                price: 149,
                emoji: "🧘",
                purchases: 42,
                rating: 4.8,
                isPublic: true,
              },
            ].map((pkg, idx) => (
              <div
                key={idx}
                className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5 hover:border-white/10 transition-all"
                data-testid={`package-${idx}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1">
                    <span className="text-2xl">{pkg.emoji}</span>
                    <div className="flex-1">
                      <h4 className="text-white mb-1">{pkg.title}</h4>
                      <div className="flex items-center gap-3 text-sm">
                        <span className="text-[#c6ff00]">${pkg.price}</span>
                        <div className="flex items-center gap-1 text-white/60">
                          <Users className="w-3 h-3" />
                          <span>{pkg.purchases}</span>
                        </div>
                        <div className="flex items-center gap-1 text-white/60">
                          <Star className="w-3 h-3 fill-current" />
                          <span>{pkg.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {pkg.isPublic ? (
                      <Eye className="w-4 h-4 text-[#c6ff00]" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-white/40" />
                    )}
                    <button className="p-1 hover:bg-white/5 rounded transition-colors">
                      <Edit className="w-4 h-4 text-white/60" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full px-6 py-4 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl border border-red-500/20 transition-colors flex items-center justify-center gap-2"
          data-testid="button-logout"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
