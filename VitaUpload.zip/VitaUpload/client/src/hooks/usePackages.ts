import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Package, InsertPackage } from "@shared/schema";

export function usePackages() {
  return useQuery<Package[]>({
    queryKey: ["/api/packages"],
    queryFn: async () => {
      const response = await fetch("/api/packages");
      if (!response.ok) throw new Error("Failed to fetch packages");
      return response.json();
    },
  });
}

export function usePackage(id: string | undefined) {
  return useQuery<Package>({
    queryKey: ["/api/packages", id],
    queryFn: async () => {
      if (!id) throw new Error("No package ID");
      const response = await fetch(`/api/packages/${id}`);
      if (!response.ok) throw new Error("Failed to fetch package");
      return response.json();
    },
    enabled: !!id,
  });
}

export function useCreatePackage() {
  return useMutation({
    mutationFn: async (data: InsertPackage) => {
      return await apiRequest("/api/packages", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/packages"] });
    },
  });
}
