import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Coach, InsertCoach } from "@shared/schema";

export function useCoaches(sport?: string) {
  return useQuery<Coach[]>({
    queryKey: ["/api/coaches", sport],
    queryFn: async () => {
      const url = sport ? `/api/coaches?sport=${encodeURIComponent(sport)}` : "/api/coaches";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch coaches");
      return response.json();
    },
    enabled: true,
  });
}

export function useCoach(id: string | undefined) {
  return useQuery<Coach>({
    queryKey: ["/api/coaches", id],
    queryFn: async () => {
      if (!id) throw new Error("No coach ID");
      const response = await fetch(`/api/coaches/${id}`);
      if (!response.ok) throw new Error("Failed to fetch coach");
      return response.json();
    },
    enabled: !!id,
  });
}

export function useCreateCoach() {
  return useMutation({
    mutationFn: async (data: InsertCoach) => {
      return await apiRequest("/api/coaches", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/coaches"] });
    },
  });
}

export function useUpdateCoach(id: string) {
  return useMutation({
    mutationFn: async (data: Partial<InsertCoach>) => {
      return await apiRequest(`/api/coaches/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/coaches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/coaches", id] });
    },
  });
}
