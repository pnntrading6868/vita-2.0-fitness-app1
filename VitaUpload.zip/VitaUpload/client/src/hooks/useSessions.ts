import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Session, InsertSession } from "@shared/schema";

export function useSessionsByAthlete(athleteId: string | undefined) {
  return useQuery<Session[]>({
    queryKey: ["/api/sessions", "athlete", athleteId],
    queryFn: async () => {
      if (!athleteId) throw new Error("No athlete ID");
      const response = await fetch(`/api/athletes/${athleteId}/sessions`);
      if (!response.ok) throw new Error("Failed to fetch sessions");
      return response.json();
    },
    enabled: !!athleteId,
  });
}

export function useSessionsByCoach(coachId: string | undefined) {
  return useQuery<Session[]>({
    queryKey: ["/api/sessions", "coach", coachId],
    queryFn: async () => {
      if (!coachId) throw new Error("No coach ID");
      const response = await fetch(`/api/coaches/${coachId}/sessions`);
      if (!response.ok) throw new Error("Failed to fetch sessions");
      return response.json();
    },
    enabled: !!coachId,
  });
}

export function useCreateSession() {
  return useMutation({
    mutationFn: async (data: InsertSession) => {
      return await apiRequest("/api/sessions", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
    },
  });
}

export function useUpdateSession(id: string) {
  return useMutation({
    mutationFn: async (data: Partial<InsertSession>) => {
      return await apiRequest(`/api/sessions/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
    },
  });
}
