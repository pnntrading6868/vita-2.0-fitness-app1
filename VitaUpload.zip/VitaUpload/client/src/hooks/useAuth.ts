import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { User, InsertUser } from "@shared/schema";

export function useCurrentUser() {
  const userIdFromStorage = localStorage.getItem("userId");
  
  return useQuery<User>({
    queryKey: ["/api/users", userIdFromStorage],
    queryFn: async () => {
      if (!userIdFromStorage) throw new Error("No user ID");
      const response = await fetch(`/api/users/${userIdFromStorage}`);
      if (!response.ok) throw new Error("Failed to fetch user");
      return response.json();
    },
    enabled: !!userIdFromStorage,
    retry: false,
  });
}

export function useCreateUser() {
  return useMutation({
    mutationFn: async (data: InsertUser) => {
      return await apiRequest("/api/users", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: (user: User) => {
      localStorage.setItem("userId", user.id);
      localStorage.setItem("userRole", user.role);
      queryClient.setQueryData(["/api/users", user.id], user);
    },
  });
}

export function useLogin() {
  return useMutation({
    mutationFn: async ({ username }: { username: string }) => {
      return await apiRequest(`/api/users/username/${username}`, {
        method: "GET",
      });
    },
    onSuccess: (user: User) => {
      localStorage.setItem("userId", user.id);
      localStorage.setItem("userRole", user.role);
      queryClient.setQueryData(["/api/users", user.id], user);
    },
  });
}

export function useLogout() {
  return useMutation({
    mutationFn: async () => {
      // In a real app, this would call a backend logout endpoint
      return Promise.resolve();
    },
    onSuccess: () => {
      localStorage.removeItem("userId");
      localStorage.removeItem("userRole");
      queryClient.clear();
    },
  });
}
