import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ===== USER & AUTHENTICATION =====

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  userMode: text("user_mode").notNull().default("athlete"), // "athlete" | "coach"
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  userMode: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ===== COACHES =====

export const coaches = pgTable("coaches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  sport: text("sport").notNull(),
  specialty: text("specialty"),
  bio: text("bio"),
  yearsExperience: integer("years_experience"),
  hourlyRate: integer("hourly_rate").notNull(), // in AED
  location: text("location").notNull(),
  distance: text("distance"), // e.g., "4.1 miles"
  rating: integer("rating").notNull().default(0), // stored as 0-500 (5.0 = 500)
  reviewCount: integer("review_count").notNull().default(0),
  sessionCount: integer("session_count").notNull().default(0),
  clientCount: integer("client_count").notNull().default(0),
  profileImage: text("profile_image").notNull(),
  coverImage: text("cover_image"),
  certifications: jsonb("certifications").$type<string[]>(), // Array of certification names
  gallery: jsonb("gallery").$type<string[]>(), // Array of image URLs
  serviceArea: text("service_area"),
  isVerified: boolean("is_verified").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCoachSchema = createInsertSchema(coaches).omit({
  id: true,
  createdAt: true,
});

export type InsertCoach = z.infer<typeof insertCoachSchema>;
export type Coach = typeof coaches.$inferSelect;

// ===== CLIENTS (for Coach CRM) =====

export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: varchar("coach_id").notNull().references(() => coaches.id),
  name: text("name").notNull(),
  age: integer("age"),
  gender: text("gender"),
  phone: text("phone"),
  email: text("email"),
  location: text("location"),
  emergencyContact: text("emergency_contact"),
  sport: text("sport").notNull(),
  flowIndex: integer("flow_index").notNull().default(50), // 0-100
  currentStreak: integer("current_streak").notNull().default(0),
  goals: jsonb("goals").$type<string[]>(),
  progressStatus: text("progress_status"),
  activePackageId: varchar("active_package_id"),
  paymentStatus: text("payment_status"),
  coachNotes: text("coach_notes"),
  medicalNotes: text("medical_notes"),
  trainingPreferences: jsonb("training_preferences").$type<Record<string, any>>(),
  lastSessionDate: timestamp("last_session_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
});

export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

// ===== PACKAGES =====

export const packages = pgTable("packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  duration: text("duration").notNull(), // e.g., "90 Days"
  totalSessions: integer("total_sessions").notNull(),
  price: integer("price").notNull(), // in AED
  discount: integer("discount").default(0), // percentage
  coaches: jsonb("coaches").$type<Array<{
    name: string;
    image: string;
    sport: string;
    sessions: number;
  }>>(),
  description: text("description"),
  whatsIncluded: jsonb("whats_included").$type<string[]>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPackageSchema = createInsertSchema(packages).omit({
  id: true,
  createdAt: true,
});

export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packages.$inferSelect;

// ===== SESSIONS =====

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  athleteId: varchar("athlete_id").notNull().references(() => users.id),
  coachId: varchar("coach_id").notNull().references(() => coaches.id),
  sport: text("sport").notNull(),
  sessionDate: timestamp("session_date").notNull(),
  duration: integer("duration").notNull(), // in minutes
  location: text("location").notNull(),
  status: text("status").notNull().default("scheduled"), // "scheduled" | "completed" | "cancelled"
  notes: text("notes"),
  caloriesBurned: integer("calories_burned"),
  rating: integer("rating"), // 0-500 (5.0 = 500)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// ===== MESSAGES =====

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  recipientId: varchar("recipient_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  read: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// ===== WALLET & TRANSACTIONS =====

export const wallets = pgTable("wallets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id),
  balance: integer("balance").notNull().default(0), // in AED cents (100 = 1 AED)
  tokenBalance: integer("token_balance").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertWalletSchema = createInsertSchema(wallets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletId: varchar("wallet_id").notNull().references(() => wallets.id),
  type: text("type").notNull(), // "deposit" | "session_payment" | "package_payment" | "refund"
  amount: integer("amount").notNull(), // in AED cents
  paymentMethod: text("payment_method"), // "bank" | "debit" | "credit" | "wallet"
  status: text("status").notNull().default("pending"), // "pending" | "completed" | "failed"
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// ===== ACHIEVEMENTS =====

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // "first_step" | "week_warrior" | "consistency_king" | "champion" | "century_club" | "multi_sport"
  title: text("title").notNull(),
  description: text("description").notNull(),
  progress: integer("progress").notNull().default(0),
  target: integer("target").notNull(),
  unlocked: boolean("unlocked").default(false),
  unlockedAt: timestamp("unlocked_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  createdAt: true,
});

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// ===== REVIEWS =====

export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: varchar("coach_id").notNull().references(() => coaches.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  rating: integer("rating").notNull(), // 0-500 (5.0 = 500)
  comment: text("comment"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
